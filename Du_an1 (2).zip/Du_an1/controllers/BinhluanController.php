<?php
function binhluan()
{
    $binhluan = showAll_binhluan();
    require_once PATH_VIEW . 'sanpham/ctsanpham.php';
}


?>