<?php
function gioithieu(){
    $sanpham = showAll_sanpham();
    require_once PATH_VIEW . 'shop/gioithieu/gioithieushop.php';
}

?>