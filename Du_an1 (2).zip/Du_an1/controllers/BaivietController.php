<?php
//danh sách
function baiviet()
{
    $baiviet = showAll_baiviet();
    require_once PATH_VIEW . 'baiviet/baiviet.php';
}
function ctbaiviet(){
    $id = $_GET['id']; // Lấy ID từ URL

    // Truy vấn cơ sở dữ liệu để lấy dữ liệu của bản ghi dựa trên ID
    $baiviet = showOne_baiviet($id);

    require_once PATH_VIEW . 'baiviet/chitiet.php';
}
//thêm nội dung
function thembaiviet()
{
    require_once PATH_VIEW . 'baiviet/thembaiviet.php';
}

function create_baiviet()
{
    if (isset($_POST['them'])) {
        $tieude_baiviet = $_POST['tieude_baiviet'];
        $anh = $_FILES['anh_bai_viet']['name']; // Lấy tên tệp ảnh
        $noi_dung = $_POST['noi_dung'];
        $ngay_dang = $_POST['ngay_dang'];
        $trangthai = $_POST['trang_thai'];
        
        

        // Di chuyển tệp ảnh vào thư mục đích
        if (empty($tieude_baiviet)||empty($anh)||empty($noi_dung)||empty($ngay_dang)||empty($trangthai)) {
            echo "<script>alert('Hãy nhập đủ thông tin!')</script>";
            echo "<script>window.location.href = 'index.php?act=thembaiviet';</script>";
        } else {
            move_uploaded_file($_FILES['anh_bai_viet']['tmp_name'], 'uploads/baiviet/' . $anh);

            // Tạo mảng dữ liệu mới
            $new_baiviet = [
                'tieude_baiviet' => $tieude_baiviet,
                'anh_bai_viet' => $anh,
                'noi_dung' => $noi_dung,
                'ngay_dang' => $ngay_dang,
                'trang_thai' => $trangthai,
                
            ];

            // Thêm dữ liệu vào cơ sở dữ liệu
            insert('tb_bai_viet', $new_baiviet);

            echo "<script>alert('Thêm bài viết thành công!')</script>";

            // Chuyển hướng sau khi thêm thành công
            echo "<script>window.location.href = 'index.php?act=baiviet';</script>";
        }
    }
}



//sửa nội dung
function suabaiviet()
{
    $id = $_GET['id']; // Lấy ID từ URL

    // Truy vấn cơ sở dữ liệu để lấy dữ liệu của bản ghi dựa trên ID
    $baiviet = showOne_baiviet($id);

    require_once PATH_VIEW . 'baiviet/capnhat.php';
}

function update_baiviet()
{
    if (isset($_POST['sua'])) {
        $id = $_POST['id_bai_viet']; // Lấy ID từ form
        $tieude_baiviet = $_POST['tieude_baiviet'];
        $anh = $_FILES['anh']['name']; // Lấy tên tệp ảnh
        $noi_dung = $_POST['noi_dung'];
        $ngaydangbai = $_POST['ngay_dang'];
        $trangthai = $_POST['trang_thai'];
        $new_baiviet = [];

        // Kiểm tra xem ảnh mới có được tải lên không
        if (!empty($anh)) {
            // Nếu có, di chuyển ảnh mới vào thư mục và cập nhật tên ảnh
            move_uploaded_file($_FILES['anh']['tmp_name'], 'uploads/baiviet/' . $anh);
            $new_baiviet = [
                'tieude_baiviet' => $tieude_baiviet,
                'anh_bai_viet' => $anh,
                'noi_dung' => $noi_dung,
                'ngay_dang' => $ngaydangbai,
                'trang_thai' => $trangthai,
            ];
        } else {
            // Nếu không, sử dụng tên ảnh cũ
            // $old_baiviet = showOne_baiviet($id);
            $new_baiviet = [
                'tieude_baiviet' => $tieude_baiviet,
                'noi_dung' => $noi_dung,
                'ngay_dang' => $ngaydangbai,
                'trang_thai' => $trangthai,
            ];
        }

        // Thực hiện cập nhật dữ liệu
        $baiviet=capnhat_baiviet($id, $new_baiviet);

        // var_dump($baiviet);die;
        echo "<script>alert('Sửa nội dung thành công!')</script>";
       

        // Chuyển hướng sau khi sửa thành công
        echo "<script>window.location.href = 'index.php?act=baiviet';</script>";
        exit(); // Thêm dòng này để dừng việc thực thi của mã PHP
    }
}



//xoá
function xoabaiviet()
{
    if (isset($_GET['act']) && $_GET['act'] == 'xoabaiviet') {
        $id_bai_viet = $_GET['id'];
        delete_baiviet($id_bai_viet);
        echo "<script>window.location.href = 'index.php?act=baiviet';</script>";

        
    }
}

function xoaAllbaiviet()
{
    if (isset($_GET['act']) && $_GET['act'] == 'xoaAllbaiviet') {
        deleteAll_baiviet();
        echo "<script>window.location.href = 'index.php?act=baiviet';</script>";
    }
}
