<?php
function sanphamshop()
{
    $danhmuc = showAll_danhmuc();
    $sanpham = showAll_sanpham();
    require_once PATH_VIEW . 'shop/sanphamshop/sanphamshop.php';
}
function shopchitietsanpham()
{
    $id = $_GET['id'];
    $id_nguoi_dung = $_SESSION['user']['id_nguoi_dung'];
    $danhgia = showAll_danhgia_id($id); // Lấy thông tin đánh giá
    $binhluan = showAll_binhluan_id($id); // Lấy thông tin bình luận
    $sanpham = showOne_sanpham($id); // Lấy thông tin sản phẩm
    require_once PATH_VIEW . 'shop/chitietsanpham/chitietsanpham.php';
    if (isset($_POST['gui_binhluan'])) {
        $ngay_dang = $_POST['ngay_dang'];
        $noidung_binhluan = $_POST['noidung_binhluan'];

        // Di chuyển tệp ảnh vào thư mục đích
        if (empty($noidung_binhluan)) {
            echo "<script>alert('Hãy nhập nội dung bình luận!')</script>";
            echo "<script>window.location.href = 'index.php?act=shopchitietsanpham&id=" . $id . "';</script>";
        } else {
            $new_binhluan = [
                'id_nguoi_dung' => $id_nguoi_dung,
                'id_san_pham' => $id,
                'ngay_dang' => $ngay_dang,
                'noidung_binhluan' => $noidung_binhluan,
            ];

            // Thêm dữ liệu vào cơ sở dữ liệu
            insert('tb_binh_luan', $new_binhluan);

            echo "<script>alert('Gửi bình luận thành công!')</script>";

            // Chuyển hướng sau khi thêm thành công
            echo "<script>window.location.href = 'index.php?act=shopchitietsanpham&id=" . $id . "';</script>";
        }
    }

}
function sanpham_danhmuc()
{
    $id_danh_muc = $_GET['iddanhmuc'];
    $danhmuc = showAll_danhmuc();
    $sanpham = showAll_sanpham_danhmuc($id_danh_muc);
    require_once PATH_VIEW . 'shop/sanphamshop/sanpham_danhmuc.php';
}

function timkiem(){
    $danhmuc = showAll_danhmuc();
    $sanpham = showAll_sanpham();
    $sptimkiem = timkiem_sanpham();
    require_once PATH_VIEW . 'shop/sanphamshop/timkiem.php'; 
}


