<?php
function donhang()
{
    $donhang = showAll_donhang();
    require_once PATH_VIEW . 'donhang/danhsach.php';
}

function chitietdonhang()
{
    $id_don_hang = $_GET['id_don_hang'];
    $donhang = showOne_donhang_admin($id_don_hang);
    $ttdonhang = showAll_ttdonhang();
// var_dump($sanpham);die;
    require_once PATH_VIEW . 'donhang/chitiet.php';
}

// Hàm update_trangthai trong file controller.php
function update_ttdonhang()
{
    if (isset($_POST['xacnhan'])) {
        $id = $_POST['id_don_hang'];
        $trangthai = ['id_trangthai_donhang' => $_POST['trangthai_donhang']]; // Đưa giá trị vào mảng

        // Cập nhật trạng thái vào cơ sở dữ liệu
        capnhat_trangthai_donhang($id, $trangthai);

        // Chuyển hướng trở lại trang danh sách liên hệ
        header("Location: index.php?act=donhang");
        exit();
    }
}
