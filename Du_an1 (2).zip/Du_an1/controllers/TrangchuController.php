<?php
function trangchu()
{
    $nguoidung = showAll_nguoidung();
    require_once PATH_VIEW . 'trangchu/trangchu.php';
}
