<?php
// controller.php
function themgiohang($id_san_pham, $so_luong = 0, $tong_tien)
{

    //kiểm tra xem có sản phẩm với id kia không
    // $sanpham = showOne_sanpham('tb_san_pham', $id_san_pham);

    // if (empty($sanpham)) {
    //     debug('Không thấy sản phẩm nào');
    // }
    $id_nguoi_dung = $_SESSION['user']['id_nguoi_dung'];
    //ktra trong giỏ hàng đã có bản ghi của user đang đăng nhập chưa
    $ktra_gio_hang = getCartID($id_nguoi_dung);
    if ($ktra_gio_hang) { //ktra nguoi dung da co gio hang chua
        $chi_tiet_gio_hang = showOneChiTietGioHang($id_san_pham, $ktra_gio_hang);
        if ($chi_tiet_gio_hang) { //truong hop san pham trong chi tiet gio hang da ton tai, chi can cong them so luong moi
            $so_luong_ton_tai = intval($chi_tiet_gio_hang['so_luong']);
            $so_luong_moi = $so_luong + $so_luong_ton_tai;
            $tong_tien_moi = $tong_tien * $so_luong_moi;
            updateChiTietGioHang($chi_tiet_gio_hang['id_gio_hang'], $chi_tiet_gio_hang['id_san_pham'], $so_luong_moi, $tong_tien_moi);
        } else { //truong hop san pham chua co trong chi tiet gio hang
            insert('tb_chitiet_giohang', [
                'id_gio_hang' => $ktra_gio_hang,
                'id_san_pham' => $id_san_pham,
                'so_luong' => $so_luong,
                'tong_tien' => $tong_tien * $so_luong,
            ]);
        }
    } else { // truong hop nguoi dung chua mua gi trong gio hang
        $id_gio_hang = insert_get_last_id('tb_gio_hang', ['id_nguoi_dung' => $id_nguoi_dung]);
        if ($id_gio_hang) {
            insert('tb_chitiet_giohang', [
                'id_gio_hang' => $id_gio_hang,
                'id_san_pham' => $id_san_pham,
                'so_luong' => $so_luong,
                'tong_tien' => $tong_tien * $so_luong,
            ]);
        }
    }

    //chuyển hướng sang list cart
    header('Location: ' . BASE_URL . '?act=danhsachgiohang');
}


function danhsachgiohang()
{
    $id_nguoi_dung = $_SESSION['user']['id_nguoi_dung'];
    $id_gio_hang = getCartID($id_nguoi_dung);
    $danh_sach_gio_hang = [];
    if ($id_gio_hang) {
        $danh_sach_gio_hang = showListChiTietGioHang($id_gio_hang);
    }
    require_once PATH_VIEW . 'shop/giohang/danhsachgiohang.php';
}

// function tanggiohang($idsanpham)
// {
// }

// function giamgiohang($idsanpham)
// {
// }

function xoagiohang($id_san_pham)
{
    if (isset($_GET['act']) && $_GET['act'] == 'xoagiohang') {
        $id_chitiet_giohang = $_GET['id_chitiet_giohang'];
        // var_dump($id_chitiet_giohang);die;
        delete_giohang($id_chitiet_giohang);
        // exit();
        echo "<script>window.location.href = 'index.php?act=danhsachgiohang';</script>";
    }
}
function capnhatgiohang()
{
    if (isset($_GET['act']) && $_GET['act'] == 'capnhatgiohang') {
        $id_chitiet_giohang = $_GET['id_chitiet_giohang'];
        $so_luong = $_POST['so_luong'];
        $tong_tien  = $_POST['gia_ban'] * $so_luong;
        $new_giohang = [
            'so_luong' => $so_luong,
            'tong_tien' => $tong_tien,
        ];

        update_giohang($id_chitiet_giohang, $new_giohang);

        echo "<script>window.location.href = 'index.php?act=danhsachgiohang';</script>";
    }
}
