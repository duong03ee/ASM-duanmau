<?php
function khuyenmai()
{
    $khuyenmai = showAll_khuyenmai();
    require_once PATH_VIEW . 'khuyenmai/khuyenmai.php';
}
function ctkhuyenmai(){
    
    $id = $_GET['id']; // Lấy ID từ URL

    $khuyenmai = showOne_khuyenmai($id);
    require_once PATH_VIEW . 'khuyenmai/chitiet.php';
}
function themkhuyenmai()
{
    require_once PATH_VIEW . 'khuyenmai/them.php';
}
function create_khuyenmai()
{
    if (isset($_POST['them'])) {
        $tenkhuyenmai = $_POST['tenkhuyenmai'];
        $makhuyenmai = $_POST['makhuyenmai'];
        $mucgiamgia = $_POST['mucgiamgia'];
        $ngaybatdau = $_POST['ngaybatdau'];
        $ngayhethan = $_POST['ngayhethan'];
        $trangthai = "";
        $mota = $_POST['mota'];
        $soluong = $_POST['soluong'];

        // Di chuyển tệp ảnh vào thư mục đích
        if (empty($tenkhuyenmai)||empty($makhuyenmai)||empty($mucgiamgia)||empty($ngaybatdau)||empty($ngayhethan)||empty($mota)) {
            echo "<script>alert('Hãy nhập đủ thông tin!')</script>";
            echo "<script>window.location.href = 'index.php?act=themkhuyenmai';</script>";
        } else {
            if($soluong >0 ){
                $trangthai="Còn";
            }else{
                $trangthai="Hết";
            }
            $new_khuyenmai = [
                'ten_khuyen_mai' => $tenkhuyenmai,
                'ma_khuyen_mai' => $makhuyenmai,
                'mo_ta' => $mota,
                'muc_giam_gia' => $mucgiamgia,
                'ngay_bat_dau' => $ngaybatdau,
                'ngay_het_han' => $ngayhethan,
                'trang_thai' => $trangthai,
                'so_luong' => $soluong,
            ];

            // Thêm dữ liệu vào cơ sở dữ liệu
            insert('tb_khuyen_mai', $new_khuyenmai);

            echo "<script>alert('Thêm khuyến mãi thành công!')</script>";

            // Chuyển hướng sau khi thêm thành công
            echo "<script>window.location.href = 'index.php?act=khuyenmai';</script>";
        }
    }
}
function xoakhuyenmai()
{
    if (isset($_GET['act']) && $_GET['act'] == 'xoakhuyenmai') {
        $id_khuyen_mai = $_GET['id'];
        delete_khuyenmai($id_khuyen_mai);

        echo "<script>window.location.href = 'index.php?act=khuyenmai';</script>";
    }
}
function suakhuyenmai()
{
    $id = $_GET['id']; // Lấy ID từ URL

    // Truy vấn cơ sở dữ liệu để lấy dữ liệu của bản ghi dựa trên ID
    $khuyenmai = showOne_khuyenmai($id);

    require_once PATH_VIEW . 'khuyenmai/capnhat.php';
}

function update_khuyenmai()
{
    if (isset($_POST['sua'])) {
        $id = $_POST['id_khuyen_mai']; // Lấy ID từ form
        $tenkhuyenmai = $_POST['tenkhuyenmai'];
        $makhuyenmai = $_POST['makhuyenmai'];
        $mucgiamgia = $_POST['mucgiamgia'];
        $ngaybatdau = $_POST['ngaybatdau'];
        $ngayhethan = $_POST['ngayhethan'];
        $trangthai = ""; // Kiểm tra ngày hết hạn
        $mota = $_POST['mota'];
        $soluong = $_POST['soluong'];
        
        if (empty($tenkhuyenmai)||empty($makhuyenmai)||empty($mucgiamgia)||empty($ngaybatdau)||empty($ngayhethan)||empty($mota)) {
            echo "<script>alert('Hãy nhập đủ thông tin!')</script>";
            echo "<script>window.location.href = 'index.php?act=suakhuyenmai';</script>";
        } else {
            if($ngaybatdau > $ngayhethan){
                echo "<script>alert('Hãy nhập ngày bắt đầu nhỏ hơn ngày hết hạn!')</script>";
                echo "<script>window.location.href = 'index.php?act=suakhuyenmai&id=".$id."';</script>";
            }
            if($soluong > 0){
                $trangthai = "Còn";
            }else{
                $trangthai = "Hết";
            }
            $new_khuyenmai = [
                'ten_khuyen_mai' => $tenkhuyenmai,
                'ma_khuyen_mai' => $makhuyenmai,
                'mo_ta' => $mota,
                'muc_giam_gia' => $mucgiamgia,
                'ngay_bat_dau' => $ngaybatdau,
                'ngay_het_han' => $ngayhethan,
                'trang_thai' => $trangthai,
                'so_luong' => $soluong,

            ];
        }

        // Thực hiện cập nhật dữ liệu
        $khuyenmai=capnhat_khuyenmai($id, $new_khuyenmai);

        // var_dump($khuyenmai);die;
        echo "<script>alert('Sửa khuyến mãi thành công!')</script>";
       

        // Chuyển hướng sau khi sửa thành công
        echo "<script>window.location.href = 'index.php?act=khuyenmai';</script>";
        exit(); // Thêm dòng này để dừng việc thực thi của mã PHP
    }
}
?>