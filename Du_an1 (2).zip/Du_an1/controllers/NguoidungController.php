<?php
function nguoidung()
{
    $nguoidung = showAll_nguoidung();
    // var_dump($nguoidung);die;
    require_once PATH_VIEW . 'nguoidung/nguoidung.php';
}
function ctnguoidung(){
    
    $id = $_GET['id']; // Lấy ID từ URL

    $nguoidung = showOne_nguoidung($id);
    require_once PATH_VIEW . 'nguoidung/chitiet.php';
}
function themnguoidung()
{
    $chucvu = get_chucvu();
    require_once PATH_VIEW . 'nguoidung/them.php';
}
function create_nguoidung()
{
    if (isset($_POST['them'])) {
        $tennguoidung = $_POST['user'];
        $diachi = $_POST['diachi'];
        $email = $_POST['email'];
        $gioitinh = $_POST['gioitinh'];
        $ngaysinh= $_POST['ngaysinh'];
        $matkhau= $_POST['matkhau'];
        $sdt = $_POST['sdt'];
        $chucvu = $_POST['chucvu'];

        if (empty($tennguoidung)||empty($diachi)||empty($email)||empty($gioitinh)||empty($ngaysinh)||empty($matkhau)||empty($sdt)) {
            echo "<script>alert('Hãy nhập đủ thông tin!')</script>";
            echo "<script>window.location.href = 'index.php?act=themnguoidung';</script>";
        } else {
            $new_nguoidung = [
                'ten_nguoi_dung' => $tennguoidung,
                'dia_chi' => $diachi,
                'email' => $email,
                'gioi_tinh' => $gioitinh,
                'ngay_sinh' => $ngaysinh,
                'mat_khau' => $matkhau,
                'sdt' => $sdt,
                'id_chuc_vu' => $chucvu,
            ];

            // Thêm dữ liệu vào cơ sở dữ liệu
            insert('tb_nguoi_dung', $new_nguoidung);

            echo "<script>alert('Thêm người dùng thành công!')</script>";

            // Chuyển hướng sau khi thêm thành công
            echo "<script>window.location.href = 'index.php?act=nguoidung';</script>";
        }
    }
}

function xoanguoidung()
{
    if (isset($_GET['act']) && $_GET['act'] == 'xoanguoidung') {
        $id_nguoi_dung = $_GET['id'];
        delete_nguoidung($id_nguoi_dung);

        echo "<script>window.location.href = 'index.php?act=nguoidung';</script>";
    }
}
function suanguoidung()
{
    $id = $_GET['id']; // Lấy ID từ URL

    // Truy vấn cơ sở dữ liệu để lấy dữ liệu của bản ghi dựa trên ID
    $nguoidung = showOne_nguoidung($id);
    $chucvu = get_chucvu();

    require_once PATH_VIEW . 'nguoidung/capnhat.php';
}

function update_nguoidung()
{
    if (isset($_POST['sua'])) {
        $id = $_POST['id_nguoi_dung']; // Lấy ID từ form
        $tennguoidung = $_POST['user'];
        $diachi = $_POST['diachi'];
        $email = $_POST['email'];
        $gioitinh = $_POST['gioitinh'];
        $ngaysinh= $_POST['ngaysinh'];
        $matkhau= $_POST['matkhau'];
        $sdt = $_POST['sdt'];
        $chucvu = $_POST['chucvu'];
        
        if (empty($tennguoidung)||empty($diachi)||empty($email)||empty($gioitinh)||empty($ngaysinh)||empty($matkhau)||empty($sdt)) {
            echo "<script>alert('Hãy nhập đủ thông tin!')</script>";
            echo "<script>window.location.href = 'index.php?act=suanguoidung';</script>";
        } else {
            
            $new_nguoidung = [
                'ten_nguoi_dung' => $tennguoidung,
                'dia_chi' => $diachi,
                'email' => $email,
                'gioi_tinh' => $gioitinh,
                'ngay_sinh' => $ngaysinh,
                'mat_khau' => $matkhau,
                'sdt' => $sdt,
                'id_chuc_vu' => $chucvu,

            ];
        }

        // Thực hiện cập nhật dữ liệu
        $nguoidung=capnhat_nguoidung($id, $new_nguoidung);

        // var_dump($nguoidung);die;
        echo "<script>alert('Sửa nguời dùng thành công!')</script>";
       

        // Chuyển hướng sau khi sửa thành công
        echo "<script>window.location.href = 'index.php?act=nguoidung';</script>";
        exit(); // Thêm dòng này để dừng việc thực thi của mã PHP
    }
}