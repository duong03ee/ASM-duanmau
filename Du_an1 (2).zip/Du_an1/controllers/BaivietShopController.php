<?php
function baivietshop(){
    $baiviet = showAll_baiviet();

    require_once PATH_VIEW .'shop/baiviet/baivietshop.php';
}
function ctbaivietshop(){
    $id = $_GET['id']; // Lấy ID từ URL
    
    $ctbaiviet = showOne_baiviet($id);
    $baiviet_lienquan = showAll_baivietlienquan($id);

    require_once PATH_VIEW . 'shop/baiviet/chitietbaivietshop.php';
}

?>