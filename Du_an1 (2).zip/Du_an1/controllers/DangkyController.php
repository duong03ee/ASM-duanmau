<?php
function dangki()
{
    if (isset($_POST['submit'])) {
        $email = $_POST['email'];
        $ho_ten = $_POST['ho_ten'];
        $mat_khau = $_POST['mat_khau'];
        $sdt = $_POST['sdt'];
        $dia_chi = $_POST['dia_chi'];
        $gioi_tinh = $_POST['gioi_tinh'];
        $ngay_sinh = $_POST['ngay_sinh'];
        $new_nguoidung = [
            'email' => $email,
            'ten_nguoi_dung' => $ho_ten,
            'dia_chi' => $dia_chi,
            'mat_khau' => $mat_khau,
            'gioi_tinh' => $gioi_tinh,
            'sdt' => $sdt,
            'ngay_sinh' => $ngay_sinh,

        ];
        insert('tb_nguoi_dung', $new_nguoidung);

        echo "<script>alert('Tạo tài khoản thành công!')</script>";

        // Chuyển hướng sau khi thêm thành công
        echo "<script>window.location.href = 'index.php?act=dangnhap';</script>";
    }
    require_once PATH_VIEW . 'shop/dangki/dangki.php';
}
