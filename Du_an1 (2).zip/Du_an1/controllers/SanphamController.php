<?php
//danh sách
function sanpham()
{
    $sanpham = showAll_sanpham();
    require_once PATH_VIEW . 'sanpham/sanpham.php';
}

function ctsanpham()
{
    $id = $_GET['id'];
    $danhgia = showOne_danhgia($id); // Lấy thông tin đánh giá
    $binhluan = showAll_binhluan($id); // Lấy thông tin bình luận
    $sanpham = showOne_sanpham($id); // Lấy thông tin sản phẩm
    require_once PATH_VIEW . 'sanpham/ctsanpham.php';
}

//thêm 
function themsanpham()
{
    $danhmuc = get_danhmuc();
    require_once PATH_VIEW . 'sanpham/themsanpham.php';
}

function create_sanpham()
{
    if (isset($_POST['them'])) {
        $ten_san_pham = $_POST['ten_san_pham'];
        $anh = $_FILES['anh']['name']; // Lấy tên tệp ảnh
        $gia = $_POST['gia'];
        $gia_ban = $_POST['gia_ban'];
        $so_luong = $_POST['so_luong'];
        $trang_thai = "";
        $mota = $_POST['mota'];
        $ngay_nhap = $_POST['ngay_nhap'];
        $danh_muc = $_POST['danh_muc'];

        // Di chuyển tệp ảnh vào thư mục đích
        if (empty($ten_san_pham) || empty($gia) || empty($gia_ban) || empty($so_luong) || empty($mota)) {
            echo "<script>alert('Hãy nhập đủ thông tin!')</script>";
            echo "<script>window.location.href = 'index.php?act=themsanpham';</script>";
        } else {
            if ($so_luong > 0) {
                $trang_thai = "Còn";
            } else {
                $trang_thai = "Hết";
            }
            move_uploaded_file($_FILES['anh']['tmp_name'], 'uploads/products/' . $anh);

            // Tạo mảng dữ liệu mới
            $new_sanpham = [
                'ten_san_pham' => $ten_san_pham,
                'gia' => $gia,
                'gia_ban' => $gia_ban,
                'so_luong' => $so_luong,
                'trang_thai' => $trang_thai,
                'mota' => $mota,
                'ngay_nhap' => $ngay_nhap,
                'id_danh_muc' => $danh_muc
            ];
            $id_san_pham = insert_get_last_id('tb_san_pham', $new_sanpham);

            $new_anh = [
                'anh' => $anh,
                'id_san_pham' => $id_san_pham
            ];
            insert('tb_anh', $new_anh);
            // Thêm dữ liệu vào cơ sở dữ liệu



            // Lấy danh sách nội dung sau khi thêm
            // $list_noidung = listAll('tb_noi_dung');
            // debug($list_noidung);
            // Hiển thị thông báo thành công

            echo "<script>alert('Thêm sản phẩm thành công!')</script>";
            // exit();
            // Chuyển hướng sau khi thêm thành công
            echo "<script>window.location.href = 'index.php?act=sanpham';</script>";
        }
    }
}



function suasanpham()
{
    $id = $_GET['id']; // Lấy ID từ URL
    $sanpham = showOne_sanpham($id);
    $danhmuc = get_danhmuc(); // Lấy danh sách danh mục
    require_once PATH_VIEW . 'sanpham/suasanpham.php'; // Truyền biến $danhmuc vào view
}


function update_sanpham()
{
    if (isset($_POST['sua'])) {
        $id = $_POST['id_san_pham'];
        $ten_san_pham = $_POST['ten_san_pham'];
        $anh = $_FILES['anh']['name'];
        $gia = $_POST['gia'];
        $gia_ban = $_POST['gia_ban'];
        $ngay_nhap = $_POST['ngay_nhap'];
        $mota = $_POST['mota'];
        $so_luong = $_POST['so_luong'];
        $trang_thai = $_POST['trang_thai'];
        $id_danh_muc = $_POST['danh_muc']; // Lấy ID của danh mục được chọn

        // Cập nhật danh mục sản phẩm
        $new_sanpham = [
            'ten_san_pham' => $ten_san_pham,
            'gia' => $gia,
            'gia_ban' => $gia_ban,
            'ngay_nhap' => $ngay_nhap,
            'mota' => $mota,
            'so_luong' => $so_luong,
            'trang_thai' => $trang_thai,
            'id_danh_muc' => $id_danh_muc // Sử dụng ID của danh mục
        ];

        // Kiểm tra xem ảnh mới có được tải lên không
        if (!empty($anh)) {
            // Nếu có, di chuyển ảnh mới vào thư mục và cập nhật tên ảnh
            move_uploaded_file($_FILES['anh']['tmp_name'], 'uploads/products/' . $anh);
            $new_anh = [
                'anh' => $anh,
            ];
            // Cập nhật ảnh
            capnhat_anh($id, $new_anh);
        }

        // Thực hiện cập nhật dữ liệu sản phẩm
        capnhat_sanpham($id, $new_sanpham);

        echo "<script>alert('Sửa sản phẩm thành công!')</script>";
        echo "<script>window.location.href = 'index.php?act=sanpham';</script>";
        exit();
    }
}





//xoá
function xoasanpham()
{
    if (isset($_GET['act']) && $_GET['act'] == 'xoasanpham') {
        $id_san_pham = $_GET['id'];
        delete_anh($id_san_pham); // Gọi hàm xóa ảnh cùng với sản phẩm
        delete_sanpham($id_san_pham); // Gọi hàm xóa sản phẩm
        echo "<script>window.location.href = 'index.php?act=sanpham';</script>";
    }
}

function xoaAllsanpham()
{
    if (isset($_GET['act']) && $_GET['act'] == 'xoaAllsanpham') {
        deleteAll_sanpham();
        echo "<script>window.location.href = 'index.php?act=sanpham';</script>";
    }
}
