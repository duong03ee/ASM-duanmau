<?php
function mua()
{
    $id_nguoi_dung = $_SESSION['user']['id_nguoi_dung'];
    $id_gio_hang = getCartID($id_nguoi_dung);
    $danhsachgiohang =  [];
    if ($id_gio_hang) {
        $danhsachgiohang = showListChiTietGioHang($id_gio_hang);
    }
    $makhuyenmai = showAll_khuyenmai();
    if (isset($_GET['id_khuyen_mai']) && $_GET['id_khuyen_mai']) {
        $mot_khuyen_mai = showOne_khuyenmai($_GET['id_khuyen_mai']);
    }
    require_once PATH_VIEW . 'shop/donhang/donhang.php';
}
function thongtinnguoidung()
{
    // Xử lý dữ liệu gửi từ form
    if (isset($_POST['thanhtoan'])) {
        // var_dump($_POST['id_khuyen_mai']); die;  
        // Lấy các giá trị từ form
        $id_gio_hang = $_POST['id_gio_hang'];
        $ten_nguoi_nhan = $_POST['ten_nguoi_nhan'];
        $sdt_nguoi_nhan = $_POST['sdt_nguoi_nhan'];
        $email = $_POST['email'];
        $ngay_dat = $_POST['ngay_dat'];
        $tong_tien = $_POST['tong_tien'];
        $diachi_nhanhang = $_POST['diachi_nhanhang'];
        $makhuyenmai = $_POST['id_khuyen_mai'];
        $phuongthuc_thanhtoan = $_POST['payment-method']; // Lấy phương thức thanh toán từ form

        // Tạo mảng dữ liệu mới
        if (empty($ten_nguoi_nhan) || empty($sdt_nguoi_nhan) || empty($email) || empty($diachi_nhanhang) || empty($phuongthuc_thanhtoan)) {
            echo "<script>alert('Hãy nhập đủ thông tin người nhận!')</script>";
            // exit();
            echo "<script>window.location.href = 'index.php?act=mua';</script>";
        } else {
            $new_donhang = [
                'ten_nguoi_nhan' => $ten_nguoi_nhan,
                'sdt_nguoi_nhan' => $sdt_nguoi_nhan,
                'email' => $email,
                'ngay_dat' => $ngay_dat,
                'tong_tien' => $tong_tien,
                'diachi_nhanhang' => $diachi_nhanhang,
                'id_khuyen_mai' => $makhuyenmai,
                'phuongthuc_thanhtoan' => $phuongthuc_thanhtoan, // Thêm phương thức thanh toán vào mảng dữ liệu
                'id_trangthai_donhang' => 1,
                'id_nguoi_dung' => $_SESSION['user']['id_nguoi_dung']
            ];
            //tru so luong khuyen mai
            if ($makhuyenmai) {
                $mot_khuyen_mai = showOne_khuyenmai($makhuyenmai);
                $soluongkhuyenmaicapnhat = intval($mot_khuyen_mai['so_luong']) - 1;
                $capnhatsoluong = capnhat_khuyenmai($makhuyenmai, ['so_luong' => $soluongkhuyenmaicapnhat]);
            }
            // Gọi hàm insert để thêm dữ liệu vào cơ sở dữ liệu
            $themdonhang = insert_get_last_id('tb_don_hang', $new_donhang);
            // $themdonhang = true;
            if ($themdonhang) {
                $_SESSION['user']['id_don_hang'] = $themdonhang;
                $chitietgiohang = getDetailCartByCartId($id_gio_hang);
                //them chi tiet don hang
                foreach ($chitietgiohang as $giohang) {
                    $new_chitiet_donhang = [
                        'id_don_hang' => $themdonhang,
                        'id_san_pham' => $giohang['id_san_pham'],
                        'so_luong' => $giohang['so_luong'],
                        'don_gia' => intval($giohang['gia_ban']),
                        'thanh_tien' => intval($giohang['gia_ban']) * intval($giohang['so_luong']),
                    ];
                    //truy van them du lieu vao chi tiet don hang
                    insert('tb_chitiet_donhang', $new_chitiet_donhang);
                }
                //xoa gio hang va chi tiet gio hang
                //xoa gio hang thanh cong check dung moi dc xoa chi tiet, xoa gio hang thi dung ham (delete_giohangdon), con xoa chi tiet gio hang thi dung ham (delete_giohang)
                $xoa_giohang = delete_giohangdon($id_gio_hang);
                if ($xoa_giohang) {
                    delete_giohang($id_gio_hang);
                }
            }

            echo "<script>alert('Đặt hàng thành công!')</script>";

            echo "<script>window.location.href = 'index.php?act=bill';</script>";
        }
    } else if ((isset($_POST['momopr']))) {
        $id_gio_hang = $_POST['id_gio_hang'];
        $ten_nguoi_nhan = $_POST['ten_nguoi_nhan'];
        $sdt_nguoi_nhan = $_POST['sdt_nguoi_nhan'];
        $email = $_POST['email'];
        $ngay_dat = $_POST['ngay_dat'];
        $tong_tien = $_POST['tong_tien'];
        $diachi_nhanhang = $_POST['diachi_nhanhang'];
        $makhuyenmai = $_POST['id_khuyen_mai'];
        $phuongthuc_thanhtoan = $_POST['payment-method']; // Lấy phương thức thanh toán từ form

        // Tạo mảng dữ liệu mới
        if (empty($ten_nguoi_nhan) || empty($sdt_nguoi_nhan) || empty($email) || empty($diachi_nhanhang) || empty($phuongthuc_thanhtoan)) {
            echo "<script>alert('Hãy nhập đủ thông tin người nhận!')</script>";
            // exit();
            echo "<script>window.location.href = 'index.php?act=mua';</script>";
        } else {
            $new_donhang = [
                'ten_nguoi_nhan' => $ten_nguoi_nhan,
                'sdt_nguoi_nhan' => $sdt_nguoi_nhan,
                'email' => $email,
                'ngay_dat' => $ngay_dat,
                'tong_tien' => $tong_tien,
                'diachi_nhanhang' => $diachi_nhanhang,
                'id_khuyen_mai' => $makhuyenmai,
                'phuongthuc_thanhtoan' => $phuongthuc_thanhtoan, // Thêm phương thức thanh toán vào mảng dữ liệu
                'id_trangthai_donhang' => 1,
                'id_nguoi_dung' => $_SESSION['user']['id_nguoi_dung']
            ];
            //tru so luong khuyen mai
            if ($makhuyenmai) {
                $mot_khuyen_mai = showOne_khuyenmai($makhuyenmai);
                $soluongkhuyenmaicapnhat = intval($mot_khuyen_mai['so_luong']) - 1;
                $capnhatsoluong = capnhat_khuyenmai($makhuyenmai, ['so_luong' => $soluongkhuyenmaicapnhat]);
            }
            // Gọi hàm insert để thêm dữ liệu vào cơ sở dữ liệu
            $themdonhang = insert_get_last_id('tb_don_hang', $new_donhang);
            // $themdonhang = true;
            if ($themdonhang) {
                $chitietgiohang = getDetailCartByCartId($id_gio_hang);
                //them chi tiet don hang
                foreach ($chitietgiohang as $giohang) {
                    $new_chitiet_donhang = [
                        'id_don_hang' => $themdonhang,
                        'id_san_pham' => $giohang['id_san_pham'],
                        'so_luong' => $giohang['so_luong'],
                        'don_gia' => intval($giohang['gia_ban']),
                        'thanh_tien' => intval($giohang['gia_ban']) * intval($giohang['so_luong']),
                    ];
                    //truy van them du lieu vao chi tiet don hang
                    insert('tb_chitiet_donhang', $new_chitiet_donhang);
                }
                //xoa gio hang va chi tiet gio hang
                //xoa gio hang thanh cong check dung moi dc xoa chi tiet, xoa gio hang thi dung ham (delete_giohangdon), con xoa chi tiet gio hang thi dung ham (delete_giohang)
                $xoa_giohang = delete_giohangdon($id_gio_hang);
                if ($xoa_giohang) {
                    delete_giohang($id_gio_hang);
                }
            }
        }

        header('Content-type: text/html; charset=utf-8');


        function execPostRequest($url, $data)
        {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt(
                $ch,
                CURLOPT_HTTPHEADER,
                array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data)
                )
            );
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            //execute post
            $result = curl_exec($ch);
            //close connection
            curl_close($ch);
            return $result;
        }

        $endpoint = "https://test-payment.momo.vn/v2/gateway/api/create";


        $partnerCode = 'MOMOBKUN20180529';
        $accessKey = 'klm05TvNBzhg7h7j';
        $secretKey = 'at67qH6mk8w5Y1nAyMoYKMWACiEi2bsa';
        $orderInfo = "Thanh toán qua QRcode MoMo";
        $amount = $_POST["tong_tien"];
        $orderId = time() . "";
        $redirectUrl = "http://localhost/Duan1/Du_an1/index.php?act=bill";
        $ipnUrl = "http://localhost/Duan1/Du_an1/index.php?act=bill";
        $extraData = "";


        $requestId = time() . "";
        $requestType = "captureWallet";
        // $extraData = ($_POST["extraData"] ? $_POST["extraData"] : "");
        //before sign HMAC SHA256 signature
        $rawHash = "accessKey=" . $accessKey . "&amount=" . $amount . "&extraData=" . $extraData . "&ipnUrl=" . $ipnUrl . "&orderId=" . $orderId . "&orderInfo=" . $orderInfo . "&partnerCode=" . $partnerCode . "&redirectUrl=" . $redirectUrl . "&requestId=" . $requestId . "&requestType=" . $requestType;
        $signature = hash_hmac("sha256", $rawHash, $secretKey);
        $data = array(
            'partnerCode' => $partnerCode,
            'partnerName' => "Test",
            "storeId" => "MomoTestStore",
            'requestId' => $requestId,
            'amount' => $amount,
            'orderId' => $orderId,
            'orderInfo' => $orderInfo,
            'redirectUrl' => $redirectUrl,
            'ipnUrl' => $ipnUrl,
            'lang' => 'vi',
            'extraData' => $extraData,
            'requestType' => $requestType,
            'signature' => $signature
        );
        $result = execPostRequest($endpoint, json_encode($data));
        $jsonResult = json_decode($result, true);  // decode json

        //Just a example, please check more in there

        header('Location: ' . $jsonResult['payUrl']);
    } else if ((isset($_POST['momoatm']))) {
        // var_dump($_POST); die;
        $id_gio_hang = $_POST['id_gio_hang'];
        $ten_nguoi_nhan = $_POST['ten_nguoi_nhan'];
        $sdt_nguoi_nhan = $_POST['sdt_nguoi_nhan'];
        $email = $_POST['email'];
        $ngay_dat = $_POST['ngay_dat'];
        $tong_tien = $_POST['tong_tien'];
        $diachi_nhanhang = $_POST['diachi_nhanhang'];
        $makhuyenmai = $_POST['id_khuyen_mai'];
        $phuongthuc_thanhtoan = $_POST['payment-method']; // Lấy phương thức thanh toán từ form

        // Tạo mảng dữ liệu mới
        if (empty($ten_nguoi_nhan) || empty($sdt_nguoi_nhan) || empty($email) || empty($diachi_nhanhang) || empty($phuongthuc_thanhtoan)) {
            echo "<script>alert('Hãy nhập đủ thông tin người nhận!')</script>";
            // exit();
            echo "<script>window.location.href = 'index.php?act=mua';</script>";
        } else {
            $new_donhang = [
                'ten_nguoi_nhan' => $ten_nguoi_nhan,
                'sdt_nguoi_nhan' => $sdt_nguoi_nhan,
                'email' => $email,
                'ngay_dat' => $ngay_dat,
                'tong_tien' => $tong_tien,
                'diachi_nhanhang' => $diachi_nhanhang,
                'id_khuyen_mai' => $makhuyenmai,
                'phuongthuc_thanhtoan' => $phuongthuc_thanhtoan, // Thêm phương thức thanh toán vào mảng dữ liệu
                'id_trangthai_donhang' => 1,
                'id_nguoi_dung' => $_SESSION['user']['id_nguoi_dung']
            ];
            //tru so luong khuyen mai
            if ($makhuyenmai) {
                $mot_khuyen_mai = showOne_khuyenmai($makhuyenmai);
                $soluongkhuyenmaicapnhat = intval($mot_khuyen_mai['so_luong']) - 1;
                $capnhatsoluong = capnhat_khuyenmai($makhuyenmai, ['so_luong' => $soluongkhuyenmaicapnhat]);
            }
            // Gọi hàm insert để thêm dữ liệu vào cơ sở dữ liệu
            $themdonhang = insert_get_last_id('tb_don_hang', $new_donhang);
            // $themdonhang = true;
            if ($themdonhang) {
                $_SESSION['user']['id_don_hang'] = $themdonhang;

                $chitietgiohang = getDetailCartByCartId($id_gio_hang);
                //them chi tiet don hang
                foreach ($chitietgiohang as $giohang) {
                    $new_chitiet_donhang = [
                        'id_don_hang' => $themdonhang,
                        'id_san_pham' => $giohang['id_san_pham'],
                        'so_luong' => $giohang['so_luong'],
                        'don_gia' => intval($giohang['gia_ban']),
                        'thanh_tien' => intval($giohang['gia_ban']) * intval($giohang['so_luong']),
                    ];
                    //truy van them du lieu vao chi tiet don hang
                    insert('tb_chitiet_donhang', $new_chitiet_donhang);
                }
                //xoa gio hang va chi tiet gio hang
                //xoa gio hang thanh cong check dung moi dc xoa chi tiet, xoa gio hang thi dung ham (delete_giohangdon), con xoa chi tiet gio hang thi dung ham (delete_giohang)
                $xoa_giohang = delete_giohangdon($id_gio_hang);
                if ($xoa_giohang) {
                    delete_giohang($id_gio_hang);
                }
            }
        }



        header('Content-type: text/html; charset=utf-8');


        function execPostRequestt($url, $data)
        {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt(
                $ch,
                CURLOPT_HTTPHEADER,
                array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data)
                )
            );
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            //execute post
            $result = curl_exec($ch);
            //close connection
            curl_close($ch);
            return $result;
        }


        $endpoint = "https://test-payment.momo.vn/v2/gateway/api/create";


        $partnerCode = 'MOMOBKUN20180529';
        $accessKey = 'klm05TvNBzhg7h7j';
        $secretKey = 'at67qH6mk8w5Y1nAyMoYKMWACiEi2bsa';
        $orderInfo = "Thanh toán qua MoMo";
        $amount = [];
        $orderId = time() . "";
        $redirectUrl = "http://localhost/Duan1/Du_an1/index.php?act=bill";
        $ipnUrl = "http://localhost/Duan1/Du_an1/index.php?act=bill";
        $extraData = "";



        // if (!empty($_POST)) {
        //     $partnerCode = $_POST["partnerCode"];
        //     $accessKey = $_POST["accessKey"];
        //     $serectkey = $_POST["secretKey"];
        // $orderId = $_POST["orderId"]; // Mã đơn hàng
        //     $orderInfo = $_POST["orderInfo"];
        $amount = $_POST["tong_tien"];
        //     $ipnUrl = $_POST["ipnUrl"];
        //     $redirectUrl = $_POST["redirectUrl"];
        //     $extraData = $_POST["extraData"];

        $requestId = time() . "";
        $requestType = "payWithATM";
        // $extraData = ($_POST["extraData"] ? $_POST["extraData"] : "");
        //before sign HMAC SHA256 signature
        $rawHash = "accessKey=" . $accessKey . "&amount=" . $amount . "&extraData=" . $extraData . "&ipnUrl=" . $ipnUrl . "&orderId=" . $orderId . "&orderInfo=" . $orderInfo . "&partnerCode=" . $partnerCode . "&redirectUrl=" . $redirectUrl . "&requestId=" . $requestId . "&requestType=" . $requestType;
        $signature = hash_hmac("sha256", $rawHash, $secretKey);
        $data = array(
            'partnerCode' => $partnerCode,
            'partnerName' => "Test",
            "storeId" => "MomoTestStore",
            'requestId' => $requestId,
            'amount' => $amount,
            'orderId' => $orderId,
            'orderInfo' => $orderInfo,
            'redirectUrl' => $redirectUrl,
            'ipnUrl' => $ipnUrl,
            'lang' => 'vi',
            'extraData' => $extraData,
            'requestType' => $requestType,
            'signature' => $signature
        );
        $result = execPostRequestt($endpoint, json_encode($data));
        $jsonResult = json_decode($result, true);  // decode json

        //Just a example, please check more in there

        header('Location: ' . $jsonResult['payUrl']);
    }
}

function bill()
{
    $id_nguoi_dung = $_SESSION['user']['id_nguoi_dung'];
    if (isset($_GET['partnerCode'])) {
        $momo = [
            'partnerCode' => $_GET['partnerCode'],
            'orderId' => $_GET['orderId'],
            'requestId' => $_GET['requestId'],
            'amount' => $_GET['amount'],
            'orderInfo' => $_GET['orderInfo'],
            'orderType' => $_GET['orderType'],
            'transId' => $_GET['transId'],
            'payType' => $_GET['payType'],
            'signature' => $_GET['signature'],
        ];
        insert('momo', $momo);
        $ma_giao_dich = [
            'ma_giao_dich' => $_GET['orderId'],
        ];
        update_magiaodich($_SESSION['user']['id_don_hang'],$ma_giao_dich);
        unset($_SESSION['user']['id_don_hang']);
    }

    $chitietdonhang = listAll_donhang($id_nguoi_dung);
    // var_dump($chitietdonhang);die;
    // exit();
    require_once PATH_VIEW . 'shop/donhang/bill.php';
}

function chitietbill()
{
    $id_anh = $_GET['id_anh'];
    $bill = showOne_bill($id_anh);
    // $momo=showALL_momo();
    require_once PATH_VIEW . 'shop/donhang/chitietbill.php';
}
function huydonhang()
{
    $id_don_hang = $_GET['id_don_hang'];
    $new_trangthai_donhang = [
        'id_trangthai_donhang' => 5,
    ];
    capnhat_trangthai_donhang($id_don_hang, $new_trangthai_donhang);
    echo "<script>alert('Huỷ thành công!')</script>";
    // exit();
    echo "<script>window.location.href = 'index.php?act=bill';</script>";
}
function danhanhang()
{
    $id_don_hang = $_GET['id_don_hang'];
    $new_trangthai_donhang = [
        'id_trangthai_donhang' => 4,
    ];
    capnhat_trangthai_donhang($id_don_hang, $new_trangthai_donhang);
    echo "<script>alert('Xác nhận thành công!')</script>";
    // exit();
    echo "<script>window.location.href = 'index.php?act=bill';</script>";
}
function guidanhgia()
{
    if (isset($_GET['id_anh'])) {
        $id = $_GET['id_anh'];
        $chitietdonhang = showOne_donhang($id);
        require_once PATH_VIEW . 'shop/donhang/guidanhgia.php';

        $id_san_pham = $_GET['id_san_pham'];
        if (isset($_POST['gui_danhgia'])) {
            $ngay_dang = date('Y-m-d'); // Sử dụng ngày hiện tại
            $noidung_danhgia = $_POST['noidung_danhgia'];
            $sao_danh_gia = $_POST['sao_danh_gia'];
            $id_nguoi_dung = 1; // Gán giá trị ID người dùng tạm thời, bạn cần thay đổi giá trị này bằng ID thực của người dùng

            if ($sao_danh_gia == 0) {
                echo "<script>alert('Hãy đánh giá sản phẩm!');</script>";
                echo "<script>window.location.href = 'index.php?act=guidanhgia&id_don_hang=" . $id . "';</script>";
            } else {
                $new_danhgia = [
                    'sao_danh_gia' => $sao_danh_gia,
                    'noidung_danhgia' => $noidung_danhgia,
                    'ngay_dang' => $ngay_dang,
                    'id_san_pham' => $id_san_pham,
                    'id_nguoi_dung' => $id_nguoi_dung,
                ];

                // Thêm dữ liệu vào cơ sở dữ liệu
                insert('tb_danh_gia', $new_danhgia);

                echo "<script>alert('Gửi đánh giá thành công!');</script>";

                // Chuyển hướng sau khi thêm thành công
                echo "<script>window.location.href = 'index.php?act=bill&id_don_hang=" . $id . "';</script>";
            }
        }
    }
}
