<?php
function danhgia()
{
    $danhgia = showAll_danhgia();
    require_once PATH_VIEW . 'danhgia/danhgia.php';
}
?>