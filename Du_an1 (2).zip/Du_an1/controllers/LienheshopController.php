<?php
function lienheshop(){
    $lienhe = showAll_lienhe();
    require_once PATH_VIEW . 'shop/lienhe/lienheshop.php';
}

function guilienhe(){
    if (isset($_POST['themm'])) {
        $sender_name = $_POST['sender_name'];
        $subject = $_POST['subject'];
        $message = $_POST['message'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $date = $_POST['date'];

        $new_guilienhe =[
            'ten_nguoi_gui'  => $sender_name,
            'tieu_de'  => $subject,
            'noi_dung'  => $message,
            'email'  => $email,
            'sdt'  => $phone,
            'ngay_gui'  => $date,
            'trang_thai' => "Chưa phản hồi",
        ];
        insert('tb_lien_he',$new_guilienhe);

        echo "<script>alert('Bạn đã gửi thắc mắc cho chúng tôi thành công! Chúng tôi sẽ sớm xử lý nhanh nhất có thể')</script>";

        // Chuyển hướng sau khi thêm thành công
        echo "<script>window.location.href = 'index.php?act=lienheshop';</script>";
        

}
}
?>