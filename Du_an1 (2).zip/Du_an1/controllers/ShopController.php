<?php
function shop()
{
    $danhmuc = showAll_danhmuc();
    $sanpham = showAll_sanpham();
    require_once PATH_VIEW . 'shop/trangchu.php';
}
