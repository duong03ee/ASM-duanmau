<?php
function lienhe()
{
    $lienhe = showAll_lienhe();
    require_once PATH_VIEW . 'lienhe/lienhe.php';
}

function chitietlienhe() {
    $id = $_GET['id'];
    $lienhe = showOne_lienhe($id);
    require_once PATH_VIEW . 'lienhe/chitietlienhe.php';
}

// Hàm update_trangthai trong file controller.php
function update_trangthai()
{
    if (isset($_POST['xacnhan'])) {
        $id = $_POST['id_lien_he'];
        $trangthai = $_POST['trang_thai'];

        // Cập nhật trạng thái vào cơ sở dữ liệu
        capnhat_trangthai($id, $trangthai);

        // Chuyển hướng trở lại trang danh sách liên hệ
        header("Location: index.php?act=lienhe");
        exit();
    }
}
