<?php

session_start();
// Require file trong commons
require_once './commons/env.php';
require_once './commons/helper.php';
require_once './commons/connect-db.php';
require_once './commons/model.php';

// Require file trong controllers và models
require_file(PATH_CONTROLLER);
require_file(PATH_MODEL);

// Điều hướng
$act = $_GET['act'] ?? '/';

// Biến này cần khai báo được link cần đăng nhập mới vào được
$arrRouteNeedAuth = [
    'cart',
    'addToCart',
    'remoteCartItem',
    'remoteCart',
    'order',
    'addOrder',
    'updateQuantity',
    'createUser',
    'danhsachnoidung',
    'themnoidung',
    'create_noidung',
    'suanoidung',
    'update_noidung',
    'xoanoidung',
    'xoaAllnoidung',

    //lienhe
    'lienhe',
    'chitietlienhe',
    'update_trangthai',

    //binhluan
    'binhluan',

    //danhgia
    'danhgia',

    //chucvu
    'chucvu',
    'themchucvu',
    'create_chucvu',
    'suachucvu',
    'update_chucvu',
    'xoachucvu',
    'xoaAllchucvu',

    //danhmuc
    'danhmuc',
    'themdanhmuc',
    'create_danhmuc',
    'suadanhmuc',
    'update_danhmuc',
    'xoadanhmuc',
    'xoaAlldanhmuc',

    //sanpham
    'sanpham',
    'ctsanpham',
    'themsanpham',
    'create_sanpham',
    'suasanpham',
    'update_sanpham',
    'xoasanpham',
    'xoaAllsanpham',

    //nguoidung
    'nguoidung',
    'ctnguoidung',
    'themnguoidung',
    'create_nguoidung',
    'suanguoidung',
    'update_nguoidung',
    'xoanguoidung',

    //khuyenmai
    'khuyenmai',
    'ctkhuyenmai',
    'themkhuyenmai',
    'create_khuyenmai',
    'suakhuyenmai',
    'update_khuyenmai',
    'xoakhuyenmai',

    //baiviet
    'baiviet',
    'ctbaiviet',
    'thembaiviet',
    'create_baiviet',
    'suabaiviet',
    'update_baiviet',
    'xoabaiviet',

    //giỏ hàng
    'danhsachgiohang',
    'themgiohang',
    'xoagiohang',
    'capnhatgiohang',

    //mua hàng
    'mua',
    'thongtinnguoidung',
    'bill',
    'chitietbill',
    'huydonhang',
    'danhanhang',
    // 'xulythanhtoanmomo_qrcode',
    // 'xulythanhtoanmomoatm',
];

// Kiểm tra xem user đã đăng nhập chưa
middleware_auth_check($act, $arrRouteNeedAuth);

match ($act) {
    '/' => sanpham(),
    //giỏ hàng
    'themgiohang' => themgiohang($_GET['id_san_pham'], $_GET['so_luong'], $_GET['tong_tien']),
    'danhsachgiohang' => danhsachgiohang(),
    // 'tanggiohang' => tanggiohang($_GET['idsanpham']),
    // 'giamgiohang' => giamgiohang($_GET['idsanpham']),
    'xoagiohang' => xoagiohang($_GET['id_chitiet_giohang']),
    'capnhatgiohang' => capnhatgiohang(),
    
    //lọc
    // 'loc' => loc(),

    //đánh giá sp
    'guidanhgia' => guidanhgia(),


    //mua hàng
    'mua' => mua(),
    'thongtinnguoidung' => thongtinnguoidung(),
    'bill' => bill(),
    'chitietbill' => chitietbill(),
    'huydonhang' => huydonhang(),
    'danhanhang' => danhanhang(),
    // 'xulythanhtoanmomo_qrcode' =>momoqr(),
    // 'xulythanhtoanmomoatm' =>atmmomo(),

    // 'cart' => cartIndex(),
    // 'addToCart' => addToCart(),
    // 'remoteCartItem' => remoteCartItem(),
    // 'remoteCart' => remoteAllCart(),
    // 'order' => orderIndex(),
    // 'addOrder' => addOrder(),
    // 'updateQuantity' => updateQuantity(),

    //user
    'addUser' => addUser(),
    'createUser' => createUser(),

    //noidung
    'danhsachnoidung' => danhsachnoidung(),
    'themnoidung' => themnoidung(),
    'create_noidung' => create_noidung(),
    'suanoidung' => suanoidung(),
    'update_noidung' => update_noidung(),
    'xoanoidung' => xoanoidung(),
    'xoaAllnoidung' => xoaAllnoidung(),

    //lienhe
    'lienhe' => lienhe(),
    'chitietlienhe' => chitietlienhe(),
    'update_trangthai' => update_trangthai(),

    //donhang
    'donhang' => donhang(),
    'chitietdonhang' => chitietdonhang(),
    'update_ttdonhang' => update_ttdonhang(),

    //binhluan
    'binhluan' => binhluan(),

    //danhgia
    'danhgia' => danhgia(),

    //chucvu
    'chucvu' => chucvu(),
    'themchucvu' => themchucvu(),
    'create_chucvu' => create_chucvu(),
    'suachucvu' => suachucvu(),
    'update_chucvu' => update_chucvu(),
    'xoachucvu' => xoachucvu(),
    'xoaAllchucvu' => xoaAllchucvu(),

    //danhmuc
    'danhmuc' => danhmuc(),
    'themdanhmuc' => themdanhmuc(),
    'create_danhmuc' => create_danhmuc(),
    'suadanhmuc' => suadanhmuc(),
    'update_danhmuc' => update_danhmuc(),
    'xoadanhmuc' => xoadanhmuc(),
    'xoaAlldanhmuc' => xoaAlldanhmuc(),

    //sanpham
    'sanpham' => sanpham(),
    'ctsanpham' => ctsanpham(),
    'themsanpham' => themsanpham(),
    'create_sanpham' => create_sanpham(),
    'suasanpham' => suasanpham(),
    'update_sanpham' => update_sanpham(),
    'xoasanpham' => xoasanpham(),
    'xoaAllsanpham' => xoaAllsanpham(),
    'timkiem' => timkiem(),

    //dangnhap
    'logout' => dangxuat(),
    'dangnhap' => hienthitrangdangnhap(),

    //nguoidung
    'nguoidung' => nguoidung(),
    'ctnguoidung' => ctnguoidung(),
    'themnguoidung' => themnguoidung(),
    'create_nguoidung' => create_nguoidung(),
    'suanguoidung' => suanguoidung(),
    'update_nguoidung' => update_nguoidung(),
    'xoanguoidung' => xoanguoidung(),

    //khuyenmai
    'khuyenmai' => khuyenmai(),
    'ctkhuyenmai' => ctkhuyenmai(),
    'themkhuyenmai' => themkhuyenmai(),
    'create_khuyenmai' => create_khuyenmai(),
    'suakhuyenmai' => suakhuyenmai(),
    'update_khuyenmai' => update_khuyenmai(),
    'xoakhuyenmai' => xoakhuyenmai(),

    //baiviet
    'baiviet' => baiviet(),
    'ctbaiviet' => ctbaiviet(),
    'thembaiviet' => thembaiviet(),
    'create_baiviet' => create_baiviet(),
    'suabaiviet' => suabaiviet(),
    'update_baiviet' => update_baiviet(),
    'xoabaiviet' => xoabaiviet(),

    // Authen
    // 'login' => authenShowFormLogin(),
    // 'logout' => authenLogout(),

    // GIAO DIỆN SHOP
    'shop' => shop(),

    'sanphamshop' => sanphamshop(),
    'shopchitietsanpham' => shopchitietsanpham(),
    'sanpham_danhmuc' => sanpham_danhmuc(),


    'gioithieushop' => gioithieu(),

    'lienheshop' => lienheshop(),
    'guilienhe' => guilienhe(),

    'baivietshop' => baivietshop(),
    'ctbaivietshop' => ctbaivietshop(),

    //đăng ký
    'dangki' => dangki(),
};

require_once './commons/disconnect-db.php';
