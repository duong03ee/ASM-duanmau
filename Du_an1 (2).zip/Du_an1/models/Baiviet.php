<?php
if (!function_exists('showAll_baiviet')) {
    function showAll_baiviet()
    {
        try {
            $sql = "SELECT * FROM `tb_bai_viet` ORDER BY id_bai_viet DESC";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('delete_baiviet')) {
    function delete_baiviet($id_bai_viet)
    {
        try {
            $sql = "DELETE FROM `tb_bai_viet` WHERE id_bai_viet = :id_bai_viet";

            $stmt = $GLOBALS['conn']->prepare($sql);


            $stmt->bindParam(":id_bai_viet", $id_bai_viet);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('showOne_baiviet')) {
    function showOne_baiviet($id_bai_viet)
    {
        try {
            $sql = "SELECT * FROM `tb_bai_viet` WHERE id_bai_viet = :id";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id", $id_bai_viet); 

            $stmt->execute();

            return $stmt->fetch();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('capnhat_baiviet')) {
    function capnhat_baiviet($id, $data = []) {
        try {
            $setParams = get_set_params($data);

            $sql = "UPDATE `tb_bai_viet` SET $setParams WHERE id_bai_viet = :id";
            // return ($sql);
            $stmt = $GLOBALS['conn']->prepare($sql);

            foreach ($data as $fieldName => &$value) {
                $stmt->bindParam(":$fieldName", $value);
            }

            $stmt->bindParam(":id", $id);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}


if (!function_exists('deleteAll_baiviet')) {
    function deleteAll_baiviet() {
        try {
            $sql = "DELETE FROM `tb_bai_viet`";
            
            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('showAll_baivietlienquan')) {
    function showAll_baivietlienquan($id_bai_viet)
    {
        try {
            $sql = "SELECT * FROM `tb_bai_viet` WHERE id_bai_viet != :id ORDER BY RAND();";

            $stmt = $GLOBALS['conn']->prepare($sql);
            
            $stmt->bindParam(":id", $id_bai_viet); 

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
