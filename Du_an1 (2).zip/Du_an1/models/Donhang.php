<?php
if (!function_exists('showAll_donhang')) {
    function showAll_donhang()
    {
        try {
            $sql = "SELECT tb_don_hang.* ,tb_khuyen_mai.ma_khuyen_mai,tb_trangthai_donhang.trangthai_donhang FROM `tb_khuyen_mai` 
            INNER JOIN tb_don_hang ON tb_khuyen_mai.id_khuyen_mai=tb_don_hang.id_khuyen_mai 
            INNER JOIN tb_trangthai_donhang 
            ON tb_trangthai_donhang.id_trangthai_donhang=tb_don_hang.id_trangthai_donhang 
            ORDER BY id_don_hang DESC";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('showAll_ttdonhang')) {
    function showAll_ttdonhang()
    {
        try {
            $sql = "SELECT * FROM `tb_trangthai_donhang` ORDER BY id_trangthai_donhang DESC";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('update_magiaodich')) {
    function update_magiaodich($id, $data = []) {
        try {
            $setParams = get_set_params($data);

            $sql = "UPDATE tb_don_hang SET $setParams WHERE id_don_hang = :id";
            
            $stmt = $GLOBALS['conn']->prepare($sql);

            foreach ($data as $fieldName => &$value) {
                $stmt->bindParam(":$fieldName", $value);
            }

            $stmt->bindParam(":id", $id);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
function showOne_donhang($id_anh)
{
    try {
        $sql = "SELECT 
                    tb_chitiet_donhang.*, 
                    tb_khuyen_mai.ma_khuyen_mai, 
                    tb_khuyen_mai.muc_giam_gia,
                    tb_anh.*, 
                    tb_don_hang.*, 
                    tb_don_hang.tong_tien, 
                    tb_san_pham.ten_san_pham,
                    tb_san_pham.gia_ban,
                    tb_trangthai_donhang.trangthai_donhang
                FROM 
                    `tb_khuyen_mai` 
                INNER JOIN 
                    tb_don_hang ON tb_don_hang.id_khuyen_mai = tb_khuyen_mai.id_khuyen_mai   
                INNER JOIN
                    tb_trangthai_donhang ON tb_trangthai_donhang.id_trangthai_donhang=tb_don_hang.id_trangthai_donhang
                INNER JOIN 
                    tb_chitiet_donhang ON tb_don_hang.id_don_hang = tb_chitiet_donhang.id_don_hang   
                INNER JOIN 
                    tb_san_pham ON tb_san_pham.id_san_pham = tb_chitiet_donhang.id_san_pham 
                INNER JOIN 
                    tb_anh ON tb_san_pham.id_san_pham = tb_anh.id_san_pham
                WHERE id_anh = :id";

        $stmt = $GLOBALS['conn']->prepare($sql);

        $stmt->bindParam(":id", $id_anh);

        $stmt->execute();

        return $stmt->fetchAll(); // Sử dụng fetchAll() để lấy tất cả các dòng dữ liệu

    } catch (\Exception $e) {
        debug($e);
    }
}

function showOne_donhang_admin($id_don_hang)
{
    try {
        $sql = "SELECT 
                    tb_chitiet_donhang.*, 
                    tb_khuyen_mai.ma_khuyen_mai, 
                    tb_khuyen_mai.muc_giam_gia,
                    tb_anh.*, 
                    tb_don_hang.*, 
                    tb_don_hang.tong_tien, 
                    tb_san_pham.ten_san_pham,
                    tb_san_pham.gia_ban,
                    tb_trangthai_donhang.trangthai_donhang
                FROM 
                    `tb_khuyen_mai` 
                INNER JOIN 
                    tb_don_hang ON tb_don_hang.id_khuyen_mai = tb_khuyen_mai.id_khuyen_mai   
                INNER JOIN
                    tb_trangthai_donhang ON tb_trangthai_donhang.id_trangthai_donhang=tb_don_hang.id_trangthai_donhang
                INNER JOIN 
                    tb_chitiet_donhang ON tb_don_hang.id_don_hang = tb_chitiet_donhang.id_don_hang   
                INNER JOIN 
                    tb_san_pham ON tb_san_pham.id_san_pham = tb_chitiet_donhang.id_san_pham 
                INNER JOIN 
                    tb_anh ON tb_san_pham.id_san_pham = tb_anh.id_san_pham
                WHERE tb_don_hang.id_don_hang = :id_don_hang";

        $stmt = $GLOBALS['conn']->prepare($sql);

        $stmt->bindParam(":id_don_hang", $id_don_hang);

        $stmt->execute();

        return $stmt->fetch(); // Sử dụng fetchAll() để lấy tất cả các dòng dữ liệu

    } catch (\Exception $e) {
        debug($e);
    }
}


if (!function_exists('showAll_sanpham')) {
    function showAll_sanpham()
    {
        try {
            $sql = "SELECT tb_san_pham.*,tb_anh.anh,tb_danh_muc.ten_danh_muc FROM `tb_anh` INNER JOIN tb_san_pham ON tb_anh.id_san_pham=tb_san_pham.id_san_pham INNER JOIN tb_danh_muc ON tb_danh_muc.id_danh_muc=tb_san_pham.id_danh_muc ORDER BY id_san_pham DESC";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('listAll_donhang')) {
    function listAll_donhang($id_nguoi_dung)
    {
        try {
            $sql = "SELECT 
            tb_chitiet_donhang.*, 
            tb_khuyen_mai.ma_khuyen_mai, 
            tb_khuyen_mai.muc_giam_gia,
            tb_anh.*, 
            tb_don_hang.id_don_hang, 
            tb_don_hang.tong_tien, 
            tb_san_pham.ten_san_pham,
            tb_trangthai_donhang.trangthai_donhang,
            tb_don_hang.id_trangthai_donhang
        FROM 
            `tb_khuyen_mai` 
        INNER JOIN 
            tb_don_hang ON tb_don_hang.id_khuyen_mai = tb_khuyen_mai.id_khuyen_mai   
        INNER JOIN
            tb_trangthai_donhang ON tb_trangthai_donhang.id_trangthai_donhang=tb_don_hang.id_trangthai_donhang
        INNER JOIN 
            tb_chitiet_donhang ON tb_don_hang.id_don_hang = tb_chitiet_donhang.id_don_hang   
        INNER JOIN 
            tb_san_pham ON tb_san_pham.id_san_pham = tb_chitiet_donhang.id_san_pham 
        INNER JOIN 
            tb_anh ON tb_san_pham.id_san_pham = tb_anh.id_san_pham
        WHERE 
            tb_don_hang.id_nguoi_dung = :id_nguoi_dung
        ORDER BY 
            tb_chitiet_donhang.id_chitiet_donhang DESC
        ";

            $stmt = $GLOBALS['conn']->prepare($sql);
            $stmt->bindParam(':id_nguoi_dung', $id_nguoi_dung);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('showOne_bill')) {
    function showOne_bill($id)
    {
        try {
            $sql = "SELECT 
            tb_chitiet_donhang.*, 
            tb_khuyen_mai.ma_khuyen_mai, 
            tb_khuyen_mai.muc_giam_gia,
            tb_anh.*, 
            tb_don_hang.*, 
            tb_san_pham.ten_san_pham,
            tb_trangthai_donhang.trangthai_donhang
        FROM 
            `tb_khuyen_mai` 
        INNER JOIN 
            tb_don_hang ON tb_don_hang.id_khuyen_mai = tb_khuyen_mai.id_khuyen_mai   
        INNER JOIN
            tb_trangthai_donhang ON tb_trangthai_donhang.id_trangthai_donhang=tb_don_hang.id_trangthai_donhang
        INNER JOIN 
            tb_chitiet_donhang ON tb_don_hang.id_don_hang = tb_chitiet_donhang.id_don_hang   
        INNER JOIN 
            tb_san_pham ON tb_san_pham.id_san_pham = tb_chitiet_donhang.id_san_pham 
        INNER JOIN 
            tb_anh ON tb_san_pham.id_san_pham = tb_anh.id_san_pham 
        WHERE id_anh = :id LIMIT 1";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id", $id);

            $stmt->execute();

            return $stmt->fetch();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('capnhat_trangthai_donhang')) {
    function capnhat_trangthai_donhang($id, $data = [])
    {
        try {
            $setParams = get_set_params($data);

            $sql = "UPDATE `tb_don_hang` SET $setParams WHERE id_don_hang = :id";
            // return ($sql);
            $stmt = $GLOBALS['conn']->prepare($sql);

            foreach ($data as $fieldName => &$value) {
                $stmt->bindParam(":$fieldName", $value);
            }

            $stmt->bindParam(":id", $id);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
