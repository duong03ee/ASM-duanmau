<?php 
function getUserClientByEmailAndPassword($email, $mat_khau)
{
    try {
        $sql = "SELECT nd.*, cv.* 
                FROM tb_nguoi_dung nd
                INNER JOIN tb_chuc_vu cv ON nd.id_chuc_vu = cv.id_chuc_vu
                WHERE nd.email = :email AND nd.mat_khau = :mat_khau
                LIMIT 1";

        $stmt = $GLOBALS['conn']->prepare($sql);

        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":mat_khau", $mat_khau);

        $stmt->execute();

        return $stmt->fetch();
    } catch (\Exception $e) {
        debug($e);
    }
}

?>