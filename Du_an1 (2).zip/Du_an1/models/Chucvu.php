<?php
if (!function_exists('showAll_chucvu')) {
    function showAll_chucvu()
    {
        try {
            $sql = "SELECT * FROM `tb_chuc_vu` ORDER BY id_chuc_vu DESC";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('delete_chucvu')) {
    function delete_chucvu($id_chuc_vu)
    {
        try {
            $sql = "DELETE FROM `tb_chuc_vu` WHERE id_chuc_vu = :id_chuc_vu";

            $stmt = $GLOBALS['conn']->prepare($sql);


            $stmt->bindParam(":id_chuc_vu", $id_chuc_vu);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

if (!function_exists('showOne_chucvu')) {
    function showOne_chucvu($id_chuc_vu)
    {
        try {
            $sql = "SELECT * FROM `tb_chuc_vu` WHERE id_chuc_vu = :id";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id", $id_chuc_vu); 

            $stmt->execute();

            return $stmt->fetch();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

if (!function_exists('capnhat_chucvu')) {
    function capnhat_chucvu($id, $data = []) {
        try {
            $setParams = get_set_params($data);

            $sql = "UPDATE `tb_chuc_vu` SET $setParams WHERE id_chuc_vu = :id";
            // return ($sql);
            $stmt = $GLOBALS['conn']->prepare($sql);

            foreach ($data as $fieldName => &$value) {
                $stmt->bindParam(":$fieldName", $value);
            }

            $stmt->bindParam(":id", $id);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

if (!function_exists('deleteAll_chucvu')) {
    function deleteAll_chucvu() {
        try {
            $sql = "DELETE FROM `tb_chuc_vu`";
            
            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}