<?php
if (!function_exists('showAll_nguoidung')) {
    function showAll_nguoidung()
    {
        try {
            $sql = "SELECT tb_nguoi_dung.*,tb_chuc_vu.ten_chuc_vu FROM `tb_nguoi_dung` INNER JOIN tb_chuc_vu ON tb_nguoi_dung.id_chuc_vu=tb_chuc_vu.id_chuc_vu ORDER BY id_nguoi_dung DESC";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('showOne_nguoidung')) {
    function showOne_nguoidung($idnguoidung)
    {
        try {
            $sql = "SELECT tb_nguoi_dung.*,tb_chuc_vu.ten_chuc_vu FROM `tb_nguoi_dung` INNER JOIN tb_chuc_vu ON tb_chuc_vu.id_chuc_vu=tb_nguoi_dung.id_chuc_vu WHERE id_nguoi_dung = :id;";

            // $sql = "SELECT * FROM `tb_nguoi_dung` WHERE id_nguoi_dung = :id";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id", $idnguoidung); 

            $stmt->execute();

            return $stmt->fetch();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('get_chucvu')) {
    function get_chucvu()
    {
        try {
            $sql = "SELECT * FROM `tb_chuc_vu`";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('capnhat_nguoidung')) {
    function capnhat_nguoidung($id, $data = []) {
        try {
            $setParams = get_set_params($data);

            $sql = "UPDATE `tb_nguoi_dung` SET $setParams WHERE id_nguoi_dung = :id";
            // return ($sql);
            $stmt = $GLOBALS['conn']->prepare($sql);

            foreach ($data as $fieldName => &$value) {
                $stmt->bindParam(":$fieldName", $value);
            }

            $stmt->bindParam(":id", $id);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

if (!function_exists('delete_nguoi_dung')) {
    function delete_nguoidung($id_nguoi_dung)
    {
        try {
            $sql = "DELETE FROM `tb_nguoi_dung` WHERE id_nguoi_dung = :id_nguoi_dung";

            $stmt = $GLOBALS['conn']->prepare($sql);


            $stmt->bindParam(":id_nguoi_dung", $id_nguoi_dung);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

?>