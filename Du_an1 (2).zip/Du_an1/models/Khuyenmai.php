<?php
if (!function_exists('showAll_khuyenmai')) {
    function showAll_khuyenmai()
    {
        try {
            $sql = "SELECT * FROM `tb_khuyen_mai` ORDER BY id_khuyen_mai DESC";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('showOne_khuyenmai')) {
    function showOne_khuyenmai($idkhuyenmai)
    {
        try {
            $sql = "SELECT * FROM `tb_khuyen_mai` WHERE id_khuyen_mai = :id";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id", $idkhuyenmai); 

            $stmt->execute();

            return $stmt->fetch();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('capnhat_khuyenmai')) {
    function capnhat_khuyenmai($id, $data = []) {
        try {
            $setParams = get_set_params($data);

            $sql = "UPDATE `tb_khuyen_mai` SET $setParams WHERE id_khuyen_mai = :id";
            // return ($sql);
            $stmt = $GLOBALS['conn']->prepare($sql);

            foreach ($data as $fieldName => &$value) {
                $stmt->bindParam(":$fieldName", $value);
            }

            $stmt->bindParam(":id", $id);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

if (!function_exists('xoa_khuyenmai')) {
    function delete_khuyenmai($id_khuyen_mai)
    {
        try {
            $sql = "DELETE FROM `tb_khuyen_mai` WHERE id_khuyen_mai = :id_khuyen_mai";

            $stmt = $GLOBALS['conn']->prepare($sql);


            $stmt->bindParam(":id_khuyen_mai", $id_khuyen_mai);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}