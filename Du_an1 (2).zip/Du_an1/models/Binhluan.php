<?php
function showAll_binhluan()
{
    try {
        $sql = "SELECT * FROM tb_nguoi_dung 
                INNER JOIN tb_binh_luan ON tb_nguoi_dung.id_nguoi_dung = tb_binh_luan.id_nguoi_dung 
                INNER JOIN tb_san_pham ON tb_san_pham.id_san_pham = tb_binh_luan.id_san_pham 
                INNER JOIN tb_anh ON tb_anh.id_san_pham = tb_san_pham.id_san_pham 
                ORDER BY id_binh_luan DESC";

        $stmt = $GLOBALS['conn']->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    } catch (\Exception $e) {
        debug($e);
    }
}
function showAll_binhluan_id($id_sanpham)
{
    try {
        $sql = "SELECT * FROM tb_nguoi_dung 
                INNER JOIN tb_binh_luan ON tb_nguoi_dung.id_nguoi_dung = tb_binh_luan.id_nguoi_dung 
                INNER JOIN tb_san_pham ON tb_san_pham.id_san_pham = tb_binh_luan.id_san_pham 
                INNER JOIN tb_anh ON tb_anh.id_san_pham = tb_san_pham.id_san_pham 
                WHERE tb_san_pham.id_san_pham = :id_sanpham
                ORDER BY tb_binh_luan.id_binh_luan DESC";

        $stmt = $GLOBALS['conn']->prepare($sql);
        $stmt->bindParam(':id_sanpham', $id_sanpham);
        $stmt->execute();

        return $stmt->fetchAll();
    } catch (\Exception $e) {
        debug($e);
    }
}
// if (!function_exists('showOne')) {
//     function showOne($tableName, $id) {
//         try {
//             $sql = "SELECT * FROM $tableName WHERE id = :id LIMIT 1";

//             $stmt = $GLOBALS['conn']->prepare($sql);

//             $stmt->bindParam(":id", $id);

//             $stmt->execute();

//             return $stmt->fetch();
//         } catch (\Exception $e) {
//             debug($e);
//         }
//     }
// }


// model/binhluan.php
if (!function_exists('showOne_binhluan')) {
    function showOne_binhluan($id_san_pham)
    {
        try {
            $sql = "SELECT tb_nguoi_dung.ten_nguoi_dung, tb_binh_luan.noidung_binhluan
                    FROM tb_binh_luan
                    INNER JOIN tb_nguoi_dung ON tb_nguoi_dung.id_nguoi_dung = tb_binh_luan.id_nguoi_dung
                    WHERE tb_binh_luan.id_san_pham = :id_san_pham
                    ORDER BY tb_binh_luan.id_binh_luan DESC
                    LIMIT 1"; // Chỉ lấy một bình luận

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id_san_pham", $id_san_pham);

            $stmt->execute();

            return $stmt->fetch(); // Sử dụng fetch() để lấy chỉ một bình luận
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
