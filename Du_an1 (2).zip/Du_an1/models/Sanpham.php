<?php
if (!function_exists('showAll_sanpham')) {
    function showAll_sanpham()
    {
        try {
            $sql = "SELECT tb_san_pham.*,tb_anh.anh,tb_danh_muc.ten_danh_muc FROM `tb_anh` INNER JOIN tb_san_pham ON tb_anh.id_san_pham=tb_san_pham.id_san_pham INNER JOIN tb_danh_muc ON tb_danh_muc.id_danh_muc=tb_san_pham.id_danh_muc ORDER BY id_san_pham DESC";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('showAll_sanpham_danhmuc')) {
    function showAll_sanpham_danhmuc($id_danh_muc)
    {
        try {
            $sql = "SELECT tb_san_pham.*,tb_anh.anh,tb_danh_muc.ten_danh_muc 
                    FROM `tb_anh` 
                    INNER JOIN tb_san_pham ON tb_anh.id_san_pham=tb_san_pham.id_san_pham 
                    INNER JOIN tb_danh_muc ON tb_danh_muc.id_danh_muc=tb_san_pham.id_danh_muc 
                    WHERE tb_san_pham.id_danh_muc = :id_danh_muc 
                    ORDER BY id_san_pham DESC";

            $stmt = $GLOBALS['conn']->prepare($sql);
            $stmt->bindParam(':id_danh_muc', $id_danh_muc, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

if (!function_exists('get_danhmuc')) {
    function get_danhmuc()
    {
        try {
            $sql = "SELECT * FROM `tb_danh_muc`";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('delete_sanpham')) {
    function delete_sanpham($id_san_pham)
    {
        try {
            $sql = "DELETE FROM `tb_san_pham` WHERE id_san_pham = :id_san_pham";

            $stmt = $GLOBALS['conn']->prepare($sql);


            $stmt->bindParam(":id_san_pham", $id_san_pham);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('delete_anh')) {
    function delete_anh($id_san_pham)
    {
        try {
            $sql = "DELETE tb_anh FROM tb_anh 
                    INNER JOIN tb_san_pham ON tb_san_pham.id_san_pham = tb_anh.id_san_pham 
                    WHERE tb_anh.id_san_pham = :id_san_pham";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id_san_pham", $id_san_pham);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

if (!function_exists('showOne_sanpham')) {
    function showOne_sanpham($id)
    {
        try {
            $sql = "SELECT tb_san_pham.*,tb_anh.anh,tb_danh_muc.ten_danh_muc FROM `tb_anh` INNER JOIN tb_san_pham ON tb_san_pham.id_san_pham=tb_anh.id_san_pham INNER JOIN tb_danh_muc ON tb_danh_muc.id_danh_muc=tb_san_pham.id_danh_muc WHERE tb_san_pham.id_san_pham = :id";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id", $id);

            $stmt->execute();

            return $stmt->fetch();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}


if (!function_exists('capnhat_sanpham')) {
    function capnhat_sanpham($id, $data = [])
    {
        try {
            $setParams = get_set_params($data);

            $sql = "UPDATE `tb_san_pham` SET $setParams WHERE id_san_pham = :id";
            // return ($sql);
            $stmt = $GLOBALS['conn']->prepare($sql);

            foreach ($data as $fieldName => &$value) {
                $stmt->bindParam(":$fieldName", $value);
            }

            $stmt->bindParam(":id", $id);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

if (!function_exists('capnhat_anh')) {
    function capnhat_anh($id, $data = [])
    {
        try {
            $setParams = get_set_params($data);

            $sql = "UPDATE `tb_anh` SET $setParams WHERE id_san_pham = :id";

            $stmt = $GLOBALS['conn']->prepare($sql);

            foreach ($data as $fieldName => &$value) {
                $stmt->bindParam(":$fieldName", $value);
            }

            $stmt->bindParam(":id", $id);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

if (!function_exists('deleteAll_sanpham')) {
    function deleteAll_sanpham()
    {
        try {
            $sql = "DELETE FROM `tb_san_pham`";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('timkiem_sanpham')){
    function timkiem_sanpham(){   
        $tukhoa = $_GET['search_query'];
        $loaigia= $_GET['gia'];
        if(isset($_GET['search_query'])){
            try {
                ;
                $sql_timkiem = "SELECT tb_san_pham.*, tb_anh.anh, tb_danh_muc.ten_danh_muc FROM `tb_anh` INNER JOIN tb_san_pham ON tb_anh.id_san_pham=tb_san_pham.id_san_pham INNER JOIN tb_danh_muc ON tb_danh_muc.id_danh_muc=tb_san_pham.id_danh_muc WHERE `ten_san_pham` LIKE '%".$tukhoa."%' ORDER BY tb_san_pham.gia_ban ".$loaigia."";
                
                $stmt = $GLOBALS['conn']->prepare($sql_timkiem);
                $stmt->execute();
    
                return $stmt->fetchAll();
            } catch (\Exception $e) {
                debug($e);
            }
        }else if(isset($_GET['search_query'])&&isset($_GET['gia'])){
            try {
                ;
                $sql_timkiem = "SELECT tb_san_pham.*, tb_anh.anh, tb_danh_muc.ten_danh_muc FROM `tb_anh` INNER JOIN tb_san_pham ON tb_anh.id_san_pham=tb_san_pham.id_san_pham INNER JOIN tb_danh_muc ON tb_danh_muc.id_danh_muc=tb_san_pham.id_danh_muc WHERE `ten_san_pham` LIKE '%".$tukhoa."%' ORDER BY tb_san_pham.gia_ban ".$loaigia."";
                
                $stmt = $GLOBALS['conn']->prepare($sql_timkiem);
                $stmt->execute();
    
                return $stmt->fetchAll();
            } catch (\Exception $e) {
                debug($e);
            }
        }else {
            try {
                $sql_timkiem = "SELECT tb_san_pham.*, tb_anh.anh, tb_danh_muc.ten_danh_muc FROM `tb_anh` INNER JOIN tb_san_pham ON tb_anh.id_san_pham=tb_san_pham.id_san_pham INNER JOIN tb_danh_muc ON tb_danh_muc.id_danh_muc=tb_san_pham.id_danh_muc ORDER BY Rand() ,tb_san_pham.gia_ban limit 9 ";
    
                $stmt = $GLOBALS['conn']->prepare($sql_timkiem);
                $stmt->execute();
    
                return $stmt->fetchAll();
            } catch (\Exception $e) {
                debug($e);
            }                    
        }
    }
}
