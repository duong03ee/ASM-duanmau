<?php
if (!function_exists('showAll_lienhe')) {
    function showAll_lienhe()
    {
        try {
            $sql = "SELECT * FROM `tb_lien_he` ORDER BY id_lien_he DESC";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('showOne_lienhe')) {
    function showOne_lienhe($id_lien_he) {
        try {
            $sql = "SELECT * FROM `tb_lien_he` WHERE id_lien_he = :id";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id", $id_lien_he);

            $stmt->execute();

            return $stmt->fetch();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('capnhat_trangthai_lienhe')) {
    function capnhat_trangthai($id, $trang_thai) {
        try {
            // Chuẩn bị câu truy vấn SQL
            $sql = "UPDATE `tb_lien_he` SET `trang_thai` = :trang_thai WHERE id_lien_he = :id";

            // Chuẩn bị và thực thi câu truy vấn
            $stmt = $GLOBALS['conn']->prepare($sql);
            $stmt->bindParam(":trang_thai", $trang_thai);
            $stmt->bindParam(":id", $id);
            $stmt->execute();
        } catch (\Exception $e) {
            debug($e); // Xử lý lỗi nếu có
        }
    }
}

?>