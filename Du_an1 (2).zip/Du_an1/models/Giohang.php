<?php
if (!function_exists('getCartID')) {
    function getCartID($id_nguoi_dung)
    {
        $cart = getCartByUserID($id_nguoi_dung);

        if (!empty($cart)) {
            return $cart['id_gio_hang'];
        }else{
            return false;
        }
    }
}
if (!function_exists('getCartByUserID')) {
    function getCartByUserID($id_nguoi_dung)
    {
        try {
            $sql = "SELECT * FROM `tb_gio_hang` INNER JOIN tb_nguoi_dung ON tb_gio_hang.id_nguoi_dung=tb_nguoi_dung.id_nguoi_dung WHERE tb_gio_hang.id_nguoi_dung = :id_nguoi_dung LIMIT 1";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id_nguoi_dung", $id_nguoi_dung);

            $stmt->execute();

            // $data = $stmt->fetch();
            // if (empty($data)) { //chưa có bản ghi

            // }
            return $stmt->fetch();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('getCartByCartId')) {
    function getCartByCartId($id_gio_hang)
    {
        try {
            $sql = "SELECT * FROM `tb_gio_hang` WHERE id_gio_hang = :id_gio_hang";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id_gio_hang", $id_gio_hang);

            $stmt->execute();

            // $data = $stmt->fetch();
            // if (empty($data)) { //chưa có bản ghi

            // }
            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

if (!function_exists('delete_giohangdon')) {
    function delete_giohangdon($id_gio_hang)
    {
        try {
            $sql = "DELETE FROM `tb_gio_hang` WHERE id_gio_hang = :id_gio_hang";

            $stmt = $GLOBALS['conn']->prepare($sql);


            $stmt->bindParam(":id_gio_hang", $id_gio_hang);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

