<?php
if (!function_exists('showAll_danhgia_id')) {
    function showAll_danhgia_id($id)
    {
        try {
            $sql = "SELECT 
            tb_danh_gia.*, 
            tb_nguoi_dung.ten_nguoi_dung, 
            tb_san_pham.ten_san_pham, 
            tb_anh.anh, 
            tb_san_pham.ten_san_pham 
        FROM 
            `tb_nguoi_dung`
        INNER JOIN 
            tb_danh_gia ON tb_nguoi_dung.id_nguoi_dung = tb_danh_gia.id_nguoi_dung 
        INNER JOIN 
            tb_san_pham ON tb_danh_gia.id_san_pham = tb_san_pham.id_san_pham 
        INNER JOIN 
            tb_anh ON tb_anh.id_san_pham = tb_san_pham.id_san_pham 
        WHERE tb_san_pham.id_san_pham = :id  
        ORDER BY id_danh_gia DESC";

            $stmt = $GLOBALS['conn']->prepare($sql);

            // Sửa đoạn này để không có dấu : trước tên tham số
            $stmt->bindParam("id", $id);

            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
// model/danhgia.php
if (!function_exists('showOne_danhgia')) {
    function showOne_danhgia($id_san_pham)
    {
        try {
            $sql = "SELECT 
                        tb_danh_gia.*, 
                        tb_nguoi_dung.ten_nguoi_dung
                    FROM 
                        tb_danh_gia
                    INNER JOIN 
                        tb_nguoi_dung ON tb_nguoi_dung.id_nguoi_dung = tb_danh_gia.id_nguoi_dung
                    WHERE 
                        tb_danh_gia.id_san_pham = :id_san_pham
                    ORDER BY 
                        tb_danh_gia.id_danh_gia DESC
                    LIMIT 
                        1";

            $stmt = $GLOBALS['conn']->prepare($sql);
            $stmt->bindParam(":id_san_pham", $id_san_pham); // Bind giá trị vào tham số

            $stmt->execute();

            return $stmt->fetch(); // Trả về kết quả
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
