<?php
// model/chitiet_giohang.php
function updateChiTietGioHang($id_gio_hang, $id_san_pham, $soluong, $tong_tien)
{
    try {
        $sql = "UPDATE `tb_chitiet_giohang` SET so_luong = :soluong, tong_tien = :tong_tien WHERE id_gio_hang = :id_gio_hang AND id_san_pham = :id_san_pham";

        $stmt = $GLOBALS['conn']->prepare($sql);

        $stmt->bindParam(":id_gio_hang", $id_gio_hang);
        $stmt->bindParam(":id_san_pham", $id_san_pham);
        $stmt->bindParam(":soluong", $soluong);
        $stmt->bindParam(":tong_tien", $tong_tien);

        $stmt->execute();
    } catch (\Exception $e) {
        debug($e);
    }
}

if (!function_exists('showOneChiTietGioHang')) {
    function showOneChiTietGioHang($id_san_pham, $id_gio_hang)
    {
        try {
            $sql = "SELECT * FROM tb_chitiet_giohang WHERE id_san_pham = :id_san_pham AND id_gio_hang = :id_gio_hang LIMIT 1";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id_san_pham", $id_san_pham);
            $stmt->bindParam(":id_gio_hang", $id_gio_hang);

            $stmt->execute();

            return $stmt->fetch();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}

if (!function_exists('showListChiTietGioHang')) {
    function showListChiTietGioHang($id_gio_hang)
    {
        try {
            $sql = "SELECT tb_chitiet_giohang.*, tb_gio_hang.id_nguoi_dung, tb_san_pham.ten_san_pham, tb_san_pham.gia_ban,tb_san_pham.gia, tb_anh.anh
                    FROM tb_gio_hang 
                    INNER JOIN tb_chitiet_giohang ON tb_chitiet_giohang.id_gio_hang = tb_gio_hang.id_gio_hang 
                    INNER JOIN tb_san_pham ON tb_chitiet_giohang.id_san_pham = tb_san_pham.id_san_pham 
                    INNER JOIN tb_anh ON tb_anh.id_san_pham = tb_san_pham.id_san_pham 
                    WHERE tb_chitiet_giohang.id_gio_hang = :id_gio_hang 
                    ORDER BY tb_chitiet_giohang.id_chitiet_giohang DESC";

            $stmt = $GLOBALS['conn']->prepare($sql);
            $stmt->bindParam(":id_gio_hang", $id_gio_hang, PDO::PARAM_INT);
            $stmt->execute();

            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('getDetailCartByCartId')) {
    function getDetailCartByCartId($id_gio_hang)
    {
        try {
            $sql = "SELECT tb_chitiet_giohang.*,tb_san_pham.gia_ban
             FROM `tb_chitiet_giohang`
            INNER JOIN tb_san_pham ON tb_chitiet_giohang.id_san_pham=tb_san_pham.id_san_pham
             WHERE id_gio_hang = :id_gio_hang";

            $stmt = $GLOBALS['conn']->prepare($sql);

            $stmt->bindParam(":id_gio_hang", $id_gio_hang);

            $stmt->execute();

            // $data = $stmt->fetch();
            // if (empty($data)) { //chưa có bản ghi

            // }
            return $stmt->fetchAll();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('delete_giohang')) {
    function delete_giohang($id_chitiet_giohang)
    {
        try {
            $sql = "DELETE FROM `tb_chitiet_giohang` WHERE id_chitiet_giohang = :id_chitiet_giohang";

            $stmt = $GLOBALS['conn']->prepare($sql);


            $stmt->bindParam(":id_chitiet_giohang", $id_chitiet_giohang);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
if (!function_exists('update_giohang')) {
    function update_giohang($id, $data = [])
    {
        try {
            $setParams = get_set_params($data);

            $sql = "UPDATE `tb_chitiet_giohang` SET $setParams WHERE id_chitiet_giohang = :id";

            $stmt = $GLOBALS['conn']->prepare($sql);

            foreach ($data as $fieldName => &$value) {
                $stmt->bindParam(":$fieldName", $value);
            }

            $stmt->bindParam(":id", $id);

            $stmt->execute();
        } catch (\Exception $e) {
            debug($e);
        }
    }
}
