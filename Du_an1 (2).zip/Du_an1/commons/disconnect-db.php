<?php 

// Ngắt kết nối CSDL
$conn = null;