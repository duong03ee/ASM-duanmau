<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>




<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Danh sách bình luận</h1>
    <style>
        
    </style>
    <table class="table table-hover ">
    <thead class="thead-dark">
        <tr>
            <th>ID bình luận</th>
            <th>Ngày đăng</th>
            <th>Người bình luận</th>
            <th>Sản phẩm bình luận</th>
            <th>Tên sản phẩm</th>
            <th>Nội dung bình luận</th>
        </tr>
    </thead>
        <?php
        // var_dump($binhluan);
        foreach ($binhluan as $item) : ?>
            <tr>
                <td><?php echo $item['id_binh_luan']; ?></td>
                <td><?php echo $item['ngay_dang']; ?></td>
                <td><?= $item['ten_nguoi_dung']  ?></td>
                <td><img src="uploads/products/<?= $item['anh'] ?>" alt="" width="200px" height="200px"></td>
                <td><?= $item['ten_san_pham'] ?></td>
                <td><?php echo $item['noidung_binhluan']; ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
</div>
<?php
include "views/layout/footer.php";
?>