<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>

<!-- MAIN CHÍNH -->
<style>
    .container {
        font-family: Arial, sans-serif;
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background-color: #f4f4f4;
        border: 1px solid #e4e4e4;
        border-radius: 5px;
    }

    .page-title {
        margin-top: 0;
        padding-bottom: 10px;
        border-bottom: 1px solid #ccc;
    }

    .btn-back {
        display: inline-block;
        margin-bottom: 20px;
        text-decoration: none;
        color: white;
        background-color: #007bff;
        border: 1px solid #007bff;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .btn-back i {
        margin-right: 5px;
    }

    .button {
        margin-bottom: 20px;
        text-align: right;
    }

    .btn-primary {
        text-decoration: none;
        color: white;
        background-color: #007bff;
        border: 1px solid #007bff;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }

    .detail-info {
        padding: 20px;
        background-color: white;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .detail-row {
        margin-bottom: 15px;
    }

    .detail-label {
        font-weight: bold;
    }

    .detail-value {
        display: block;
        width: calc(100% - 160px);
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-top: 5px;
    }

    .actions {
        margin-top: 20px;
    }

    .actions a {
        margin-right: 10px;
    }

    .btn-danger {
        text-decoration: none;
        color: white;
        background-color: #dc3545;
        border: 1px solid #dc3545;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .btn-danger:hover {
        background-color: #c82333;
        border-color: #bd2130;
    }

    button[name="xacnhan"] {
        background-color: #4CAF50;
        color: white;
        padding: 5px 10px;
        /* Giảm padding để nút nhỏ lại */
        font-size: 14px;
        /* Điều chỉnh kích thước chữ */
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    button[name="xacnhan"]:hover {
        background-color: #45a049;
    }
</style>
<div class="container">
    <h1 class="page-title">Chi tiết liên hệ</h1>
    <a href="index.php?act=lienhe" class="btn btn-back"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <!-- <div class="button">
        <a href="<?= BASE_URL . '?act=themnguoidung' ?>" class="btn btn-primary" role="button">Thêm người dùng</a>
    </div> -->
    <div class="detail-info">
        <!-- <div class="detail-row">
            <label class="detail-label">ID:</label>
            <span class="detail-value"><?php echo $lienhe['id_lien_he']; ?></span>
        </div> -->
        <div class="detail-row">
            <label class="detail-label">Tên người gửi:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $lienhe['ten_nguoi_gui']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Email:</label> <br>
            <input type="email" class="detail-value" value="<?php echo $lienhe['email']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Số điện thoại:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $lienhe['sdt']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Tiêu đề:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $lienhe['tieu_de']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Ngày gửi:</label>
            <input type="date" class="detail-value" value="<?php echo $lienhe['ngay_gui']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Trạng thái:</label>
            <form action="?act=update_trangthai" name="trang_thai" method="POST">
                <input type="hidden" name="id_lien_he" value="<?php echo $lienhe['id_lien_he']; ?>">
                <label><input type="radio" name="trang_thai" value="Đã phản hồi" <?php if ($lienhe['trang_thai'] == 'Đã phản hồi') echo 'checked'; ?>> Đã phản hồi</label>
                <label><input type="radio" name="trang_thai" value="Chưa phản hồi" <?php if ($lienhe['trang_thai'] == 'Chưa phản hồi') echo 'checked'; ?>> Chưa phản hồi</label>
                <button type="submit" name="xacnhan">Xác nhận</button>
            </form>
        </div>

    </div>
</div>

<?php
include "views/layout/footer.php";
?>