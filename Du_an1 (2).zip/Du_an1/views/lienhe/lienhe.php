<?php
include "./views/layout/header.php";
include "./views/layout/menu.php";
?>



<!-- MAIN CHÍNH (CẦN SỬA) -->
<style>
    button[name="xacnhan"] {
        background-color: #4CAF50;
        color: white;
        padding: 5px 10px;
        /* Giảm padding để nút nhỏ lại */
        font-size: 14px;
        /* Điều chỉnh kích thước chữ */
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    button[name="xacnhan"]:hover {
        background-color: #45a049;
    }
</style>
<div class="container-fluid">
    <h1>Danh sách liên hệ</h1>
    <style>

    </style>
    <table class="table table-hover ">
        <thead class="thead-dark">
            <tr>
                <!-- <th>ID liên hệ</th> -->
                <th>STT</th>
                <th>Người gửi</th>
                <th>Sđt</th>
                <!-- <th>Email</th> -->
                <th>Tiêu đề</th>
                <!-- <th>Nội dung</th> -->
                <!-- <th>Ngày gửi</th> -->
                <th>Trạng thái</th>
                <th></th>
            </tr>
        </thead>
        <?php
        $stt=1;
        foreach ($lienhe as $item) {
        ?>
            <tr>
                <!-- <td><?php echo $item['id_lien_he']; ?></td> -->
                <td><?php echo $stt++; ?></td>
                <td><?php echo $item['ten_nguoi_gui']; ?></td>
                <td><?= $item['sdt'] ?></td>
                <!-- <td><?= $item['email'] ?></td> -->
                <td><?= $item['tieu_de'] ?></td>
                <!-- <td><?php echo $item['noi_dung']; ?></td> -->
                <!-- <td><?php echo $item['ngay_gui']; ?></td> -->
                <td>
                    <!-- <form action="?act=update_trangthai" name="trang_thai" method="POST">
                        <input type="hidden" name="id_lien_he" value="<?php echo $item['id_lien_he']; ?>">
                        <label><input type="radio" name="trang_thai" value="Đã phản hồi" <?php if ($item['trang_thai'] == 'Đã phản hồi') echo 'checked'; ?>> Đã phản hồi</label>
                        <label><input type="radio" name="trang_thai" value="Chưa phản hồi" <?php if ($item['trang_thai'] == 'Chưa phản hồi') echo 'checked'; ?>> Chưa phản hồi</label>
                        <br>
                        <button type="submit" name="xacnhan">Xác nhận</button>
                    </form> -->
                    <?php echo $item['trang_thai']; ?>
                </td>
                <td>
                    <a href="?act=chitietlienhe&id=<?php echo $item['id_lien_he']; ?>" class="btn btn-warning">Chi tiết</a>
                </td>
            </tr>
        <?php
        }
        ?>
    </table>
</div>





<?php
include "./views/layout/footer.php";
?>