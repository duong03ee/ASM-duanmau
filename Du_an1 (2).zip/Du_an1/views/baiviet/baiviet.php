<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>
<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Danh sách bài viết</h1>
    <br>
    <div class="button">
    <a href="<?= BASE_URL . '?act=thembaiviet' ?>" class="btn btn-success">Thêm bài viết</a>
</div>
<br>

    <table class="table table-hover">
    <thead class="thead-dark">
            <tr>
                <th>STT</th>
                <th>ID bài viết</th>
                <th>Tiêu đề</th>
                <!-- <th>Ảnh bài viết</th> -->
                <th>Ngày đăng</th>
                <th>Trạng thái</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $stt=1;
            foreach ($baiviet as $item) : ?>
                <tr>
                    <!-- <td><?php echo $item['id_bai_viet']; ?></td> -->
                    <td><?php echo $stt++; ?></td>
                    <td><?php echo $item['tieude_baiviet']; ?></td>
                    <!-- <td>
                        <img src="uploads/baiviet/<?php echo $item['anh_bai_viet']; ?>" width="200" height="200" alt="">
                    </td> -->
                    <td><?php echo $item['ngay_dang']; ?></td>
                    <td><?php echo $item['trang_thai']; ?></td>
                    <td>
                        <a href="?act=ctbaiviet&id=<?php echo $item['id_bai_viet']; ?>">
                            <button class="btn btn-warning btn-sm">Chi tiết</button>
                        </a>
                        <a href="?act=suabaiviet&id=<?php echo $item['id_bai_viet']; ?>">
                            <button class="btn btn-info btn-sm">Sửa</button>
                        </a>
                        <a href="?act=xoabaiviet&id=<?php echo $item['id_bai_viet']; ?>" onclick="return confirm('Bạn có chắc chắn muốn xoá bài viết này không?')">
                            <button class="btn btn-danger btn-sm">Xoá</button>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php
include "views/layout/footer.php";
?>
