<?php
include "./views/layout/header.php";
include "./views/layout/menu.php";
?>

<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Chi tiết bài viết</h1>
    <br>
    <a href="index.php?act=baiviet" onclick="history.go(-1); return false;"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <br><br>
    <form action="<?= BASE_URL . '?act=suabaiviet&id=' . $baiviet['id_bai_viet'] ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="tieude_baiviet">Tiêu đề bài viết</label>
            <input type="text" class="form-control" id="tieude_baiviet" name="tieude_baiviet" value="<?=$baiviet['tieude_baiviet']?>" readonly>
        </div>

        <div class="form-group">
    <label for="anh">Ảnh</label><br>
    <div style="display: inline-block; vertical-align: top;">
        <img src="uploads/baiviet/<?=$baiviet['anh_bai_viet']?>" alt="" width="200px" height="200px">
    </div>
   </div>

        <div class="form-group">
            <label for="noi_dung">Nội dung</label>
            <textarea class="form-control" name="noi_dung" id="noi_dung" cols="30" rows="10" readonly><?=$baiviet['noi_dung']?></textarea>
        </div>

        <div class="form-group">
            <label for="ngay_dang">Ngày đăng bài</label>
            <input type="date" class="form-control" id="ngay_dang" name="ngay_dang" value="<?=$baiviet['ngay_dang']?>" readonly>
        </div>

        <div class="form-group">
            <label for="trang_thai">Trạng thái</label>
            <select name="trang_thai" id="trang_thai" class="form-control" disabled>
                <option value="<?=$baiviet['trang_thai']?>"><?php echo $baiviet['trang_thai']; ?></option>
            </select>
        </div>

        <input type="hidden" name="id_bai_viet" value="<?= $baiviet['id_bai_viet'] ?>">
        <a href="index.php?act=suabaiviet&id=<?php echo $baiviet['id_bai_viet']; ?>">
        <button class="btn btn-info btn-md">Sửa</button></a>        
        <br><br>        
        
    </form>
    
</div>

<?php
include "./views/layout/footer.php";
?>
