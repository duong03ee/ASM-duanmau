<?php
include "./views/layout/header.php";
include "./views/layout/menu.php";
?>

<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Cập nhập bài viết</h1>
    <br>
    <a href="index.php?act=baiviet" onclick="history.go(-1); return false;"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <br><br>
    <form action="<?= BASE_URL . '?act=update_baiviet&id=' . $baiviet['id_bai_viet'] ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="tieude_baiviet">Tiêu đề bài viết</label>
            <input type="text" class="form-control" id="tieude_baiviet" name="tieude_baiviet" value="<?=$baiviet['tieude_baiviet']?>">
        </div>

        <div class="form-group">
    <label for="anh">Ảnh</label><br>
    
    <div style="display: inline-block; vertical-align: top; margin-left: 10px;">
        <input type="file" class="form-control-file" id="anh" name="anh">
    </div>
    <div style="display: inline-block; vertical-align: top;">
        <img src="uploads/baiviet/<?=$baiviet['anh_bai_viet']?>" alt="" width="200px" height="200px">
    </div>
   </div>

        <div class="form-group">
            <label for="noi_dung">Nội dung</label>
            <textarea class="form-control" name="noi_dung" id="noi_dung" cols="30" rows="10"><?=$baiviet['noi_dung']?></textarea>
        </div>

        <div class="form-group">
            <label for="ngay_dang">Ngày đăng bài</label>
            <input type="date" class="form-control" id="ngay_dang" name="ngay_dang" value="<?=$baiviet['ngay_dang']?>">
        </div>

        <div class="form-group">
            <label for="trang_thai">Trạng thái</label>
            <select name="trang_thai" id="trang_thai" class="form-control">
                <option value="Chưa được duyệt" <?= $baiviet['trang_thai'] == "Chưa được duyệt" ? "selected" : "" ?>>Chưa được duyệt</option>
                <option value="Đã duyệt" <?= $baiviet['trang_thai'] == "Đã duyệt" ? "selected" : "" ?>>Đã duyệt</option>
                <option value="Đã chỉnh sửa" <?= $baiviet['trang_thai'] == "Đã chỉnh sửa" ? "selected" : "" ?>>Đã chỉnh sửa</option>
            </select>
        </div>

        <input type="hidden" name="id_bai_viet" value="<?= $baiviet['id_bai_viet'] ?>">
        <button type="submit" class="btn btn-primary" name="sua">Cập nhật</button>
        <br><br>
        <button type="reset" class="btn btn-primary"><i class="fas fa-sync reset-icon" onclick="resetForm()"></i></button>
        
        
    </form>
    
</div>

<?php
include "./views/layout/footer.php";
?>
