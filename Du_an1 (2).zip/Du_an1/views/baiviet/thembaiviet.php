<?php
include "./views/layout/header.php";
include "./views/layout/menu.php";
?>

<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Thêm bài viết</h1>
    <br>
    <a href="index.php?act=baiviet" onclick="history.go(-1); return false;"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <br><br>
    <form action="<?= BASE_URL . '?act=create_baiviet'?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="tieude_baiviet">Tiêu đề bài viết</label>
            <input type="text" class="form-control" id="tieude_baiviet" name="tieude_baiviet">
        </div>

        <div class="form-group">
            <label for="anh_bai_viet">Ảnh bài viết</label>
            <input type="file" class="form-control-file" id="anh_bai_viet" name="anh_bai_viet">
        </div>

        <div class="form-group">
            <label for="noi_dung">Nội dung</label>
            <textarea name="noi_dung" id="noi_dung" class="form-control" cols="30" rows="10"></textarea>
        </div>

        <div class="form-group">
            <label for="ngay_dang">Ngày đăng</label>
            <input type="date" class="form-control" id="ngay_dang" name="ngay_dang">
        </div>

        <div class="form-group">
            <label for="trang_thai">Trạng thái</label>
            <select name="trang_thai" id="trang_thai" class="form-control">
                <option value="Chưa được duyệt">Chưa được duyệt</option>
                <option value="Đã duyệt">Đã duyệt</option>
                <option value="Đã chỉnh sửa">Đã chỉnh sửa</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary" name="them">Thêm</button>
        <br>
        <br>
        <button type="reset" class="btn btn-primary"><i class="fas fa-sync reset-icon" onclick="resetForm()"></i></button>
        
    </form>

   
</div>

<?php
include "./views/layout/footer.php";
?>
