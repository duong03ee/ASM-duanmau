<?php
include "./views/layout/header.php";
include "./views/layout/menu.php";
?>

<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Thêm danh mục</h1>
    <br>
    <a href="index.php?act=danhmuc" onclick="history.go(-1); return false;"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <br><br>
    <form action="<?= BASE_URL . '?act=create_danhmuc' ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="ten_danh_muc">Tên danh mục</label>
            <input type="text" class="form-control" id="ten_danh_muc" name="ten_danh_muc">
        </div>

        
        <button type="submit" class="btn btn-primary" name="them">Thêm</button>
        <br><br>
        <button type="reset" class="btn btn-primary"><i class="fas fa-sync reset-icon" onclick="resetForm()"></i></button>
    </form>
</div>

<?php
include "./views/layout/footer.php";
?>
