<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>

<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Danh sách chức vụ</h1><br>
    <a href="<?= BASE_URL . '?act=themdanhmuc' ?>" class="btn btn-success">Thêm danh mục</a>
    <br><br>
    <table class="table table-hover">
    <thead class="thead-dark">
            <tr>
                <!-- <th>ID danh mục</th> -->
                <th>STT</th>
                <th>Tên danh mục</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $stt=1;
            foreach ($danhmuc as $item) : ?>
                <tr>
                    <!-- <td><?php echo $item['id_danh_muc']; ?></td> -->
                    <td><?php echo $stt++; ?></td>
                    <td><?php echo $item['ten_danh_muc']; ?></td>
                    <td>
                        <a href="?act=suadanhmuc&id=<?php echo $item['id_danh_muc']; ?>" class="btn btn-info">Sửa</a>
                        <a href="?act=xoadanhmuc&id=<?php echo $item['id_danh_muc']; ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xoá danh mục này không?')">Xoá</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <div class="button">
        <a href="<?= BASE_URL . '?act=xoaAlldanhmuc' ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xoá tất cả danh mục không?')">Xoá tất cả</a>

    </div>
</div>

<?php
include "views/layout/footer.php";
?>
