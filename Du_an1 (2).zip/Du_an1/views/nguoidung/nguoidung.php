<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>

<!-- MAIN CHÍNH -->
<div class="container-fluid">
    <h1>Danh sách người dùng</h1>
    <div class="button">
        <!-- <a href="<?= BASE_URL . '?act=themnguoidung' ?>" class="btn btn-success">Thêm người dùng</a> -->
    </div>
    <br>
    <table class="table table-hover">
        <thead class="thead-dark">
            <tr>
                <th>STT</th>
                <th>Tên người dùng</th>
                <th>Email</th>
                <th>Chức vụ</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $stt=1;
            foreach ($nguoidung as $item) : ?>
                <tr>
                    <!-- <td><?php echo $item['id_nguoi_dung']; ?></td> -->
                    <td><?php echo $stt++; ?></td>
                    <td><?php echo $item['ten_nguoi_dung']; ?></td>
                    <td><?php echo $item['email']; ?></td>
                    <td><?php echo $item['ten_chuc_vu']; ?></td>
                    <td>
                        <a href="?act=ctnguoidung&id=<?php echo $item['id_nguoi_dung']; ?>" class="btn btn-warning btn-sm">Chi tiết</a>
                        <a href="?act=suanguoidung&id=<?php echo $item['id_nguoi_dung']; ?>" class="btn btn-info btn-sm">Sửa</a>
                        <?php if ($item['id_chuc_vu'] != 1) : ?>
                            <a href="?act=xoanguoidung&id=<?php echo $item['id_nguoi_dung']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xoá người dùng này không?')">Xoá</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</div>

<?php
include "views/layout/footer.php";
?>