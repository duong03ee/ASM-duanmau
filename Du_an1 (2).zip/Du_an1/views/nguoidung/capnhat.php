<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>





<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Cập nhật người dùng</h1>
    <a href="index.php?act=nguoidung" onclick="history.go(-1); return false;"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <br><br>
    <form action="<?= BASE_URL . '?act=update_nguoidung&id=' .$nguoidung['id_nguoi_dung'] ?>" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3 mt-3">
                            <label for="user" class="form-label">Tên đăng nhập:</label>
                            <input type="text" class="form-control" id="user" value="<?= $nguoidung['ten_nguoi_dung'] ?>" name="user">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="diachi" class="form-label">Địa chỉ:</label>
                            <input type="text" class="form-control" id="diachi" value="<?= $nguoidung['dia_chi'] ?>" name="diachi">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" class="form-control" id="email" value="<?= $nguoidung['email'] ?>" name="email">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="gioitinh" class="form-label">Giới tính:</label>
                            <select name="gioitinh" id="gioitinh" class="form-control">
                                <option <?= $nguoidung['gioi_tinh'] == "Nữ "? 'selected' : null ?> value="Nữ">Nữ</option>
                                <option <?= $nguoidung['gioi_tinh'] == "Nam" ? 'selected' : null ?> value="Nam">Nam</option>
                            </select>
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="ngaysinh" class="form-label">Ngày sinh:</label>
                            <input type="date" class="form-control" name="ngaysinh" id="ngaysinh" value="<?= $nguoidung['ngay_sinh'] ?>">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="sdt" class="form-label">Số điện thoại:</label>
                            <input type="text" class="form-control" id="sdt" name="sdt" value="<?= $nguoidung['sdt'] ?>">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="matkhau" class="form-label">Mật khẩu:</label>
                            <input type="password" class="form-control" id="matkhau" name="matkhau" value="<?= $nguoidung['mat_khau'] ?>">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="chucvu" class="form-label">Chức vụ:</label>
                            <select name="chucvu" id="chucvu" class="form-control">
                                <?php foreach ($chucvu as $cv) : ?>
                                    <option value="<?= $cv['id_chuc_vu'] ?>" <?= ($cv['id_chuc_vu'] == $nguoidung['id_chuc_vu']) ? 'selected' : '' ?>><?= $cv['ten_chuc_vu'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            </div>

                    </div>
                </div>
                <input type="hidden" name="id_nguoi_dung" value="<?= $nguoidung['id_nguoi_dung'] ?>">
                <button type="submit" class="btn btn-primary" name="sua">Sửa</button>
                <br><br>
        <button type="reset" class="btn btn-primary"><i class="fas fa-sync reset-icon" onclick="resetForm()"></i></button>
  
            </form>

</div>
</div>


<?php
include "views/layout/footer.php";
?>