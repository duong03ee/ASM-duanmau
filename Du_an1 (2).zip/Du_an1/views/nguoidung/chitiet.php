<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>

<!-- MAIN CHÍNH -->
<style>
    .container {
        font-family: Arial, sans-serif;
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background-color: #f4f4f4;
        border: 1px solid #e4e4e4;
        border-radius: 5px;
    }

    .page-title {
        margin-top: 0;
        padding-bottom: 10px;
        border-bottom: 1px solid #ccc;
    }

    .btn-back {
        display: inline-block;
        margin-bottom: 20px;
        text-decoration: none;
        color: white;
        background-color: #007bff;
        border: 1px solid #007bff;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .btn-back i {
        margin-right: 5px;
    }

    .button {
        margin-bottom: 20px;
        text-align: right;
    }

    .btn-primary {
        text-decoration: none;
        color: white;
        background-color: #007bff;
        border: 1px solid #007bff;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }

    .detail-info {
        padding: 20px;
        background-color: white;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .detail-row {
        margin-bottom: 15px;
    }

    .detail-label {
        font-weight: bold;
    }

    .detail-value {
        display: block;
        width: calc(100% - 160px);
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-top: 5px;
    }

    .actions {
        margin-top: 20px;
    }

    .actions a {
        margin-right: 10px;
    }

    .btn-danger {
        text-decoration: none;
        color: white;
        background-color: #dc3545;
        border: 1px solid #dc3545;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .btn-danger:hover {
        background-color: #c82333;
        border-color: #bd2130;
    }
</style>
<div class="container">
    <h1 class="page-title">Chi tiết người dùng</h1>
    <a href="index.php?act=nguoidung" class="btn btn-back"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <!-- <div class="button">
        <a href="<?= BASE_URL . '?act=themnguoidung' ?>" class="btn btn-primary" role="button">Thêm người dùng</a>
    </div> -->
    <div class="detail-info">
        <!-- <div class="detail-row">
            <label class="detail-label">ID:</label>
            <span class="detail-value"><?php echo $nguoidung['id_nguoi_dung']; ?></span>
        </div> -->
        <div class="detail-row">
            <label class="detail-label">Tên người dùng:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $nguoidung['ten_nguoi_dung']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Địa chỉ:</label> <br>
            <input type="email" class="detail-value" value="<?php echo $nguoidung['email']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Giới tính:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $nguoidung['gioi_tinh']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Ngày sinh:</label> <br>
            <input type="date" class="detail-value" value="<?php echo $nguoidung['ngay_sinh']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Mật khẩu:</label>
            <input type="text" class="detail-value" value="<?php echo $nguoidung['mat_khau']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Số điện thoại:</label>
            <input type="text" class="detail-value" value="<?php echo $nguoidung['sdt']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Chức vụ:</label>
            <span class="detail-value"><?php echo $nguoidung['ten_chuc_vu']; ?></span>
        </div>

        <div class="actions">
            <a href="?act=suanguoidung&id=<?php echo $nguoidung['id_nguoi_dung']; ?>" class="btn btn-primary" role="button">Sửa</a>
            <?php
            if(!$nguoidung['id_chuc_vu']=="1"){
                ?>
                <a href="?act=xoanguoidung&id=<?php echo $nguoidung['id_nguoi_dung']; ?>" class="btn btn-danger" role="button" onclick="return confirm('Bạn có chắc chắn muốn xoá người dùng này không?')">Xoá</a>
                <?php
            }
            ?>
        </div>
    </div>
</div>

<?php
include "views/layout/footer.php";
?>