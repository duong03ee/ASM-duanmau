<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>





<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Thêm khuyến mãi</h1>
    <a href="index.php?act=khuyenmai" onclick="history.go(-1); return false;"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <br>
    <form action="<?= BASE_URL . '?act=create_khuyenmai' ?>" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3 mt-3">
                            <label for="" class="form-label">Tên khuyến mãi:</label>
                            <input type="text" class="form-control" id="tenkhuyenmai" name="tenkhuyenmai">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="makhuyenmai" class="form-label">Mã khuyến mãi:</label>
                            <input type="text" class="form-control" id="makhuyenmai"  name="makhuyenmai">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="" class="form-label">Mô tả:</label>
                            <input type="text" class="form-control" id="mota" name="mota">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="" class="form-label">Mức giảm giá:</label>
                            <input type="text" class="form-control"  min="0"  name="mucgiamgia">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="" class="form-label">Ngày bắt đầu:</label>
                            <input type="date" class="form-control" id="ngaybatdau" name="ngaybatdau">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="" class="form-label">Ngày hết hạn:</label>
                            <input type="date" class="form-control" id="ngayhethan" name="ngayhethan">
                        </div>
                        <!-- <div class="mb-3 mt-3">
                            <label for="" class="form-label">Trạng thái:</label>
                            <select name="trangthai" id="trangthai" class="form-control">
                                <option value="Hết">Hết</option>
                                <option value="Còn">Còn</option>
                        </select> -->

                        <!-- <input type="hidden"  name="trang_thai" value=""> -->
                        <div class="mb-3 mt-3">
                            <label for="" class="form-label">Số lượng:</label>
                            <input type="number" class="form-control"  min="0" name="soluong">
                        </div>

                    </div>
                </div>
                 
                <button type="submit" style="margin-left: 25px;" class="btn btn-primary" name="them">Thêm khuyến mãi</button>
                <br><br>
        <button type="reset" style="margin-left: 25px;" class="btn btn-primary"><i class="fas fa-sync reset-icon" onclick="resetForm()"></i></button>
                

            </form>

</div>
</div>


<?php
include "views/layout/footer.php";
?>