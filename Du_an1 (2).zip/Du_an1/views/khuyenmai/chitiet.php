<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>

<!-- MAIN CHÍNH -->
<style>
    .container {
  font-family: Arial, sans-serif;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f4f4f4;
  border: 1px solid #e4e4e4;
  border-radius: 5px;
}

.page-title {
  margin-top: 0;
  padding-bottom: 10px;
  border-bottom: 1px solid #ccc;
}

.btn-back {
  display: inline-block;
  margin-bottom: 20px;
  text-decoration: none;
  color: white;
  background-color: #007bff;
  border: 1px solid #007bff;
  padding: 8px 12px;
  border-radius: 5px;
}

.btn-back i {
  margin-right: 5px;
}

.button {
  margin-bottom: 20px;
  text-align: right;
}

.btn-primary {
  text-decoration: none;
  color: white;
  background-color: #007bff;
  border: 1px solid #007bff;
  padding: 8px 12px;
  border-radius: 5px;
}

.btn-primary:hover {
  background-color: #0056b3;
  border-color: #0056b3;
}

.detail-info {
  padding: 20px;
  background-color: white;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.detail-row {
  margin-bottom: 15px;
}

.detail-label {
  font-weight: bold;
}

.detail-value {
  display: block;
  width: calc(100% - 160px);
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 5px;
  margin-top: 5px;
}

.actions {
  margin-top: 20px;
}

.actions a {
  margin-right: 10px;
}

.btn-danger {
  text-decoration: none;
  color: white;
  background-color: #dc3545;
  border: 1px solid #dc3545;
  padding: 8px 12px;
  border-radius: 5px;
}

.btn-danger:hover {
  background-color: #c82333;
  border-color: #bd2130;
}

</style>
<div class="container">
    <h1 class="page-title">Chi tiết khuyến mãi</h1>
    <a href="index.php?act=khuyenmai" class="btn btn-back"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <div class="button">
        <a href="<?= BASE_URL . '?act=themkhuyenmai' ?>" class="btn btn-primary" role="button">Thêm khuyến mãi</a>
    </div>
    <div class="detail-info">
        <!-- <div class="detail-row">
            <label class="detail-label">ID:</label>
            <span class="detail-value"><?php echo $khuyenmai['id_khuyen_mai']; ?></span>
        </div> -->
        <div class="detail-row">
            <label class="detail-label">Tên khuyến mãi:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $khuyenmai['ten_khuyen_mai']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Mã khuyến mãi:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $khuyenmai['ma_khuyen_mai']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Mô tả:</label> <br>
            <textarea class="detail-value" readonly><?php echo $khuyenmai['mo_ta']; ?></textarea>
        </div>
        <div class="detail-row">
            <label class="detail-label">Mức giảm giá:</label>
            <span class="detail-value"><?php echo $khuyenmai['muc_giam_gia']; ?></span>


        </div>
        <div class="detail-row">
            <label class="detail-label">Ngày bắt đầu:</label>
            <input type="date" class="detail-value" value="<?php echo $khuyenmai['ngay_bat_dau']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Ngày hết hạn:</label>
            <input type="date" class="detail-value" value="<?php echo $khuyenmai['ngay_het_han']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Trạng thái:</label>
            <span class="detail-value"><?php echo $khuyenmai['trang_thai'] ?></span>
        </div>
        <div class="detail-row">
            <label class="detail-label">Số lượng:</label>
            <span class="detail-value"><?php echo $khuyenmai['so_luong']; ?></span>
        </div>

        <div class="actions">
            <a href="?act=suakhuyenmai&id=<?php echo $khuyenmai['id_khuyen_mai']; ?>" class="btn btn-primary" role="button">Sửa</a>
            <a href="?act=xoakhuyenmai&id=<?php echo $khuyenmai['id_khuyen_mai']; ?>" class="btn btn-danger" role="button" onclick="return confirm('Bạn có chắc chắn muốn xoá nội dung này không?')">Xoá</a>
        </div>
    </div>
</div>

<?php
include "views/layout/footer.php";
?>