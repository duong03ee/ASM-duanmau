<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>

<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Danh sách khuyến mãi</h1>
    <div class="button">
        <a href="<?= BASE_URL . '?act=themkhuyenmai' ?>" class="btn btn-success">Thêm khuyến mãi</a>
    </div>
    <br><br>
    <table class="table table-hover">
    <thead class="thead-dark">
            <tr>
                <!-- <th>ID</th> -->
                <th>STT</th>
                <th>Tên khuyến mãi</th>
                <th>Mã khuyến mãi</th>
                <th>Mức giảm giá</th>
                <!-- <th>Trạng thái</th> -->
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $stt=1;
            foreach ($khuyenmai as $item) : ?>
                <tr>
                    <td><?php echo $stt++; ?></td>
                    <!-- <td><?php echo $item['id_khuyen_mai']; ?></td> -->
                    <td><?php echo $item['ten_khuyen_mai']; ?></td>
                    <td><?php echo $item['ma_khuyen_mai']; ?></td>
                    <td><?php echo $item['muc_giam_gia']; ?></td>
                    <!-- <td><?php echo $item['trang_thai']; ?></td> -->
                    <td>
                        <a href="?act=ctkhuyenmai&id=<?php echo $item['id_khuyen_mai']; ?>" class="btn btn-warning">Chi tiết</a>
                        <a href="?act=suakhuyenmai&id=<?php echo $item['id_khuyen_mai']; ?>" class="btn btn-info">Sửa</a>
                        <a href="?act=xoakhuyenmai&id=<?php echo $item['id_khuyen_mai']; ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xoá khuyến mãi này không?')">Xoá</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
</div>

<?php
include "views/layout/footer.php";
?>
