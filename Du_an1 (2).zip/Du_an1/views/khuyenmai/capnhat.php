<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>





<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Cập nhật khuyến mãi</h1><br>
    <a href="index.php?act=khuyenmai" onclick="history.go(-1); return false;"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <br><br>
    <form action="<?= BASE_URL . '?act=update_khuyenmai&id=' .$khuyenmai['id_khuyen_mai']?>" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3 mt-3">
                            <label for="" class="form-label">Tên khuyến mãi:</label>
                            <input type="text" class="form-control" id="tenkhuyenmai" name="tenkhuyenmai" value="<?= $khuyenmai['ten_khuyen_mai'] ?>">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="makhuyenmai" class="form-label">Mã khuyến mãi:</label>
                            <input type="text" class="form-control" id="makhuyenmai"  name="makhuyenmai" value="<?= $khuyenmai['ma_khuyen_mai'] ?>">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="" class="form-label">Mô tả:</label>
                            <input type="text" class="form-control" id="mota" name="mota" value="<?= $khuyenmai['mo_ta'] ?>">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="" class="form-label">Mức giảm giá:</label>
                            <input type="text" class="form-control" name="mucgiamgia" value="<?= $khuyenmai['muc_giam_gia'] ?>">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="" class="form-label">Ngày bắt đầu:</label>
                            <input type="date" class="form-control" id="ngaybatdau" name="ngaybatdau" value="<?= $khuyenmai['ngay_bat_dau'] ?>">
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="" class="form-label">Ngày hết hạn:</label>
                            <input type="date" class="form-control" id="ngayhethan" name="ngayhethan" value="<?= $khuyenmai['ngay_het_han'] ?>">
                        </div>
                        <!-- <div class="mb-3 mt-3">
                            <label for="" class="form-label">Trạng thái:</label>
                            <select name="trangthai" id="trangthai" class="form-control">
                                <option <?= $khuyenmai['trang_thai'] == "Hết" ? 'selected' : null ?> value="Hết">Hết</option>
                                <option <?= $khuyenmai['trang_thai'] == "Còn" ? 'selected' : null ?> value="Còn">Còn</option>
                        </select> -->
                        <div class="mb-3 mt-3">
                            <label for="" class="form-label">Số lượng:</label>
                            <input type="number" class="form-control"  min="0" name="soluong" value="<?= $khuyenmai['so_luong'] ?>">
                        </div>
                        </div>

                    </div>
                </div>
                <input type="hidden" name="id_khuyen_mai" value="<?=$khuyenmai['id_khuyen_mai'] ?>"> 
                <button type="submit" class="btn btn-primary" name="sua">Cập nhật</button>
                <br><br>
        <button type="reset" class="btn btn-primary"><i class="fas fa-sync reset-icon" onclick="resetForm()"></i></button>
            </form>

</div>
</div>


<?php
include "views/layout/footer.php";
?>