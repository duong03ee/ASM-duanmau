<?php
include "./views/layout/header.php";
include "./views/layout/menu.php";
?>

<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Thêm chức vụ</h1>
    <br>
    <a href="index.php?act=chucvu" onclick="history.go(-1); return false;"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <br><br>
    <form action="<?= BASE_URL . '?act=create_chucvu' ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="ten_chuc_vu">Tên chức vụ</label>
            <input type="text" class="form-control" id="ten_chuc_vu" name="ten_chuc_vu">
        </div>

        <div class="form-group">
            <label for="mo_ta">Mô tả</label>
            <input type="text" class="form-control" id="mo_ta" name="mo_ta">
        </div>
        <button type="submit" class="btn btn-primary" name="them">Thêm</button>
        <br><br><button type="reset" class="btn btn-danger"><i class="fas fa-sync reset-icon" onclick="resetForm()"></i></button>
       
    </form>

</div>

<?php
include "./views/layout/footer.php";
?>
