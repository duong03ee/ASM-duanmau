<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>

<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Danh sách chức vụ</h1>
    <br><a href="<?= BASE_URL . '?act=themchucvu' ?>" class="btn btn-success">Thêm chức vụ</a>
    <br><br>
    <table class="table table-hover">
    <thead class="thead-dark">
            <tr>
                <th>STT</th>
                <th>Tên chức vụ</th>
                <th>Mô tả</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $stt=1;
            foreach ($chucvu as $item) : ?>
                <tr>
                    <td><?php echo $stt++; ?></td>
                    <!-- <td><?php echo $item['id_chuc_vu']; ?></td> -->
                    <td><?php echo $item['ten_chuc_vu']; ?></td>
                    <td><?php echo $item['mo_ta']; ?></td>
                    <td>
                        <a href="?act=suachucvu&id=<?php echo $item['id_chuc_vu']; ?>" class="btn btn-info">Sửa</a>
                        <!-- <a href="?act=xoachucvu&id=<?php echo $item['id_chuc_vu']; ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xoá chức vụ này không?')">Xoá</a> -->
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <div class="button">
        <!-- <a href="<?= BASE_URL . '?act=xoaAllchucvu' ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xoá tất cả chức vụ không?')">Xoá tất cả</a> -->
        
    </div>
</div>

<?php
include "views/layout/footer.php";
?>
