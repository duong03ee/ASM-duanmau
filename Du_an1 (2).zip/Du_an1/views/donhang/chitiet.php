<?php
// var_dump($donhang);die;
include "views/layout/header.php";
include "views/layout/menu.php";
?>

<!-- MAIN CHÍNH -->
<style>
    .container {
        font-family: Arial, sans-serif;
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background-color: #f4f4f4;
        border: 1px solid #e4e4e4;
        border-radius: 5px;
    }

    .page-title {
        margin-top: 0;
        padding-bottom: 10px;
        border-bottom: 1px solid #ccc;
    }

    .btn-back {
        display: inline-block;
        margin-bottom: 20px;
        text-decoration: none;
        color: white;
        background-color: #007bff;
        border: 1px solid #007bff;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .btn-back i {
        margin-right: 5px;
    }

    .button {
        margin-bottom: 20px;
        text-align: right;
    }

    .btn-primary {
        text-decoration: none;
        color: white;
        background-color: #007bff;
        border: 1px solid #007bff;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }

    .detail-info {
        padding: 20px;
        background-color: white;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .detail-row {
        margin-bottom: 15px;
    }

    .detail-label {
        font-weight: bold;
    }

    .detail-value {
        display: block;
        width: calc(100% - 160px);
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-top: 5px;
    }

    .actions {
        margin-top: 20px;
    }

    .actions a {
        margin-right: 10px;
    }

    .btn-danger {
        text-decoration: none;
        color: white;
        background-color: #dc3545;
        border: 1px solid #dc3545;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .btn-danger:hover {
        background-color: #c82333;
        border-color: #bd2130;
    }

    button[name="xacnhan"] {
        background-color: #4CAF50;
        color: white;
        padding: 5px 10px;
        /* Giảm padding để nút nhỏ lại */
        font-size: 14px;
        /* Điều chỉnh kích thước chữ */
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    button[name="xacnhan"]:hover {
        background-color: #45a049;
    }

    form {
        display: flex;
        align-items: center;
    }

    select {
        padding: 5px;
        margin-right: 10px;
    }

    button {
        padding: 5px 10px;
        background-color: #4CAF50;
        color: white;
        border: none;
        cursor: pointer;
    }

    button:hover {
        background-color: #45a049;
    }

    /* Style for the select element */
    select {
        padding: 10px;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 5px;
        background-color: #f7f7f7;
        width: 300px;
    }

    /* Style for the options */
    select option {
        padding: 10px;
        font-size: 16px;
        color: #333;
    }
</style>
<div class="container">
    <h1 class="page-title">Chi tiết đơn hàng</h1>
    <a href="index.php?act=donhang" class="btn btn-back"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <div class="detail-info">
        <div class="detail-row">
            <label class="detail-label">Ảnh sản phẩm:</label> <br>
            <img src="uploads/products/<?= $donhang['anh'] ?>" width="150" height="150" alt="">
        </div>
        <div class="detail-row">
            <label class="detail-label">Tên sản phẩm:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $donhang['ten_san_pham']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Đơn giá:</label> <br>
            <input type="text" class="detail-value" value="đ<?php echo number_format($donhang['gia_ban']); ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Số lượng:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $donhang['so_luong']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Phương thức thanh toán:</label>
            <input type="text" class="detail-value" value="<?php echo $donhang['phuongthuc_thanhtoan']; ?>" readonly>
        </div>
        <?php if ($donhang['phuongthuc_thanhtoan'] == 'momo') : ?>
            <div class="detail-row">
                <label class="detail-label">Mã giao dịch:</label>
                <input type="text" class="detail-value" value="#<?php echo $donhang['ma_giao_dich']; ?>" readonly>
            </div>
        <?php endif; ?>
        <div class="detail-row">
            <label class="detail-label">Mã khuyến mãi:</label>
            <input type="text" class="detail-value" value="<?php echo $donhang['ma_khuyen_mai']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Mức giảm giá:</label>
            <input type="text" class="detail-value" value="đ<?php echo number_format($donhang['muc_giam_gia']); ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Trạng thái:</label>
            <form action="?act=update_ttdonhang" name="trangthai_donhang" method="POST">
                <input type="hidden" name="id_don_hang" value="<?php echo $donhang['id_don_hang']; ?>">
                <select name="trangthai_donhang" id="">
                    <?php foreach ($ttdonhang as $tt) : ?>
                        <?php if ($tt['id_trangthai_donhang'] != 4) { ?>
                            <?php if ($donhang['id_trangthai_donhang'] == 3) : ?>
                                <!-- Hiển thị các trạng thái đơn hàng lớn hơn hoặc bằng 3 nếu đơn hàng có trạng thái 3 -->
                                <?php if ($tt['id_trangthai_donhang'] >= 3) : ?>
                                    <option value="<?php echo $tt['id_trangthai_donhang'] ?>" <?php if ($tt['id_trangthai_donhang'] == $donhang['id_trangthai_donhang']) echo 'selected'; ?>><?php echo $tt['trangthai_donhang'] ?></option>
                                <?php endif; ?>
                            <?php elseif ($donhang['id_trangthai_donhang'] == 5 || $donhang['id_trangthai_donhang'] == 1 || $donhang['id_trangthai_donhang'] == 2) : ?>
                                <!-- Hiển thị tất cả các trạng thái đơn hàng nếu đơn hàng có trạng thái là 5, 1, hoặc 2 -->
                                <option value="<?php echo $tt['id_trangthai_donhang'] ?>" <?php if ($tt['id_trangthai_donhang'] == $donhang['id_trangthai_donhang']) echo 'selected'; ?>><?php echo $tt['trangthai_donhang'] ?></option>
                            <?php endif; ?>
                        <?php
                        } else {
                        ?>
                            <option value="<?php echo $tt['id_trangthai_donhang']==4 ?>"><?php echo $tt['trangthai_donhang'] ?></option>
                        <?php
                        }; ?>
                    <?php endforeach; ?>
                </select>
                <button type="submit" name="xacnhan">Cập nhật</button>
            </form>
        </div>
        <div class="detail-row">
            <label class="detail-label">Tổng tiền:</label>
            <input type="text" class="detail-value" value="đ<?php echo number_format($donhang['tong_tien']); ?>" readonly>
        </div>
        <label class="detail-label" style="font-size: 25px; margin: 20px;">Thông tin người nhận</label>
        <br>
        <div class="detail-row">
            <label class="detail-label">Tên người nhận:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $donhang['ten_nguoi_nhan']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Số điện thoại:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $donhang['sdt_nguoi_nhan']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Email:</label> <br>
            <input type="email" class="detail-value" value="<?php echo $donhang['email']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Địa chỉ nhận hàng:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $donhang['diachi_nhanhang']; ?>" readonly>
        </div>


    </div>
</div>
<!-- <div class="container">
<div class="detail-info">
    <div class="detail-row">
            <label class="detail-label">Đơn giá:</label>
            <input type="text" class="detail-value" value="<?php echo $sanpham['gia_ban']; ?>" readonly>
    </div>
    <div class="detail-row">
            <label class="detail-label">Số lượng:</label>
            <input type="text" class="detail-value" value="<?php echo $sanpham['so_luong']; ?>" readonly>
    </div>
        <div class="detail-row">
            <label class="detail-label">Tổng tiền:</label>
            <div class="input-group">
                <input type="number" class="form-control" value="<?php echo $donhang['tong_tien']; ?>" readonly>
                <div class="input-group-append">
                    <span class="input-group-text">VNĐ</span>
                </div>
            </div>
        </div>
    </div>
    </div>
</div> -->

<?php
include "views/layout/footer.php";
?>