<?php
include "./views/layout/header.php";
include "./views/layout/menu.php";
?>



<!-- MAIN CHÍNH (CẦN SỬA) -->
<style>
    button[name="xacnhan"] {
        background-color: #4CAF50;
        color: white;
        padding: 5px 10px;
        /* Giảm padding để nút nhỏ lại */
        font-size: 14px;
        /* Điều chỉnh kích thước chữ */
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    button[name="xacnhan"]:hover {
        background-color: #45a049;
    }


    .trangthai {
        text-decoration: underline;
        text-align: center;
        color: white;
        background-color: #23A9F2;
        border-radius: 5px;
        margin: 7px 0;
    }
</style>
<div class="container-fluid">
    <h1>Danh sách đơn hàng</h1>
    <style>

    </style>
    <table class="table table-hover ">
        <thead class="thead-dark">
            <tr>
                <th>STT</th>
                <th>Mã đơn hàng</th>
                <th>Tên người nhận</th>
                <th>Sđt</th>
                <th>Địa chỉ nhận hàng</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th></th>
            </tr>
        </thead>
        <?php
        $stt = 1;
        foreach ($donhang as $item) {
        ?>
            <tr>
                <td><?php echo $stt++; ?></td>
                <td>#<?php echo $item['id_don_hang']; ?></td>
                <td><?php echo $item['ten_nguoi_nhan']; ?></td>
                <td><?= $item['sdt_nguoi_nhan'] ?></td>
                <td><?= $item['diachi_nhanhang'] ?></td>
                <td><?php echo $item['tong_tien']; ?></td>
                <td >
                    <p class="trangthai"><?php echo $item['trangthai_donhang']; ?></p>
                </td>
                <td>
                    <a href="?act=chitietdonhang&id_don_hang=<?php echo $item['id_don_hang']; ?>" class="btn btn-warning">Chi tiết</a>
                </td>
            </tr>
        <?php
        }
        ?>
    </table>
</div>





<?php
include "./views/layout/footer.php";
?>