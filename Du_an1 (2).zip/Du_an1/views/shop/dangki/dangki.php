<?php
include "views/shop/layoutshop/header.php";
include "views/shop/layoutshop/menu.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>ADMIN - KING CLOTHES</title>

    <!-- Custom fonts for this template-->
    <link href="assets/admin/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="assets/admin/css/sb-admin-2.min.css" rel="stylesheet">

</head>
<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <!-- Outer Row -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        Đăng kí
                    </div>
                    <div class="card-body">
                        <form action="<?= BASE_URL . '?act=dangki' ?>" method="post">
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="ho_ten">Họ và tên:</label>
                                <input type="text" class="form-control" id="ho_ten" name="ho_ten" required>
                            </div>
                            <div class="form-group">
                                <label for="mat_khau">Mật khẩu:</label>
                                <input type="password" class="form-control" id="mat_khau" name="mat_khau" required>
                            </div>
                            <div class="form-group">
                                <label for="sdt">Số điện thoại:</label>
                                <input type="tel" class="form-control" id="sdt" name="sdt" required>
                            </div>
                            <div class="form-group">
                                <label for="dia_chi">Địa chỉ:</label>
                                <input type="text" class="form-control" id="dia_chi" name="dia_chi" required>
                            </div>
                            <div class="form-group">
                                <label for="gioi_tinh">Giới tính:</label>
                                <select class="form-control" id="gioi_tinh" name="gioi_tinh" required>
                                    <option value="nam">Nam</option>
                                    <option value="nu">Nữ</option>
                                    <option value="khac">Khác</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="ngay_sinh">Ngày sinh:</label>
                                <input type="date" class="form-control" id="ngay_sinh" name="ngay_sinh" required>
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary">Đăng ký</button>
                            <div class="text-center">
                                <a class="small" href="<?= BASE_URL . '?act=dangnhap' ?>">Đăng nhập</a>
                            </div>
                            <hr>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <hr>
    <!-- <div class="text-center">
                                    <a class="small" href="forgot-password.html">Quên mật khẩu ?</a>
                                </div> -->
    <!-- <div class="text-center">
        <a class="small" href="<?= BASE_URL . '?act=dangnhap' ?>">Đăng nhập</a>
    </div> -->
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<?php
include "views/shop/layoutshop/footer.php";
?>