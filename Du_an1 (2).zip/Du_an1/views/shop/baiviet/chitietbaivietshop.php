<?php 
include "views/shop/layoutshop/header.php";
include "views/shop/layoutshop/menu.php";
?>

<main class="container mt-4">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title"><?php echo $ctbaiviet['tieude_baiviet']; ?></h2>
                    <img src="uploads/baiviet/<?php echo $ctbaiviet['anh_bai_viet']; ?>" class="card-img-top img-fluid" alt="...">
                    <p class="card-text"><?php echo $ctbaiviet['noi_dung']; ?></p>
                    <p class="card-text float-right"><small class="text-muted">Ngày đăng: <?php echo $ctbaiviet['ngay_dang']; ?></small></p>
                </div>
            </div>
        </div>
    </div>
</main>
<div class="container-baivietlienquan mt-4">
    <div class="col-md-12 mx-auto mt-4 text-center">
        <h3 class="section-title my-5">Xem thêm bài viết liên quan</h5>
    </div>
    <div class="row row-cols-1 row-cols-md-3 justify-content-center">
        <?php 
        $count = 0;
        foreach ($baiviet_lienquan as $item) : 
            if($count<3):
        ?>
            <div class="col mb-4">
                <div class="card">
                    <div class="image-container">
                        <img src="uploads/baiviet/<?php echo $item['anh_bai_viet']; ?>" class="card-img-top img-fluid" alt="...">
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $item['tieude_baiviet']; ?></h5>
                        <p class="card-text"><small class="text-muted">Ngày đăng: <?php echo $item['ngay_dang']; ?></small></p>
                        <a href="?act=ctbaivietshop&id=<?= $item['id_bai_viet'] ?>" class="btn btn-primary">Xem thêm</a>
                    </div>
                </div>
            </div>
        <?php 
        $count ++;
            endif;
        endforeach; 
        ?>
    </div>
</div>





<?php
include "views/shop/layoutshop/footer.php";
?>