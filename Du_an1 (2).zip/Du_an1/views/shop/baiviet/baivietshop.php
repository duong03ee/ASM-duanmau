<?php
include "views/shop/layoutshop/header.php";
include "views/shop/layoutshop/menu.php";
?>

<style>
    .section-title {
        font-size: 2rem;
        font-weight: bold;
        color: #333;
        margin-bottom: 30px;
    }

    .image-container {
        height: 200px;
        overflow: hidden;
    }

    .image-container img {
        width: 100%;
        height: auto;
        transition: transform 0.3s ease;
    }

    .image-container:hover img {
        transform: scale(1.05);
    }

    .banner-container {
    position: fixed;
    top: 30%;
    right: 20%;
    z-index: 9999;
    width: 20%;
    height: auto;
    overflow-y: auto;
    background-color: rgba(255, 255, 255, 0.0);
    padding: 20px;
}

    .banner-content img {
        max-width: 100%; /* Ảnh trong banner sẽ co dãn theo chiều ngang */
    }
    h1{
        margin-left: -400px;
        margin-top: 200px;
    }
</style>

<body>


    <h1 class="section-title text-center mb-3">Tin thời trang</h1>
    <main class="container mt-4">
        <div class="article-container">
            <div class="article-list">
                <div class="row">
                    <?php foreach ($baiviet as $item) : ?>
                        <div class="col-md-6 m-2">
                            <div class="card">
                                <div class="image-container">
                                    <img src="uploads/baiviet/<?php echo $item['anh_bai_viet']; ?>" class="card-img-top img-fluid" alt="...">
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $item['tieude_baiviet']; ?></h5>
                                    <p class="card-text"><small class="text-muted">Ngày đăng: <?php echo $item['ngay_dang']; ?></small></p>
                                    <a href="?act=ctbaivietshop&id=<?= $item['id_bai_viet'] ?>" class="btn btn-primary">Xem thêm</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="aside-container">
        </div>
        <div class="banner-container">
            <div class="banner-content" id="vertical-banner">
                <img src="https://i.pinimg.com/originals/67/bf/0b/67bf0bca45191fac2a228a848685ba8d.gif" alt="">
            </div>
            <script>
                
            </script>
        </div>
    </main>
    <div class="banner-blog d-flex justify-content-center">
    <a href="#">
        <picture>
            <source srcset="https://routine.vn/media/wysiwyg/Blog/Mua_1_duoc_2_6_.jpg" media="(max-width: 767px)">
            <img class="mx-auto my-2" src="https://routine.vn/media/amasty/webp/wysiwyg/Blog/Mua_1_duoc_2_6__jpg.webp" alt="KingClothes" width="100%" height="auto">
        </picture>
    </a>
</div>
<style>
    .banner-show {
        position: fixed;
        top: 30%;
        right: 20%;
        z-index: 9999;
        width: 20%;
        height: auto;
        overflow-y: auto;
        background-color: rgba(255, 255, 255, 0.0);
        padding: 20px;
    }

    .banner-hide {
        visibility: hidden;
    }
</style>
<script>
    window.addEventListener('scroll', function() {
        var banner = document.getElementById('vertical-banner');
        var bannerHeight = banner.offsetHeight;
        var content = document.querySelector('.article-container');
        var contentTop = content.offsetTop;
        var contentBottom = contentTop + content.offsetHeight;
        var windowHeight = window.innerHeight;
        var scrollTop = window.scrollY;

        // Kiểm tra nếu người dùng cuộn đến cuối bài viết
        if (scrollTop + window.innerHeight >= contentBottom) {
        banner.classList.add('banner-hide');
        banner.classList.remove('banner-show');
    } else {
        banner.classList.add('banner-show');
        banner.classList.remove('banner-hide');
    }
    });
</script>


    <?php
    include "views/shop/layoutshop/footer.php";
    ?>