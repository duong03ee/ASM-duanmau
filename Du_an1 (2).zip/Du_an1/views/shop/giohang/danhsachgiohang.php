<?php
include "views/shop/layoutshop/header.php";
?>
<h1 style="margin-left: 300px; margin-top: 200px; font-weight: bolder;">Giỏ hàng</h1>
<?php
$tongall = 0;
if (count($danh_sach_gio_hang) > 0) {
    foreach ($danh_sach_gio_hang as $item) {
        $tong = $item['gia_ban'] * $item['so_luong'];
        $tongall += $tong;
?>
        <style>
            .cart-item {
                display: flex;
                height: 300px;
                border: 1px solid #ccc;
                margin: 50px 250px;
                padding: 20px 50px;
                /* Border cho cart-item */
            }

            .product-image {
                margin-top: 5px;
            }

            .product-image img {
                border-radius: 5px;
                padding: 5px;
                border: 1px solid #ccc;
                width: 200px;
                height: 250px;
            }

            .product-info {
                position: relative;
                margin-left: -500px;
                padding-left: 10px;
                /* Khoảng cách giữa nội dung và ảnh */
            }

            .product-details {
                margin-left: -150px;
                /* Chiếm hết không gian nội dung còn lại */
            }

            .total-price input {
                margin-top: 20px;
                font-size: 26px;
                color: red;
                font-weight: bolder;
                border: none;
                /* Cố định phần tổng tiền sang phải */
            }

            /* Định dạng cho nút tăng giảm */
            .quantity-btn {
                background-color: #007bff;
                color: #fff;
                border: none;
                padding: 3px 10px;
                cursor: pointer;
                margin-left: -5px;
                border-top-right-radius: 5px;
                border-bottom-right-radius: 5px;
            }

            /* Định dạng cho input số lượng */
            .quantity-input {
                width: 40px;
                border-radius: 5px;
                text-align: center;
            }

            /* Định dạng cho nút tăng giảm khi hover */
            .quantity-btn:hover {
                background-color: #0056b3;
            }

            .delete {
                position: absolute;
                bottom: 0;
                right: 0;
                float: right;
                margin-left: 350px;
            }

            .delete input {
                border-radius: 5px;
                padding: 5px 15px;
                border: none;
                color: white;
                background-color: red;
            }

            .delete input:hover {
                background-color: #CC0000;
            }

            label {
                font-size: 20px;
            }

            .quantity-control form {
                position: relative;
                margin-left: -130px;
            }

            .quantity-control input[type="submit"] {
                position: absolute;
                top: 0px;
                left: 120px;
                border: none;
                background-color: #007bff;
                color: white;
                padding: 5px 15px;
                border-radius: 5px;
                margin-left: 20px;
            }

            .quantity-control input[type="submit"]:hover {
                background-color: blue;
            }



            .mua button {
                margin-left: 1200px;
                margin-bottom: 50px;
                border-radius: 5px;
                padding: 10px 20px;
                border: none;
                color: white;
                font-size: 20px;
                background-color: #007bff;
            }

            .mua button:hover {
                background-color: blue;
            }
        </style>
        <div class="cart-item">
            <div class="product-image">
                <img src="uploads/products/<?= $item['anh'] ?>" alt="Product Image">
            </div>
            <div class="product-info">
                <div class="product-details">
                    <h3 class="product-name"><?= $item['ten_san_pham'] ?></h3>
                    <div style="display: flex;">
                        <p class="product-price" style="text-decoration: none;font-size: 22px;color: black; font-weight: 500;">đ<?= number_format($item['gia_ban']) ?></p>
                        <span class="product-price" style="font-size: 18px; margin-top: 5px; margin-left: 10px;">đ<?= number_format($item['gia']) ?></span>
                    </div>
                </div>
                <div class="quantity-control">
                    <form action="<?= BASE_URL . '?act=capnhatgiohang&id_san_pham=' . $item['id_san_pham'] . '&id_chitiet_giohang=' . $item['id_chitiet_giohang'] . '' ?>" method="post">
                        <label for="">Số lượng: </label>
                        <input type="number" class="quantity-input" name="so_luong" value="<?= $item['so_luong'] ?>" min="1">
                        <div class="total-price">
                            <input type="text" value="Tổng: đ<?= number_format($tong) ?>">
                            <input type="hidden" name="gia_ban" value="<?= $item['gia_ban'] ?>">
                        </div>
                        <input type="submit" name="capnhat" value="Cập nhật">
                    </form>
                </div>
                <div class="delete">
                    <a href="<?= BASE_URL . '?act=xoagiohang&id_san_pham=' . $item['id_san_pham'] . '&id_chitiet_giohang=' . $item['id_chitiet_giohang'] . '' ?>"><input type="submit" name="xoa" value="Xoá" onclick="return confirm('Bạn có muốn xoá sản phẩm này không?')"></a>
                </div>
            </div>
        </div>
    <?php
    }
    ?>
    <!-- <div class="sum" style="margin-left: 980px;">
        <h5>Tổng các sản phẩm: <span style="color: red; font-weight: bolder;font-size: 25px;">đ<?php echo number_format($tongall) ?></span> </h5>
    </div> -->
    <div class="mua" style="margin-left: -50px;">
        <a href="<?= BASE_URL . '?act=mua' ?>"><button class="mua" type="submit" name="mua">Đặt hàng</button></a>
    </div>
<?php

} else {
?>
    <span style="margin-left: 300px; margin-top: 20px;">Chưa có gì trong giỏ hàng!</span>
<?php } ?>
<?php
include "views/shop/layoutshop/footer.php";
?>
<!-- <div class="quantity-control">
    <button class="quantity-btn decrease" style="margin-right: -5px;border-top-right-radius: 0px ;border-bottom-right-radius: 0px;;border-top-left-radius: 5px ;border-bottom-left-radius: 5px;">-</button>
    <input type="text" class="quantity-input" value="<?= $item['so_luong'] ?>">
    <button class="quantity-btn increase">+</button>
</div> -->