<?php
include "views/shop/layoutshop/header.php";
include "views/shop/layoutshop/menu.php";
?>
<div class="container-fluid">
    <div class="row">
    <nav style="background-color: white;" class="col-md-2 d-none d-md-block sidebar">
                <div class="sidebar-sticky">
                    <h6 class="sidebar-heading">Danh mục sản phẩm</h6>
                    <ul class="list-group">
                        <?php
                        foreach ($danhmuc as $dm) {
                        ?>
                            <input type="hidden" name="id_danh_muc" value="<?= $dm['id_danh_muc'] ?>">
                            <li class="list-group-item"><a href="?act=sanpham_danhmuc&iddanhmuc=<?= $dm['id_danh_muc'] ?>"><?= $dm['ten_danh_muc'] ?></a>
                            <?php
                        }
                        ?>
                    </ul>
                    <hr>
                    <h6 class="sidebar-heading">Sắp xếp theo</h6>
                    <ul>
                    <select id="locsp" class="form-control select-custom">
                        <option value="">Giá</option>
                        <option value="?act=timkiem&search_query=<?=$_GET['search_query']?>&gia=desc">Cao đến thấp</option>
                        <option value="?act=timkiem&search_query=<?=$_GET['search_query']?>&gia=asc">Thấp đến cao</option>
                    </select>
                    <script>
                        document.getElementById("locsp").onchange = function() {
                            var selectedOption = this.value;
                            if (selectedOption !== '') { 
                                window.location.href = selectedOption;
                            }
                        };
                    </script>

                    </ul>
                </div>
    </nav>
    
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
            <div class="text-center">
                <br>
                <h1>🔥Sản Phẩm🔥</h1> <br>
            </div>
            
            <div class="container">
                <div class="row">
                <?php

        foreach ($sptimkiem as $item) {
        ?>
            <div class="col-md-4">
                <div class="product-card">
                    <a href="?act=shopchitietsanpham&id=<?php echo $item['id_san_pham']; ?>"><img class="product-image" src="uploads/products/<?= $item['anh'] ?>" alt="Product 1"></a>
                    <div class="product-details">
                        <div class="product-name"><?= $item['ten_san_pham'] ?></div>
                        <del>
                            <div class="product-price">Giá: đ<?= number_format($item['gia']) ?></div>
                        </del>
                        <div class="product-sale-price">Giá ưu đãi: đ<?= number_format($item['gia_ban']) ?></div>
                        <div class="sale-price">Tiết kiệm: đ<?php echo number_format($item['gia']-$item['gia_ban']) ?></div>
                        <a href="<?= BASE_URL .'?act=themgiohang&id_san_pham='.$item['id_san_pham'].'&so_luong=1&tong_tien='.$item['gia_ban'] ?>"><button class="add-to-cart-btn">Thêm vào giỏ hàng</button></a>
                        <a href="?act=shopchitietsanpham&id=<?php echo $item['id_san_pham']; ?>"><button class="add-to-cart-btn" style="background-color: #007bff; margin-left: 5px;">Xem</button></a>
                    </div>
                </div>
            </div>
        <?php
        }
        ?>
                </div>
            </div>

        </main>
    </div>
</div>
<?php
include "views/shop/layoutshop/footer.php";
?>







