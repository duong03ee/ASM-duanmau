<?php
include "views/shop/layoutshop/header.php";
include "views/shop/layoutshop/menu.php";
?>
  <style>
   .jumbotron {
    background-color: #f8f9fa; /* Màu nền */
  }
  .jumbotron-img {
    max-width: 100%;
  } 
  .jumbotron-img {
    transition: filter 0.3s ease-in-out;
  }
  .jumbotron-img:hover {
    filter: brightness(60%); 
  }
  </style>
<div class="container">
  <div class="jumbotron">
    <h1 class="display-4 text-primary">Chào mừng bạn đến với King Clother!</h1>
    <p class="lead">Nơi thăng hoa phong cách và sự tự tin!</p>
    <hr class="my-4">
    <p>Tại King Clother, chúng tôi cam kết mang đến cho bạn những bộ trang phục đẹp và chất lượng hàng đầu từ các thương hiệu uy tín trên toàn thế giới. Từ những bộ đồ công sở thanh lịch, những trang phục dạo phố cá tính đến những trang phục dành cho các buổi tiệc đặc biệt, chúng tôi có đủ mọi thứ để bạn có thể tự tin thể hiện phong cách riêng của mình.</p>
    <p>Ngoài ra, dịch vụ chăm sóc khách hàng tận tình và chu đáo là ưu tiên hàng đầu của chúng tôi. Chúng tôi luôn sẵn lòng lắng nghe và đáp ứng mọi nhu cầu của bạn để đảm bảo bạn có trải nghiệm mua sắm tuyệt vời nhất tại King Clother.</p>
    <p class="lead">
      <a class="btn btn-primary btn-lg" href="http://localhost/Duan1/Du_an1/index.php?act=shop" role="button">Khám phá ngay</a>
    </p>
  </div>
</div>
<div class="container">
  <div class="row">
  <div class="col-md-6">
  <img src="views/shop/img/logo_black.png" alt="Welcome Image" class="jumbotron-img">
</div>
    <div class="col-md-6">
      <div class="jumbotron">
        <h1 class="display-4 text-primary"> King Clother!</h1>
        <hr class="my-4">
    <p class="lead">Nơi bạn có thể tìm thấy những bộ trang phục đẹp và chất lượng hàng đầu từ các thương hiệu uy tín trên toàn thế giới.</p>
    <p>Từ những bộ đồ công sở thanh lịch, những trang phục dạo phố cá tính đến những trang phục dành cho các buổi tiệc đặc biệt, chúng tôi có đủ mọi thứ để bạn có thể tự tin thể hiện phong cách riêng của mình.</p>
    <p>Ngoài ra, dịch vụ chăm sóc khách hàng tận tình và chu đáo là ưu tiên hàng đầu của chúng tôi. Chúng tôi luôn sẵn lòng lắng nghe và đáp ứng mọi nhu cầu của bạn để đảm bảo bạn có trải nghiệm mua sắm tuyệt vời nhất tại cửa hàng của chúng tôi.</p>      </div>
    </div>
  </div>
</div>

<br>
<?php
    include "views/shop/layoutshop/footer.php";
    ?>