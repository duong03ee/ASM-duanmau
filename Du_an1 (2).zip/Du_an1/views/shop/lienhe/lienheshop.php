<?php
include "views/shop/layoutshop/header.php";
include "views/shop/layoutshop/menu.php";
?>
  <style>
    /* Đảm bảo bản đồ sẽ lấp đầy toàn bộ khu vực chứa nó */
    #map {
      height: 100%;
      width: 100%;
    }

  .contact-info {
    margin-bottom: 20px;
  }
  .contact-info i {
    margin-right: 10px;
  }

  </style>
<h3>Vị trí của cửa hàng</h3>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.027545133524!2d106.68023261404104!3d10.769476162784646!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752958a947f163%3A0x3c87624c18ca8e8b!2sBitexco%20Financial%20Tower!5e0!3m2!1sen!2s!4v1648925410369!5m2!1sen!2s" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

<br>
<br>
<div class="container">

  <div class="row">
  <div class="col-md-6">
  <h2 class="mb-4">Gửi thắc mắc cho chúng tôi</h2>
  <p>Nếu bạn có thắc mắc gì, có thể gửi yêu cầu cho chúng tôi, và chúng tôi sẽ liên lạc lại với bạn sớm nhất có thể .

</p>


  <form action="<?= BASE_URL . '?act=guilienhe' ?>" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label for="sender_name"><i class="fas fa-user"></i> Tên của bạn:</label>
      <input type="text" class="form-control" id="sender_name" name="sender_name" required>
    </div>
    <div class="form-group">
      <label for="subject"><i class="fas fa-heading"></i> Tiêu đề:</label>
      <input type="text" class="form-control" id="subject" name="subject" required>
    </div>
    <div class="form-group">
      <label for="message"><i class="fas fa-comment"></i> Nội dung:</label>
      <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
    </div>
    <div class="form-group">
      <label for="email"><i class="fas fa-envelope"></i> Email:</label>
      <input type="email" class="form-control" id="email" name="email" placeholder="example@example.com" required>
    </div>
    <div class="form-group">
      <label for="phone"><i class="fas fa-phone"></i> Số điện thoại:</label>
      <input type="tel" class="form-control" id="phone" name="phone" pattern="[0-9]{10}" placeholder="Số điện thoại của bạn (10 chữ số)" required>
    </div>
    <input type="hidden" name="date" value="<?php echo date('Y-m-d'); ?>">
    <!-- <div class="form-group">
      <label for="date"><i class="fas fa-calendar-alt"></i> Ngày gửi:</label>
      <input type="date" class="form-control" id="date" name="date" required>
    </div> -->
    <button type="submit" name="themm" class="btn btn-primary">Gửi Cho Chúng Tôi</button>
  </form>
</div>



    <div class="col-md-6">
      <div class="">

<h2>Thông Tin Liên Hệ</h2>

<div class="contact-info">
  <i class="fas fa-map-marker-alt"></i> Địa chỉ: Tầng 99, tòa nhà Ford, số 999 Trường Chinh, quận Thanh Xuân, Hà Nội
</div>

<div class="contact-info">
  <i class="fas fa-phone"></i> Điện thoại: <a href="tel:0999999999">0999.999.999</a>
</div>

<div class="contact-info">
  <i class="far fa-clock"></i> Thời gian làm việc:
  <ul>
    <li>Thứ 2 đến thứ 6: từ 8h30 đến 18h</li>
    <li>Thứ 7: từ 8h30 đến 12h00</li>
  </ul>
</div>

<div class="contact-info">
  <i class="far fa-envelope"></i> Email: <a href="mailto:cskh@torano.vn">kingclother@gmail.com</a>
</div>


    </div>
  </div>
</div>
</div>
<br>

<?php
    include "views/shop/layoutshop/footer.php";
    ?>