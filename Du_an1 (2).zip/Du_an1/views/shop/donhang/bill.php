<?php
// var_dump($chitietdonhang);
include "views/shop/layoutshop/header.php";
include "views/shop/layoutshop/menu.php";
?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr>
            <h2 class="mb-3" style="font-size: 20px; color: orange; font-family: 'Arial', sans-serif;">
                <i class="fas fa-check-circle" style="margin-right: 5px;"></i> <!-- Biểu tượng số 1 -->
                Đơn mua
            </h2>
            <!-- Thông tin sản phẩm -->
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Mã đơn hàng</th>
                            <th scope="col">Hình ảnh</th>
                            <th scope="col">Tên sản phẩm</th>
                            <!-- <th scope="col">Đơn giá</th> -->
                            <!-- <th scope="col">Số lượng</th> -->
                            <!-- <th scope="col">Thành tiền</th> -->
                            <!-- <th scope="col">Mã khuyến mãi</th> -->
                            <th scope="col">Tổng tiền</th>
                            <th scope="col">Trạng thái</th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                    <style>
                        .trangthai {
                            text-align: center;
                            color: orange;
                            width: 120px;
                            text-decoration: underline;
                            font-weight: bolder;
                        }
                    </style>
                    <tbody>
                        <!-- Sản phẩm -->
                        <?php
                        foreach ($chitietdonhang as $item) {
                        ?>
                            <tr>
                                <td>#<?= $item['id_don_hang'] ?></td>
                                <td>
                                    <img src="uploads/products/<?php echo $item['anh']; ?>" width="100px" height="120px" alt="Hình ảnh sản phẩm">
                                </td>
                                <td><?php echo $item['ten_san_pham']; ?></td>
                                <!-- <td><?php echo $item['don_gia']; ?></td> -->
                                <!-- <td><?php echo $item['so_luong']; ?></td> -->
                                <!-- <td style="font-weight: bolder;">đ<?php echo number_format($item['thanh_tien']); ?></td> -->
                                <!-- <td style="color: blue;font-weight: bold"><?= $item['ma_khuyen_mai'] ?><br>(Giảm đ<?= number_format($item['muc_giam_gia']) ?>)</td> -->
                                <td style="color: red;font-weight: bolder;">đ<?php echo number_format($item['tong_tien']); ?></td>
                                <td>
                                    <p class="trangthai"><?php echo $item['trangthai_donhang']; ?></p>
                                </td>
                                <style>
                                    .ctdh,
                                    .huy,
                                    .danhanhang,
                                    .danhgiasp {
                                        display: inline-block;
                                        width: 80px;
                                        padding: 10px 8px;
                                        border-radius: 5px;
                                        text-align: center;
                                        text-decoration: none;
                                        color: #fff;
                                        transition: background-color 0.3s ease;
                                    }

                                    .ctdh {
                                        background-color: #3498db;
                                    }

                                    .danhgiasp {
                                        background-color: #e74c3c;
                                    }

                                    .huy {
                                        background-color: #e74c3c;
                                    }

                                    .danhanhang {
                                        margin-left: 18px;
                                        background-color: #00FF00;
                                    }

                                    .danhgiasp:hover {
                                        background-color: #c0392b;
                                        color: white;
                                        text-decoration: none;
                                    }

                                    .ctdh:hover {
                                        background-color: #2980b9;
                                        color: white;
                                        text-decoration: none;
                                        /* Màu hover cho nút "Chi tiết đơn hàng" */
                                    }

                                    .danhanhang:hover {
                                        background-color: green;
                                        color: white;
                                        text-decoration: none;
                                        /* Màu hover cho nút "Chi tiết đơn hàng" */
                                    }

                                    .huy:hover {
                                        background-color: #c0392b;
                                        color: white;
                                        text-decoration: none;
                                        /* Màu hover cho nút "Huỷ đơn hàng" */
                                    }
                                </style>
                                <td>
                                    <a class="ctdh" style="margin-right: -20px;" href="<?= BASE_URL . '?act=chitietbill&id_anh='  . $item['id_anh'] ?>">Chi tiết</a>
                                </td>
                                <?php
                                // Lấy giá trị của id_trangthai_donhang từ $item
                                $id_trangthai_donhang = $item['id_trangthai_donhang'];

                                // Kiểm tra nếu id_trangthai_donhang không phải là 3 hoặc 4 thì mới hiển thị nút "Huỷ"
                                if ($id_trangthai_donhang != 3 && $id_trangthai_donhang != 4) {
                                ?>
                                    <td>
                                        <a class="huy" onclick="return confirm('Bạn có chắc chắn muốn huỷ đơn hàng này!')" href="<?= BASE_URL . '?act=huydonhang&id_don_hang=' . $item['id_don_hang'] ?>">Huỷ</a>
                                    </td>
                                <?php
                                }
                                if ($id_trangthai_donhang != 1 && $id_trangthai_donhang != 2 && $id_trangthai_donhang != 5) {
                                ?>
                                    <td>
                                        <a class="danhanhang" onclick="return confirm('Bạn đã nhận đơn hàng này!')" href="<?= BASE_URL . '?act=danhanhang&id_don_hang=' . $item['id_don_hang'] ?>">Đã nhận</a>
                                    </td>
                                <?php
                                }
                                if ($id_trangthai_donhang == 4) {
                                ?>
                                    <td>
                                        <a class="danhgiasp" href="<?= BASE_URL . '?act=guidanhgia&id_anh=' . $item['id_anh'] . '&id_san_pham=' . $item['id_san_pham'] ?>">Đánh giá</a>
                                    </td>
                                <?php
                                }
                                ?>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
include "views/shop/layoutshop/footer.php";
?>