<?php
// var_dump($chitietdonhang);
include "views/shop/layoutshop/header.php";
include "views/shop/layoutshop/menu.php";
?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <hr>
            <h2 class="mb-3" style="font-size: 20px; color: orange; font-family: 'Arial', sans-serif;">
                <i class="fas fa-check-circle" style="margin-right: 5px;"></i> <!-- Biểu tượng số 1 -->
                Đơn hàng
            </h2>
            <!-- Thông tin sản phẩm -->
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Mã đơn hàng</th>
                            <th scope="col">Hình ảnh</th>
                            <th scope="col">Tên sản phẩm</th>
                            <!-- <th scope="col">Đơn giá</th> -->
                            <!-- <th scope="col">Số lượng</th> -->
                            <!-- <th scope="col">Thành tiền</th> -->
                            <!-- <th scope="col">Mã khuyến mãi</th> -->
                            <th scope="col">Tổng tiền</th>
                            <th scope="col">Trạng thái</th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Sản phẩm -->
                        <?php
                        foreach ($chitietdonhang as $item) {
                        ?>
                            <tr>
                                <td>#<?= $item['id_don_hang'] ?></td>
                                <td>
                                    <img src="uploads/products/<?php echo $item['anh']; ?>" width="100px" height="120px" alt="Hình ảnh sản phẩm">
                                </td>
                                <td><?php echo $item['ten_san_pham']; ?></td>
                                <!-- <td><?php echo $item['don_gia']; ?></td> -->
                                <!-- <td><?php echo $item['so_luong']; ?></td> -->
                                <!-- <td style="font-weight: bolder;">đ<?php echo number_format($item['thanh_tien']); ?></td> -->
                                <!-- <td style="color: blue;font-weight: bold"><?= $item['ma_khuyen_mai'] ?><br>(Giảm đ<?= number_format($item['muc_giam_gia']) ?>)</td> -->
                                <td style="color: red;font-weight: bolder;">đ<?php echo number_format($item['tong_tien']); ?></td>
                                <td><?php echo $item['trangthai_donhang']; ?></td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
                <h2 class="mb-3" style="font-size: 20px; color: orange; font-family: 'Arial', sans-serif;margin-top: 50px;">
                    <i class="fas fa-check-circle" style="margin-right: 5px;"></i> <!-- Biểu tượng số 1 -->
                    Đánh giá sản phẩm
                </h2>
                <style>
                    .form-group {
                        position: relative;
                    }

                    .rating {
                        position: absolute;
                        top: -5px;
                        left: 180px;
                    }

                    .rating .star {
                        font-size: 20px;
                        color: transparent;
                        /* Đặt màu chữ trong suốt */
                        text-shadow: 0 0 0 #ffd700;
                        /* Tạo hiệu ứng màu vàng */
                    }
                </style>
                <form id="form_danhgia" action="" method="post" class="needs-validation" novalidate>
                    <div class="form-group">
                        <p>Chất lượng sản phẩm</p>
                        <div class="rating">
                            <span class="star" data-value="1">&#9734;</span>
                            <span class="star" data-value="2">&#9734;</span>
                            <span class="star" data-value="3">&#9734;</span>
                            <span class="star" data-value="4">&#9734;</span>
                            <span class="star" data-value="5">&#9734;</span>
                        </div>
                        <input type="hidden" name="ngay_dang" value="<?= date('Y-m-d') ?>">
                        <input type="hidden" name="sao_danh_gia" id="sao_danh_gia" value="0">
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" name="noidung_danhgia" id="noidung" cols="30" rows="5" placeholder="Nhập nội dung đánh giá của bạn" required></textarea>
                        <div class="invalid-feedback">Vui lòng nhập nội dung đánh giá.</div>
                    </div>
                    <button type="submit" name="gui_danhgia" class="btn btn-primary">Gửi đánh giá</button>
                </form>

                <script>
                    document.addEventListener("DOMContentLoaded", function() {
                        const stars = document.querySelectorAll('.star');

                        stars.forEach(star => {
                            star.addEventListener('click', function() {
                                const value = parseInt(this.getAttribute('data-value'));
                                document.getElementById('sao_danh_gia').value = value; // Lưu giá trị ngôi sao được chọn vào trường ẩn
                                stars.forEach(s => {
                                    if (parseInt(s.getAttribute('data-value')) <= value) {
                                        s.innerHTML = '&#9733;'; // Đổi ngôi sao trống thành ngôi sao đầy cho các ngôi sao có giá trị nhỏ hơn hoặc bằng giá trị được chọn
                                    } else {
                                        s.innerHTML = '&#9734;'; // Đổi ngôi sao đầy thành ngôi sao trống cho các ngôi sao có giá trị lớn hơn giá trị được chọn
                                    }
                                });
                            });
                        });

                        // Thiết lập trạng thái ban đầu của các ngôi sao là trống
                        stars.forEach(star => {
                            star.innerHTML = '&#9734;';
                        });
                    });
                </script>



            </div>
        </div>
    </div>
</div>
<?php
include "views/shop/layoutshop/footer.php";
?>