<?php
include "views/shop/layoutshop/header.php";
include "views/shop/layoutshop/menu.php";
?>

<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
    }

    .khung {
        max-width: 800px;
        margin: 20px auto;
        background-color: #fff;
        border-radius: 5px;
        padding: 20px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .tieu-de {
        font-weight: bolder;
        text-align: center;
    }

    .chi-tiet-don-hang {
        border-bottom: 1px solid #ccc;
        padding-bottom: 10px;
        margin-bottom: 20px;
    }

    .chi-tiet-don-hang h2 {
        font-size: 24px;
        margin-bottom: 10px;
    }

    .san-pham {
        border-bottom: 1px solid #ccc;
        padding: 10px 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .san-pham-cuoi-cung {
        border-bottom: none;
    }

    .ten-san-pham {
        flex: 1;
    }

    .gia-san-pham {
        margin-left: 20px;
        font-weight: bold;
    }

    .tong-tien {
        text-align: right;
        font-weight: bold;
    }

    h2 {
        margin-top: 30px;
        margin-bottom: 15px;
        color: blue;
        text-align: center;
        font-weight: bold;

    }

    .nut {
        margin-left: 473px;
        margin-top: 20px;
    }

    .huy-don-hang {
        background-color: #e74c3c;
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        text-decoration: none;
        display: inline-block;
    }

    .huy-don-hang:hover {
        color: white;
        text-decoration: none;
        background-color: #c0392b;
    }

    .da-nhan-hang {
        background-color: #3498db;
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        text-decoration: none;
        display: inline-block;
    }

    .da-nhan-hang:hover {
        color: white;
        text-decoration: none;
        background-color: blue;
    }
</style>
</head>

<body>
    <div class="khung">
        <h1 class="tieu-de">Chi tiết đơn hàng</h1>
        <div class="chi-tiet-don-hang">
            <h3>Mã đơn hàng: #<?= $bill['id_don_hang'] ?></h3>
            <p>Ngày đặt hàng: <?= $bill['ngay_dat'] ?></p>
        </div>
        <div class="san-pham">
            <div class="ten-san-pham">Tên sản phẩm </div>
            <div class="gia-san-pham"><?= $bill['ten_san_pham'] ?></div>
        </div>
        <div class="san-pham">
            <div class="ten-san-pham">Ảnh sản phẩm </div>
            <img src="uploads/products/<?= $bill['anh'] ?>" alt="" width="150px" height="180px" style="border-radius: 10px; margin-right: 30px;">
        </div>
        <div class="san-pham">
            <div class="ten-san-pham">Đơn giá </div>
            <div class="gia-san-pham">đ<?= number_format($bill['don_gia']) ?></div>
        </div>
        <div class="san-pham">
            <div class="ten-san-pham">Số lượng </div>
            <div class="gia-san-pham"><?= $bill['so_luong'] ?></div>
        </div>
        <div class="san-pham">
            <div class="ten-san-pham">Thành tiền </div>
            <div class="gia-san-pham">đ<?= number_format($bill['thanh_tien']) ?></div>
        </div>
        <div class="san-pham">
            <div class="ten-san-pham">Mã khuyến mãi </div>
            <div class="gia-san-pham"><?= $bill['ma_khuyen_mai'] ?></div>
        </div>
        <div class="san-pham">
            <div class="ten-san-pham">Mức giảm giá </div>
            <div class="gia-san-pham">đ<?= number_format($bill['muc_giam_gia']) ?></div>
        </div>
        <div class="san-pham">
            <div class="ten-san-pham">Tổng tiền </div>
            <div class="gia-san-pham">đ<?= number_format($bill['tong_tien']) ?></div>
        </div>
        <div class="san-pham">
            <div class="ten-san-pham">Phương thức thanh toán </div>
            <div class="gia-san-pham"><?= $bill['phuongthuc_thanhtoan'] ?></div>
        </div>

        <?php if ($bill['phuongthuc_thanhtoan'] == 'momo') : ?>
            <div class="san-pham">
                <div class="ten-san-pham">Mã giao dịch </div>
                <div class="gia-san-pham">#<?= $bill['ma_giao_dich'] ?></div>
            </div>
        <?php endif; ?>

        <div class="san-pham">
            <div class="ten-san-pham">Trạng thái </div>
            <div class="gia-san-pham" style="
                            text-align: center;
                            color: red;
                            text-decoration: underline;
                            font-weight: bolder;">
                <?= $bill['trangthai_donhang'] ?></div>
        </div>
        <h2>Thông tin người nhận</h2>
        <div class="san-pham">
            <div class="ten-san-pham">Tên người nhận </div>
            <div class="gia-san-pham"><?= $bill['ten_nguoi_nhan'] ?></div>
        </div>
        <div class="san-pham">
            <div class="ten-san-pham">Sđt </div>
            <div class="gia-san-pham"><?= $bill['sdt_nguoi_nhan'] ?></div>
        </div>
        <div class="san-pham">
            <div class="ten-san-pham">Email </div>
            <div class="gia-san-pham"><?= $bill['email'] ?></div>
        </div>
        <div class="san-pham">
            <div class="ten-san-pham">Địa chỉ </div>
            <div class="gia-san-pham"><?= $bill['diachi_nhanhang'] ?></div>
        </div>
        <?php
        // Giả sử $id_trangthai_donhang là giá trị của id_trangthai_donhang từ dữ liệu cơ sở dữ liệu hoặc bất kỳ nguồn dữ liệu nào khác.
        $id_trangthai_donhang = $bill['id_trangthai_donhang'];

        // Kiểm tra giá trị của $id_trangthai_donhang để quyết định xem nút nào sẽ được hiển thị.
        if ($id_trangthai_donhang == 3) {
            // Không hiển thị nút huỷ đơn hàng
            echo '<div class="nut">';
            echo '<a class="da-nhan-hang" onclick="return confirm(\'Bạn đã nhận đơn hàng này!\')" href="' . BASE_URL . '?act=danhanhang&id_don_hang=' . $bill['id_don_hang'] . '">Đã nhận hàng</a>';
            echo '</div>';
        } else if ($id_trangthai_donhang == 4) {
            // Không hiển thị nút xác nhận
            echo '<div class="nut">';
            echo '<a class="huy-don-hang" href="' . BASE_URL . '?act=guidanhgia&id_anh=' . $bill['id_anh'] . '&id_san_pham=' . $bill['id_san_pham'] . '">Đánh giá</a>';
            echo '</div>';
        } else if ($id_trangthai_donhang == 1 || $id_trangthai_donhang == 2 || $id_trangthai_donhang == 5) {
            // Không hiển thị nút xác nhận
            echo '<div class="nut">';
            echo '<a class="huy-don-hang" onclick="return confirm(\'Bạn có chắc chắn muốn huỷ đơn hàng này!\')" href="' . BASE_URL . '?act=huydonhang&id_don_hang=' . $bill['id_don_hang'] . '">Huỷ đơn hàng</a>';
            echo '</div>';
        } else {
            // Hiển thị cả hai nút
            echo '<div class="nut">';
            echo '<a class="huy-don-hang" onclick="return confirm(\'Bạn có chắc chắn muốn huỷ đơn hàng này!\')" href="' . BASE_URL . '?act=huydonhang&id_don_hang=' . $bill['id_don_hang'] . '">Huỷ đơn hàng</a>';
            echo '<a class="da-nhan-hang" href="#">Đã nhận hàng</a>';
            echo '</div>';
        };
        ?>
    </div>
</body>

<?php
include "views/shop/layoutshop/footer.php";
?>