<?php
include "views/shop/layoutshop/header.php";
include "views/shop/layoutshop/menu.php";
?>
<script>
    function changeColor(button) {
        var buttons = document.querySelectorAll('.mkm');
        buttons.forEach(function(btn) {
            btn.classList.remove('clicked');
        });
        button.classList.add('clicked');
    }
</script>
<style>
    .table {
        background-color: #f8f9fa;
        /* Màu nền của bảng */
    }

    .table th,
    .table td {
        color: #000;
        /* Màu chữ của các ô trong bảng */
    }

    .table thead th {
        background-color: #FF9800;
        /* Màu nền của tiêu đề bảng */
        color: #fff;
        /* Màu chữ của tiêu đề bảng */
    }

    .table-striped tbody tr:nth-of-type(odd) {
        background-color: #e9ecef;
        /* Màu nền của hàng chẵn trong bảng */
    }

    .table-hover tbody tr:hover {
        background-color: #ced4da;
        /* Màu nền khi di chuột qua hàng */
    }

    .form-group {
        margin-bottom: 1.5rem;
    }

    .form-label {
        margin-top: 10px;
        font-size: 0.9rem;
    }

    .mkm {
        border: 1px solid gray;
        border-radius: 3px;
        width: 200px;
        margin: 5px;
        padding: 5px 10px;
        color: #000;
    }

    .mkm.active {
        background-color: #0084ff;
        color: #fff;
    }

    a:hover {
        text-decoration: none;
    }

    .clicked {
        background-color: green;
        color: white;
    }

    .payment-method {
        border: 1px solid #6c757d;
        /* Màu viền xám đậm */
        border-radius: 10px;
        /* Bo tròn viền */
        padding: 10px 10px;
        height: 70px;
        margin-top: 10px;
        width: 300px;
    }
</style>

<div class="container">
    <div class="row" style="margin-left: -50px; margin-bottom: 50px;">
        <div class="col-md-12">
            <hr>
            <h2 class="mb-3" style="font-size: 20px; color: orange; font-family: 'Arial', sans-serif;">
                <i class="fas fa-check-circle" style="margin-right: 5px;"></i> <!-- Biểu tượng số 1 -->
                Xác nhận đơn hàng
            </h2>
            <!-- Thông tin sản phẩm -->
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Hình ảnh</th>
                            <th scope="col">Tên sản phẩm</th>
                            <th scope="col">Đơn giá</th>
                            <th scope="col">Số lượng</th>
                            <!-- <th scope="col">Tổng tiền</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Sản phẩm  -->
                        <?php
                        $tong_tien = 0;
                        foreach ($danhsachgiohang as $dsgh) {
                            $tong_tien += $dsgh['tong_tien'];
                        ?>
                            <tr>
                                <td>
                                    <img src="uploads/products/<?php echo $dsgh['anh']; ?>" width="100px" height="120px" alt="Hình ảnh sản phẩm">
                                </td>
                                <td><?php echo $dsgh['ten_san_pham']; ?></td>
                                <td><?php echo $dsgh['gia_ban']; ?></td>
                                <td><?php echo $dsgh['so_luong']; ?></td>
                                <!-- <td><?php echo $dsgh['tong_tien']; ?></td> -->
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
                <div class="col-md-12 text-right" style="margin-bottom: 50px;">
                    <strong>Thành tiền: <span id="texttotal" style="color: red;">đ<?php echo number_format($tong_tien) ?></span></strong>
                </div>
            </div>

            <!-- Tổng tiền -->
            <!-- <div class="row mb-3">
                <div class="col-md-12 text-right"><strong>Tổng tiền: <span id="texttotal" style="color: red;">đ<?php echo number_format($tong_tien) ?></span></strong></div>
            </div> -->

        </div>

        <div class="col-md-12" style="margin-left: -30px;">
            <div class="col-md-8 mx-auto rounded p-4" style="background-color: #f8f9fa; .form-control {border-radius: 30px;}">

                <form action="<?= BASE_URL . '?act=thongtinnguoidung' ?>" method="post">
                    <h2 class="text-center mb-4" style="font-weight: bold; font-family: Arial, sans-serif;">Thông tin khách hàng</h2>
                    <!-- Mã khuyến mãi -->
                    <label class="form-label">Mã khuyễn mãi:</label><br>
                    <?php
                    foreach ($makhuyenmai as $mkm) {
                        if ($mkm['id_khuyen_mai'] != 0) {
                    ?>
                            <a href="<?= BASE_URL . '?act=mua&id_khuyen_mai=' . $mkm['id_khuyen_mai'] ?>" class="mkm 
 <?= isset($_GET['id_khuyen_mai']) && $mkm['id_khuyen_mai'] == $_GET['id_khuyen_mai'] ? 'active' : '' ?>">
                                <!-- <input type="submit" name="mkm" class="mkm" value="<?= $mkm['ma_khuyen_mai'] ?>(<?= $mkm['ten_khuyen_mai'] ?>)" onclick="changeColor(this)"> -->
                                <?= $mkm['ma_khuyen_mai'] ?> (<?= $mkm['ten_khuyen_mai'] ?>)
                            </a>
                    <?php
                        }
                    }
                    ?>
                    <!-- Họ & tên -->
                    <div class="form-group mb-3">
                        <label for="ten_nguoi_nhan" class="form-label">Họ & tên</label>
                        <input type="text" class="form-control" id="ten_nguoi_nhan" name="ten_nguoi_nhan" placeholder="Nhập họ tên của bạn">
                    </div>
                    <!-- Điện thoại -->
                    <div class="form-group mb-3">
                        <label for="sdt_nguoi_nhan" class="form-label">Điện thoại của bạn</label>
                        <input type="tel" class="form-control" id="sdt_nguoi_nhan" name="sdt_nguoi_nhan" placeholder="Nhập số điện thoại">
                    </div>
                    <!-- Địa chỉ email -->
                    <div class="form-group mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Nhập địa chỉ email">
                    </div>
                    <!-- Địa chỉ -->
                    <div class="form-group mb-3">
                        <label for="diachi_nhanhang" class="form-label">Địa chỉ đầy đủ</label>
                        <input type="text" class="form-control" id="diachi_nhanhang" name="diachi_nhanhang" placeholder="Số nhà, tên Đường, Thôn/Phường/Xã, Quận/Huyện, Tỉnh/TP">
                    </div>
                    <!-- Phương thức thanh toán -->
                    <div class="form-group mb-3">
                        <label for="phuongthuc_thanhtoan" class="form-label">Phương thức thanh toán</label>
                        <div data-v-604a8a88="" class="payment-method">
                            <label data-v-604a8a88="" for="payment-momo" class="payment-method__item active">
                                <span data-v-604a8a88="" class="payment-method__item-custom-checkbox custom-radio">
                                    <input data-v-604a8a88="" type="radio" id="payment-momo" name="payment-method" autocomplete="off" value="momo" data-gtm-form-interact-field-id="5">
                                    <span data-v-604a8a88="" class="checkmark"></span>
                                </span>
                                <span data-v-604a8a88="" class="payment-method__item-icon-wrapper">
                                    <img data-v-604a8a88="" src="views/shop/img/momo.png" width="50" height="50" alt="Momo Logo">
                                </span>
                                <span data-v-604a8a88="" class="payment-method__item-name">Thanh toán qua Momo</span>
                            </label>
                        </div>
                        <div class="payment-method" style="padding: 20px 10px;">
                            <div data-v-604a8a88="" class="mgb--20 active">
                                <label data-v-604a8a88="" name="payment-cod" for="payment-cod" class="payment-method__item active">
                                    <span data-v-604a8a88="" class="payment-method__item-custom-checkbox custom-radio">
                                        <input data-v-604a8a88="" type="radio" id="payment-cod" name="payment-method" autocomplete="off" value="cod" data-gtm-form-interact-field-id="5">
                                        <span data-v-604a8a88="" class="checkmark"></span>
                                    </span>
                                    <span data-v-604a8a88="" class="payment-method__item-name">Thanh toán khi nhận hàng</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <!-- Button đặt hàng -->

                    <script>
                        // Function to show buttons based on selected payment method
                        function showButtons() {
                            var momoRadio = document.getElementById('payment-momo');
                            var codRadio = document.getElementById('payment-cod');
                            var momoButtons = document.getElementById('momo-buttons');
                            var codButtons = document.getElementById('cod-buttons');

                            // Check which radio button is selected
                            if (momoRadio.checked) {
                                momoButtons.style.display = 'block';
                                codButtons.style.display = 'none';
                            } else if (codRadio.checked) {
                                codButtons.style.display = 'block';
                                momoButtons.style.display = 'none';
                            }
                        }

                        // Add event listener to the radio buttons
                        var radioButtons = document.querySelectorAll('input[name="payment-method"]');
                        radioButtons.forEach(function(radioButton) {
                            radioButton.addEventListener('change', showButtons);
                        });

                        // Initially hide the buttons
                        var momoButtons = document.getElementById('momo-buttons');
                        var codButtons = document.getElementById('cod-buttons');
                        momoButtons.style.display = 'none';
                        codButtons.style.display = 'none';
                    </script>

                    <!-- HTML code for the buttons container -->
                    <div id="momo-buttons" style="display: none;">
                        <div class="form-group my-4 text-right">
                            <button type="submit" name="momopr" class="btn btn-success">Thanh toán MoMo QRcode</button>
                        </div>
                        <div class="form-group my-4 text-right">
                            <button type="submit" name="momoatm" class="btn btn-success">Thanh toán MoMo ATM</button>
                        </div>
                    </div>

                    <div id="cod-buttons" style="display: none;">
                        <div class="form-group my-4 text-right">
                            <button type="submit" name="thanhtoan" class="btn btn-success">Thanh toán Khi nhận hàng</button>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <?php
                        // Khởi tạo tổng tiền ban đầu
                        $tong_tien_voucher = $tong_tien;
                        $muc_giam_gia = 0;
                        if (isset($mot_khuyen_mai['muc_giam_gia']) && $mot_khuyen_mai['muc_giam_gia']) {
                            $muc_giam_gia = $mot_khuyen_mai['muc_giam_gia'];
                            $tong_tien_voucher -= $muc_giam_gia;
                        }
                        ?>
                        <input type="hidden" name="id_khuyen_mai" value="<?= isset($_GET['id_khuyen_mai']) && $_GET['id_khuyen_mai'] ? $_GET['id_khuyen_mai'] : 0 ?>">
                        <input type="hidden" name="id_gio_hang" value="<?= $id_gio_hang ?>">
                        <input type="hidden" name="tong_tien" value="<?= $tong_tien_voucher ?>">
                        <div class="col-md-12 text-right" style="margin-left: -455px;">
                            <strong>Tiền giảm giá: <span id="textcoupon" style="color: red;">đ<?php echo number_format($muc_giam_gia) ?></span></strong>
                            <strong>Thành tiền: <span id="texttotal" style="color: red;">đ<?php echo number_format($tong_tien_voucher) ?></span></strong>
                        </div>
                    </div>
                    <input type="hidden" value="<?= date('Y-m-d H:i:s') ?>" name="ngay_dat">
                </form>
            </div>


        </div>
    </div>
</div>
<script>

</script>
<?php
include "views/shop/layoutshop/footer.php";
?>