<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sticky Header Example</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet" href="views/shop/css/style.css">
</head>

<body>
    <style>
        #myHeader {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }

        /* Reset CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Style cho menu cấp 1 */
        .menu {
            position: relative;
            display: inline-block;
        }

        .menu .icon {
            cursor: pointer;
        }

        /* Style cho menu cấp 2 */
        .sub_menu {
            display: none;
            position: absolute;
            top: 50%;
            /* Hiển thị phía dưới menu cấp 1 */
            left: 0;
            background-color: #ffffff;
            /* Màu nền của menu cấp 2 */
            border: 1px solid #ddd;
            /* Đường viền của menu cấp 2 */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            /* Đổ bóng để tạo hiệu ứng đẹp */
            padding: 10px 0;
            /* Khoảng cách giữa các mục trong menu cấp 2 */
            z-index: 1000;
            /* Đảm bảo menu cấp 2 hiển thị trên cùng */
            width: 200px;
            /* Độ rộng của menu cấp 2 */
            border-radius: 5px;
            /* Góc bo tròn */
        }

        /* Hiển thị menu cấp 2 khi hover vào menu cấp 1 */
        .menu:hover .sub_menu {
            display: block;
        }

        /* Cố định menu cấp 2 ở đầu trang web khi cuộn */
        .sub_menu.fixed {
            position: fixed;
            top: 70px;
            /* Điều chỉnh khoảng cách giữa menu cấp 2 và đỉnh trang */
            width: 200px;
            /* Chiều rộng của menu cố định */
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
            /* Hiển thị đổ bóng để tạo hiệu ứng cố định */
        }

        /* Style cho các mục trong menu cấp 2 */
        .sub_menu a {
            display: block;
            padding: 10px 20px;
            color: #333;
            /* Màu chữ */
            text-decoration: none;
            transition: background-color 0.3s ease;
            /* Hiệu ứng màu nền */
        }

        .sub_menu a:hover {
            background-color: #f0f0f0;
            /* Màu nền khi hover */
        }
    </style>

    <header id="myHeader">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="<?= BASE_URL . '?act=shop' ?>"><img src="views/shop/img/logo_black.png" alt="Logo" style="width: 70px; height: 70px;"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <form id="searchForm" action="<?= BASE_URL . '?act=timkiem' ?>" method="get">
                <div class="input-group align-text-center col-md-12">
                    <input id="searchInput" type="text" class="form-control" name="search_query" placeholder="Tìm kiếm" aria-label="Tìm kiếm" aria-describedby="button-addon2">
                    <div class="input-group-append">
                        <button class="btn btn-outline-secondary" type="button" id="submitBtn"><i class="fas fa-search"></i></button>
                    </div>
                </div>
                </form>
                <script>
                document.getElementById("submitBtn").onclick = function() {
                    var searchQuery = document.getElementById("searchInput").value;
                    window.location.href = "<?= BASE_URL ?>?act=timkiem&search_query=" + encodeURIComponent(searchQuery) + "&gia=";
                };
                </script>

                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">

                            <a class="nav-link" href="?act=shop"><i class="fas fa-home"> </i>Trang chủ </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= BASE_URL . '?act=danhsachgiohang' ?>"><i class="fas fa-shopping-cart"></i> Giỏ hàng</a>
                        </li>
                        <li class="nav-item">
                            <?php
                            // Kiểm tra xem người dùng đã đăng nhập hay chưa
                            if (isset($_SESSION['user'])) {
                                echo '<a class="nav-link" href="#"> ' . $_SESSION['user']['ten_nguoi_dung'] . '</a>';
                            } else {
                                echo '<a href="?act=dangnhap" style="color:black;"><i class="fas fa-user"></i></a>';
                            }
                            ?>
                        </li>
                        <ul>
                            <li class="menu">
                                <a class="icon" style="color: black;" href="#">
                                    <i class="fas fa-bars"></i>
                                </a>
                                <div class="sub_menu">
                                    <a class="item" href="?act=bill">Đơn hàng</a>
                                    <a class="item" href="?act=gioithieushop">Giới thiệu</a>
                                    <a class="item" href="?act=sanphamshop">Sản phẩm</a>
                                    <a class="item" href="?act=lienheshop">Liên hệ</a>
                                    <a class="item" href="?act=baivietshop">Bài viết</a>
                                    <?php if (isset($_SESSION['user'])) {
                                        if ($_SESSION['id_chuc_vu'] == 1) {
                                            echo '<a class="item" href="?act=/">Quay lại trang admin</a>';
                                            echo '<a class="item" href="?act=logout">Đăng xuất</a>';
                                        } else {
                                            echo '<a class="item" href="?act=logout">Đăng xuất</a>';
                                        }
                                    }
                                    ?>
                                </div>
                            </li>
                        </ul>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div style="margin-bottom: 200px;"></div>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Cố định header khi cuộn trang
        window.onscroll = function() {
            myFunction()
        };

        var header = document.getElementById("myHeader");
        var sticky = header.offsetTop;

        function myFunction() {
            if (window.pageYOffset > sticky) {
                header.classList.add("sticky");
            } else {
                header.classList.remove("sticky");
            }
        }
    </script>