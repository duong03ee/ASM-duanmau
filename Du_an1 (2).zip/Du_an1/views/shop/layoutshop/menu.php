    <!-- nav  -->
    <!-- <nav style="padding: 5px 440px; margin-bottom: 10px; color :cadetblue">
        <ul>
            <li class="nav-item">
                <a class="nav-link" href="?act=shop">Trang chủ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?act=gioithieushop">Giới thiệu</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?act=sanphamshop">Sản phẩm</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?act=baivietshop">Bài viết</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?act=lienheshop">Liên hệ</a>
            </li>
        </ul>
    </nav> -->

<!-- slide -->
