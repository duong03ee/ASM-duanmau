<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>

<!-- MAIN CHÍNH -->
<style>
    .container {
        font-family: Arial, sans-serif;
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background-color: #f4f4f4;
        border: 1px solid #e4e4e4;
        border-radius: 5px;
    }

    .page-title {
        margin-top: 0;
        padding-bottom: 10px;
        border-bottom: 1px solid #ccc;
    }

    .btn-back {
        display: inline-block;
        margin-bottom: 20px;
        text-decoration: none;
        color: white;
        background-color: #007bff;
        border: 1px solid #007bff;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .btn-back i {
        margin-right: 5px;
    }

    .button {
        margin-bottom: 20px;
        text-align: right;
    }

    .btn-primary {
        text-decoration: none;
        color: white;
        background-color: #007bff;
        border: 1px solid #007bff;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }

    .detail-info {
        padding: 20px;
        background-color: white;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .detail-row {
        margin-bottom: 15px;
    }

    .detail-label {
        font-weight: bold;
    }

    .detail-value {
        display: block;
        width: calc(100% - 160px);
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-top: 5px;
    }

    .actions {
        margin-top: 20px;
    }

    .actions a {
        margin-right: 10px;
    }

    .btn-danger {
        text-decoration: none;
        color: white;
        background-color: #dc3545;
        border: 1px solid #dc3545;
        padding: 8px 12px;
        border-radius: 5px;
    }

    .btn-danger:hover {
        background-color: #c82333;
        border-color: #bd2130;
    }

    .binhluan-table {
        width: 87%;
        margin: 20px 45px;
        border-collapse: collapse;
    }

    .detail-info h3 {
        margin-left: 100px;
    }

    .binhluan-table th,
    .binhluan-table td {
        border: 1px solid #ddd;
        padding: 10px 20px;
    }

    .binhluan-table th {
        background-color: #f2f2f2;
    }

    .binhluan-table tr:hover {
        background-color: #f2f2f2;
    }

    .binhluan-table td:first-child {
        width: 30%;
    }
</style>
<div class="container">
    <h1 class="page-title">Chi tiết sản phẩm</h1>
    <a href="index.php?act=sanpham" class="btn btn-back"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <div class="button">
        <a href="<?= BASE_URL . '?act=themsanpham' ?>" class="btn btn-primary" role="button">Thêm sản phẩm</a>
    </div>
    <div class="detail-info">
        <!-- <div class="detail-row">
            <label class="detail-label">ID:</label>
            <span class="detail-value"><?php echo $sanpham['id_san_pham']; ?></span>
        </div> -->
        <div class="detail-row">
            <label class="detail-label">Tên sản phẩm:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $sanpham['ten_san_pham']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Ảnh sản phẩm:</label> <br>
            <img src="uploads/products/<?= $sanpham['anh'] ?>" class="img-thumbnail" alt="Product Image" style="width: 200px; height: 200px;">
        </div>
        <div class="detail-row">
            <label class="detail-label">Giá:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $sanpham['gia']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Giá bán:</label> <br>
            <input type="text" class="detail-value" value="<?php echo $sanpham['gia_ban']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Mô tả:</label> <br>
            <textarea class="detail-value" readonly><?php echo $sanpham['mota']; ?></textarea>
        </div>
        <div class="detail-row">
            <label class="detail-label">Số lượng</label>
            <input type="number" class="detail-value" value="<?php echo $sanpham['so_luong']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Danh mục:</label>
            <input type="text" class="detail-value" value="<?php echo $sanpham['ten_danh_muc']; ?>" readonly>
        </div>
        <div class="detail-row">
            <label class="detail-label">Trạng thái:</label>
            <span class="detail-value"><?php echo $sanpham['trang_thai']; ?></span>
        </div>

        <!-- <div class="actions">
            <a href="?act=suasanpham&id=<?php echo $sanpham['id_san_pham']; ?>" class="btn btn-primary" role="button">Sửa</a>
            <a href="?act=xoasanpham&id=<?php echo $sanpham['id_san_pham']; ?>" class="btn btn-danger" role="button" onclick="return confirm('Bạn có chắc chắn muốn xoá sản phẩm này không?')">Xoá</a>
        </div> -->
    </div>
    <!-- </div><div class="container">
    <h1 class="page-title">Bình luận</h1>
     <a href="index.php?act=sanpham" class="btn btn-back"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <div class="button">
        <a href="<?= BASE_URL . '?act=themsanpham' ?>" class="btn btn-primary" role="button">Thêm khuyến mãi</a>
    </div> -->
</div>
<br>

<!-- bình luận -->
<div class="container">
    <h1 class="page-title">Bình luận</h1>
    <div class="detail-info">
        <?php if ($binhluan && is_array($binhluan)) : ?>
            <table class="binhluan-table">
                <thead>
                    <tr>
                        <th>Người bình luận</th>
                        <th>Nội dung</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($binhluan as $comment) : ?>
                        <tr>
                            <td><?= $comment['ten_nguoi_dung'] ?></td>
                            <td><?= $comment['noidung_binhluan'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>Không có bình luận nào cho sản phẩm này.</p>
        <?php endif; ?>
    </div>
</div>


<br>

<!-- Đánh giá -->
<div class="container">
    <h1 class="page-title">Đánh giá</h1>
    <div class="detail-info">
        <?php if ($danhgia && is_array($danhgia)) : ?>
            <table class="binhluan-table">
                <thead>
                    <tr>
                        <th>Người đánh giá</th>
                        <th>Nội dung đánh giá</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($danhgia as $dg) : ?>
                        <tr>
                            <td><?= $dg['ten_nguoi_dung'] ?></td>
                            <td><?= $dg['noidung_đánh giá'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>Không có đánh giá nào cho sản phẩm này.</p>
        <?php endif; ?>
    </div>
</div>


<?php
include "views/layout/footer.php";
?>