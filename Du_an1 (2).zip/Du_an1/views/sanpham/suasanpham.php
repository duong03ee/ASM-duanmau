<?php
include "./views/layout/header.php";
include "./views/layout/menu.php";
?>

<!-- MAIN CHÍNH -->
<div class="container-fluid">
    <h1>Sửa sản phẩm</h1>
    <a href="index.php?act=sanpham" onclick="history.go(-1); return false;"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <br><br>
    <form action="<?= BASE_URL . '?act=update_sanpham&id=' . $sanpham['id_san_pham'] ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="ten_san_pham">Tên sản phẩm</label>
            <input type="text" class="form-control" id="ten_san_pham" name="ten_san_pham" value="<?= $sanpham['ten_san_pham'] ?>">
        </div>

        <div class="form-group">
            <label for="anh">Ảnh sản phẩm</label>
            <input type="file" class="form-control-file" id="anh" name="anh">
            <img src="uploads/products/<?= $sanpham['anh'] ?>" width="200" height="200" alt="">
        </div>

        <div class="form-group">
            <label for="gia">Giá</label>
            <input type="text" class="form-control" id="gia" name="gia" value="<?= $sanpham['gia'] ?>">
        </div>

        <div class="form-group">
            <label for="gia_ban">Giá bán</label>
            <input type="text" class="form-control" id="gia_ban" name="gia_ban" value="<?= $sanpham['gia_ban'] ?>">
        </div>

        <div class="form-group">
            <label for="mota">Mô tả</label>
            <input type="text" class="form-control" id="mota" name="mota" value="<?= $sanpham['mota'] ?>">
        </div>

        <div class="form-group">
            <label for="ngay_nhap">Ngày nhập</label>
            <input type="date" class="form-control" id="ngay_nhap" name="ngay_nhap" value="<?= $sanpham['ngay_nhap'] ?>">
        </div>

        <div class="form-group">
            <label for="so_luong">Số lượng</label>
            <input type="text" class="form-control" id="so_luong" name="so_luong" value="<?= $sanpham['so_luong'] ?>">
        </div>

        <!-- <div class="form-group">
            <label for="trang_thai">Trạng thái</label>
            <input type="text" class="form-control" id="trang_thai" name="trang_thai" value="<?= $sanpham['trang_thai'] ?>">
        </div> -->

        <div class="form-group">
            <label for="danh_muc">Danh mục</label>
            <select class="form-control" id="danh_muc" name="danh_muc">
                <?php foreach ($danhmuc as $dm) : ?>
                    <option value="<?= $dm['id_danh_muc'] ?>" <?= ($dm['id_danh_muc'] == $sanpham['id_danh_muc']) ? 'selected' : '' ?>>
                        <?= $dm['ten_danh_muc'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <input type="hidden" name="id_san_pham" value="<?=$sanpham['id_san_pham'] ?>">
        <button type="submit" class="btn btn-primary" name="sua">Sửa</button>
        <br><br>
        <button type="reset" class="btn btn-primary"><i class="fas fa-sync reset-icon" onclick="resetForm()"></i></button>
    </form>
</div>

<?php
include "./views/layout/footer.php";
?>
