<?php
include "views/layout/header.php";
include "views/layout/menu.php";

// $results = timkiem();
?>

<!-- MAIN CHÍNH -->
<div class="container-fluid">
    <h1>Danh sách sản phẩm</h1>

    <a href="<?= BASE_URL . '?act=themsanpham' ?>" class="btn btn-success">Thêm sản phẩm</a>
    <br></br>

    <div class="table-responsive">
        <table class="table table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>STT</th>
                    <th>Tên sản phẩm</th>
                    <th>Ảnh sản phẩm</th>
                    <!-- <th>Giá</th> -->
                    <th>Giá bán</th>
                    <!-- <th>Mô tả</th> -->
                    <!-- <th>Số lượng</th> -->
                    <th>Danh mục</th>
                    <th>Trạng thái</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stt=1;
                if (!empty($sanpham)) {
                    foreach ($sanpham as $item) {
                ?>
                        <tr>
                            <!-- <td><?php echo $item['id_san_pham']; ?></td> -->
                            <td><?php echo $stt++; ?></td>
                            <td><?php echo $item['ten_san_pham']; ?></td>
                            <td>
                                <img src="uploads/products/<?= $item['anh'] ?>" class="img-thumbnail" alt="Product Image" style="width: 100px; height: 100px;">
                            </td>
                            <!-- <td><?php echo $item['gia']; ?></td> -->
                            <td><?php echo $item['gia_ban']; ?></td>
                            <!-- <td><?php echo $item['mota']; ?></td>
                            <td><?php echo $item['so_luong']; ?></td> -->
                            <td><?php echo $item['ten_danh_muc']; ?></td>
                            <td><?php echo $item['trang_thai']; ?></td>
                            <td>
                                <a href="?act=ctsanpham&id=<?php echo $item['id_san_pham']; ?>" style="background-color: yellowgreen; border: none" class="btn btn-info btn-sm">Chi tiết</a>
                                <a href="?act=suasanpham&id=<?php echo $item['id_san_pham']; ?>" class="btn btn-info btn-sm">Sửa</a>
                                <a href="?act=xoasanpham&id=<?php echo $item['id_san_pham']; ?>" onclick="return confirm('Bạn có chắc chăn muốn xoá sản phẩm này không?')" class="btn btn-danger btn-sm">Xoá</a>
                            </td>
                        </tr>
                <?php
                    }
                } else {
                    // If there are no results
                    echo "<tr><td colspan='10'>Không tìm thấy kết quả.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- <div class="button">
        <a href="<?= BASE_URL . '?act=xoaAllsanpham' ?>" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xoá tất cả sản phẩm không?')">Xoá tất cả</a>
        
    </div> -->
</div>

<?php
include "views/layout/footer.php";
?>