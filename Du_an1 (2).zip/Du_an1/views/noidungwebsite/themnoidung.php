<?php
include "./views/layout/header.php";
include "./views/layout/menu.php";
?>

<!-- MAIN CHÍNH -->
<div class="container-fluid">
    <h1>Thêm nội dung website</h1>
    <br>
    <a href="index.php?act=danhsachnoidung" onclick="history.go(-1); return false;"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <br><br>
    <form action="<?= BASE_URL . '?act=create_noidung' ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="ten_trang_web">Tên trang web</label>
            <input type="text" class="form-control" id="ten_trang_web" name="ten_trang_web">
        </div>

        <div class="form-group">
            <label for="anh">Ảnh</label>
            <input type="file" class="form-control-file" id="anh" name="anh">
        </div>

        <div class="form-group">
            <label for="noi_dung">Nội dung</label>
            <input type="text" class="form-control" id="noi_dung" name="noi_dung">
        </div>

        <div class="form-group">
            <label for="link_lien_ket">Link liên kết</label>
            <input type="text" class="form-control" id="link_lien_ket" name="link_lien_ket">
        </div>

        
        <button type="submit" class="btn btn-primary" name="them">Thêm mới</button>
        <br><br>
        <button type="reset" class="btn btn-primary"><i class="fas fa-sync reset-icon" onclick="resetForm()"></i></button>
    </form>

</div>

<?php
include "./views/layout/footer.php";
?>
