<?php
include "views/layout/header.php";
include "views/layout/menu.php";
?>

<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Nội dung website</h1>
    <br>
    <!-- <a href="<?= BASE_URL . '?act=themnoidung' ?>" class="btn btn-success" role="button">Thêm nội dung</a> -->
    <br><br>
    <table class="table table-hover">
    <thead class="thead-dark">
        <tr>
            <!-- <th>ID nội dung</th> -->
            <th>Tên trang web</th>
            <th>Ảnh (Logo,...)</th>
            <th>Nội dung </th>
            <th>Link liên kết </th>
            <th>Hành động </th>
        </tr>
    </thead>
        <?php foreach ($noidung as $item) : ?>
            <tr>
                <!-- <td><?php echo $item['id_noi_dung']; ?></td> -->
                <td><?php echo $item['ten_trang_web']; ?></td>
                <td>
                    <img src="uploads/noidung/<?= $item['anh'] ?>" width="200" height="200" alt="">
                </td>
                <td><?php echo $item['noi_dung']; ?></td>
                <td><?php echo $item['link_lien_ket']; ?></td>
                <td>
                    <a href="?act=suanoidung&id=<?php echo $item['id_noi_dung']; ?>" class="btn btn-info" role="button">Sửa</a>
                    <!-- <a href="?act=xoanoidung&id=<?php echo $item['id_noi_dung']; ?>" class="btn btn-danger" role="button" onclick="return confirm('Bạn có chắc chăn muốn xoá nội dung này không?')">Xoá</a>
                </td> -->
            </tr>
        <?php endforeach; ?>
        
    </table>

    <!-- <div class="button">
        <a href="<?= BASE_URL . '?act=xoaAllnoidung' ?>" class="btn btn-danger" role="button" onclick="return confirm('Bạn có chắc chắn muốn xoá tất cả nội dung không?')">Xoá tất cả</a>
        
    </div> -->
</div>

<?php
include "views/layout/footer.php";
?>
