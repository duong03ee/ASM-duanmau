<?php
include "./views/layout/header.php";
include "./views/layout/menu.php";
?>

<!-- MAIN CHÍNH (CẦN SỬA) -->
<div class="container-fluid">
    <h1>Sửa nội dung website</h1>
    <a href="index.php?act=danhsachnoidung" onclick="history.go(-1); return false;"><i class="fas fa-arrow-left"></i> Trở lại danh sách</a>
    <br><br>
    <form action="<?= BASE_URL . '?act=update_noidung&id=' . $noidung['id_noi_dung'] ?>" method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="ten_trang_web" class="form-label">Tên trang web</label>
            <input type="text" class="form-control" id="ten_trang_web" name="ten_trang_web" value="<?= $noidung['ten_trang_web'] ?>">
        </div>

        <div class="mb-3">
            <label for="anh" class="form-label">Ảnh</label>
            <input type="file" class="form-control" id="anh" name="anh">
            <img src="uploads/noidung/<?= $noidung['anh'] ?>" width="200" height="200" alt="">
        </div>

        <div class="mb-3">
            <label for="noi_dung" class="form-label">Nội dung</label>
            <input type="text" class="form-control" id="noi_dung" name="noi_dung" value="<?= $noidung['noi_dung'] ?>">
        </div>

        <div class="mb-3">
            <label for="link_lien_ket" class="form-label">Link liên kết</label>
            <input type="text" class="form-control" id="link_lien_ket" name="link_lien_ket" value="<?= $noidung['link_lien_ket'] ?>">
        </div>

        <input type="hidden" name="id_noi_dung" value="<?= $noidung['id_noi_dung'] ?>">
        
        <button type="submit" class="btn btn-primary" name="sua">Cập nhật</button>
        <br><br>
        <button type="reset" class="btn btn-primary"><i class="fas fa-sync reset-icon" onclick="resetForm()"></i></button>
    </form>
</div>

<?php
include "./views/layout/footer.php";
?>
